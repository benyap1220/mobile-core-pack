-- Add unique constraint on deals_feed for upsert to work
ALTER TABLE deals_feed 
ADD CONSTRAINT deals_feed_offer_deeplink_unique 
UNIQUE (offer_id, deeplink_id);