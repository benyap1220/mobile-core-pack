-- Add rotation column to store AI-detected rotation
ALTER TABLE public.border_prototypes 
ADD COLUMN IF NOT EXISTS suggested_rotation integer DEFAULT 0;

ALTER TABLE public.border_styles 
ADD COLUMN IF NOT EXISTS suggested_rotation integer DEFAULT 0;

-- Add constraint for valid rotation values
ALTER TABLE public.border_prototypes 
ADD CONSTRAINT valid_rotation CHECK (suggested_rotation IN (0, 90, 180, 270));

ALTER TABLE public.border_styles 
ADD CONSTRAINT valid_rotation_styles CHECK (suggested_rotation IN (0, 90, 180, 270));