-- Add logo columns to vouchers table
ALTER TABLE public.vouchers
  ADD COLUMN IF NOT EXISTS merchant_domain TEXT,
  ADD COLUMN IF NOT EXISTS merchant_logo_path TEXT,
  ADD COLUMN IF NOT EXISTS logo_source TEXT DEFAULT 'none'
    CHECK (logo_source IN ('uploaded', 'resolver', 'vision_crop', 'generated', 'none')),
  ADD COLUMN IF NOT EXISTS logo_cache_updated_at TIMESTAMPTZ;

-- Storage RLS policies for logos bucket (if not exists)
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND policyname = 'logos_read_all'
  ) THEN
    CREATE POLICY "logos_read_all" ON storage.objects
      FOR SELECT USING (bucket_id = 'logos');
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND policyname = 'logos_insert_authenticated'
  ) THEN
    CREATE POLICY "logos_insert_authenticated" ON storage.objects
      FOR INSERT WITH CHECK (bucket_id = 'logos' AND auth.role() = 'authenticated');
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND policyname = 'logos_update_authenticated'
  ) THEN
    CREATE POLICY "logos_update_authenticated" ON storage.objects
      FOR UPDATE USING (bucket_id = 'logos' AND auth.role() = 'authenticated');
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND policyname = 'logos_delete_authenticated'
  ) THEN
    CREATE POLICY "logos_delete_authenticated" ON storage.objects
      FOR DELETE USING (bucket_id = 'logos' AND auth.role() = 'authenticated');
  END IF;
END $$;