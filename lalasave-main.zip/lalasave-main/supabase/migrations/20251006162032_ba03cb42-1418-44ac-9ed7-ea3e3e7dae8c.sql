-- Add logo-related columns to vouchers table
ALTER TABLE public.vouchers
  ADD COLUMN IF NOT EXISTS merchant_domain text,
  ADD COLUMN IF NOT EXISTS merchant_logo_url text,
  ADD COLUMN IF NOT EXISTS logo_source text CHECK (logo_source IN ('uploaded','clearbit','unavatar','favicon','wikimedia','pinterest','generated','none')) DEFAULT 'none',
  ADD COLUMN IF NOT EXISTS logo_cache_updated_at timestamptz;

-- Create merchant logo cache table
CREATE TABLE IF NOT EXISTS public.merchant_logo_cache (
  merchant_key text PRIMARY KEY,
  domain text,
  logo_path text,
  logo_source text,
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Enable RLS on cache table
ALTER TABLE public.merchant_logo_cache ENABLE ROW LEVEL SECURITY;

-- Cache table policies
CREATE POLICY "logo_cache_read_all" ON public.merchant_logo_cache 
  FOR SELECT USING (true);

CREATE POLICY "logo_cache_write" ON public.merchant_logo_cache 
  FOR INSERT WITH CHECK (true);

CREATE POLICY "logo_cache_update" ON public.merchant_logo_cache 
  FOR UPDATE USING (true) WITH CHECK (true);