-- Make category nullable since we're removing the category selector from UI
ALTER TABLE vouchers ALTER COLUMN category DROP NOT NULL;

-- Add personal_notes column for user's private notes
ALTER TABLE vouchers ADD COLUMN personal_notes TEXT;