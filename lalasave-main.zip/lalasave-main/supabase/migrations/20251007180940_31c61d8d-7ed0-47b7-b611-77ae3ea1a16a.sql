-- Purge bad Lazada cache entries
DELETE FROM public.merchant_logo_cache 
WHERE merchant_slug = 'lazada';

-- Also purge any logistics/lex variants that snuck in
DELETE FROM public.merchant_logo_cache 
WHERE public_url ILIKE '%logistics%' 
   OR public_url ILIKE '%lex%' 
   OR public_url ILIKE '%lazmall%';