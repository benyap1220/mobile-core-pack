-- Re-create the missing border_styles entry for the approved deals border
INSERT INTO border_styles (
  id,
  title,
  style_tag,
  svg_path,
  webm_path,
  lottie_path,
  preview_path,
  image_path,
  scale_mode,
  target,
  layout_mode,
  safe_area,
  suggested_rotation,
  style_transfer_mode,
  composition_params,
  replace_base_frame,
  frame_meta,
  view_box,
  approved_by
)
SELECT
  gen_random_uuid(),
  title,
  style_tag,
  svg_path,
  webm_path,
  lottie_path,
  preview_path,
  image_path,
  scale_mode,
  target,
  layout_mode,
  safe_area,
  suggested_rotation,
  style_transfer_mode,
  composition_params,
  replace_base_frame,
  frame_meta,
  view_box,
  submitted_by
FROM border_prototypes
WHERE id = 'f87e6fc4-7e1f-4af6-acc2-9771a2d00267'
  AND target = 'deals'
  AND is_approved = true;