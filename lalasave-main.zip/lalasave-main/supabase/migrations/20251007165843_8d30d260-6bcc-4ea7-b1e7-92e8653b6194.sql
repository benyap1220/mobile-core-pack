-- Add new columns to existing merchant_logo_cache table
ALTER TABLE public.merchant_logo_cache 
  ADD COLUMN IF NOT EXISTS merchant_lower text,
  ADD COLUMN IF NOT EXISTS width int,
  ADD COLUMN IF NOT EXISTS height int,
  ADD COLUMN IF NOT EXISTS status text DEFAULT 'ok',
  ADD COLUMN IF NOT EXISTS last_checked timestamptz DEFAULT now(),
  ADD COLUMN IF NOT EXISTS error text;

-- Populate merchant_lower from merchant_key
UPDATE public.merchant_logo_cache 
SET merchant_lower = LOWER(TRIM(merchant_key))
WHERE merchant_lower IS NULL;

-- Rename logo_path to logo_url for clarity (add new column, copy data, drop old)
ALTER TABLE public.merchant_logo_cache 
  ADD COLUMN IF NOT EXISTS logo_url text;

UPDATE public.merchant_logo_cache 
SET logo_url = logo_path
WHERE logo_url IS NULL AND logo_path IS NOT NULL;

-- Create merchant domain mapping table
CREATE TABLE IF NOT EXISTS public.merchant_domain_map (
  merchant_lower text PRIMARY KEY,
  domain text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Seed common brand domains
INSERT INTO public.merchant_domain_map (merchant_lower, domain) VALUES
  ('starbucks', 'starbucks.com'),
  ('mcdonalds', 'mcdonalds.com'),
  ('mcdonald''s', 'mcdonalds.com'),
  ('grab', 'grab.com'),
  ('lazada', 'lazada.com.my'),
  ('shopee', 'shopee.com.my'),
  ('foodpanda', 'foodpanda.my'),
  ('temu', 'temu.com'),
  ('taobao', 'taobao.com'),
  ('pizza hut', 'pizzahut.com'),
  ('kfc', 'kfc.com'),
  ('subway', 'subway.com'),
  ('burger king', 'burgerking.com'),
  ('nike', 'nike.com'),
  ('adidas', 'adidas.com')
ON CONFLICT (merchant_lower) DO NOTHING;

-- Create brand-logos bucket
INSERT INTO storage.buckets (id, name, public)
VALUES ('brand-logos', 'brand-logos', true)
ON CONFLICT (id) DO UPDATE SET public = true;

-- RLS for brand-logos bucket
DROP POLICY IF EXISTS "Public can view brand logos" ON storage.objects;
CREATE POLICY "Public can view brand logos"
ON storage.objects
FOR SELECT
TO public
USING (bucket_id = 'brand-logos');

DROP POLICY IF EXISTS "Service can manage brand logos" ON storage.objects;
CREATE POLICY "Service can manage brand logos"
ON storage.objects
FOR ALL
TO service_role
USING (bucket_id = 'brand-logos')
WITH CHECK (bucket_id = 'brand-logos');