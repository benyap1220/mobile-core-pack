-- Add selection metadata columns to ia_landings
ALTER TABLE ia_landings 
ADD COLUMN IF NOT EXISTS selection_reason jsonb DEFAULT '{}',
ADD COLUMN IF NOT EXISTS last_checked_at timestamptz DEFAULT now(),
ADD COLUMN IF NOT EXISTS deeplinkable boolean DEFAULT true;

-- Add index for last_checked_at for faster queries
CREATE INDEX IF NOT EXISTS idx_landings_last_checked ON ia_landings(last_checked_at);

-- Add column to track deeplink type (deeplink vs shoplink)
ALTER TABLE ia_deeplinks
ADD COLUMN IF NOT EXISTS deeplink_type text DEFAULT 'standard' CHECK (deeplink_type IN ('standard', 'shoplink'));