-- Add foreign key from ia_promos.offer_id to ia_advertisers.offer_id
ALTER TABLE ia_promos 
ADD CONSTRAINT ia_promos_offer_id_fkey 
FOREIGN KEY (offer_id) 
REFERENCES ia_advertisers(offer_id);