-- Allow authenticated users to upload affiliate logos
CREATE POLICY "Authenticated users can upload affiliate logos"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'logos' 
  AND (storage.foldername(name))[1] = 'affiliate-logos'
);