-- Create a function to compute total saved for a user in their preferred currency
-- This sums all used vouchers (status='used') and respects currency preferences

CREATE OR REPLACE FUNCTION public.compute_total_saved(
  p_user_id UUID,
  p_preferred_currency TEXT DEFAULT 'MYR'
)
RETURNS TABLE (
  total NUMERIC,
  has_mixed_currencies BOOLEAN
) 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_currencies TEXT[];
  v_has_mixed BOOLEAN;
  v_total NUMERIC;
BEGIN
  -- Get all distinct currencies from used vouchers
  SELECT ARRAY_AGG(DISTINCT currency)
  INTO v_currencies
  FROM vouchers
  WHERE user_id = p_user_id
    AND status = 'used'
    AND deal_type = 'amount'
    AND value IS NOT NULL;

  -- Check if there are mixed currencies
  v_has_mixed := COALESCE(array_length(v_currencies, 1), 0) > 1;

  -- Sum only vouchers matching preferred currency
  SELECT COALESCE(SUM(value), 0)
  INTO v_total
  FROM vouchers
  WHERE user_id = p_user_id
    AND status = 'used'
    AND deal_type = 'amount'
    AND value IS NOT NULL
    AND currency = p_preferred_currency;

  RETURN QUERY SELECT v_total, v_has_mixed;
END;
$$;