-- Add created_at column to ia_promos if it doesn't exist
ALTER TABLE ia_promos 
ADD COLUMN IF NOT EXISTS created_at timestamptz DEFAULT now();