-- Create user_settings table for currency preferences
create table if not exists public.user_settings (
  user_id uuid primary key references auth.users(id) on delete cascade,
  preferred_currency text default 'MYR',
  currency_symbol text default 'RM',
  symbol_position text check (symbol_position in ('prefix','suffix')) default 'prefix',
  locale text default 'en-MY',
  updated_at timestamptz not null default now()
);

-- Enable RLS
alter table public.user_settings enable row level security;

-- Policy: users can only access their own settings
create policy "user_settings_owner_rw" on public.user_settings
  for all using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Trigger to auto-update updated_at
create or replace function public.update_user_settings_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger user_settings_updated_at
  before update on public.user_settings
  for each row
  execute function public.update_user_settings_updated_at();