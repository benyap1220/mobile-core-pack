-- Create public-assets bucket for logos (public read)
INSERT INTO storage.buckets (id, name, public)
VALUES ('public-assets', 'public-assets', true)
ON CONFLICT (id) DO UPDATE SET public = true;

-- Ensure brand-logos is also public (from previous migration)
UPDATE storage.buckets SET public = true WHERE id = 'brand-logos';

-- Drop existing policies to recreate them cleanly
DROP POLICY IF EXISTS "cache_read_all" ON public.merchant_logo_cache;
DROP POLICY IF EXISTS "domain_read_all" ON public.merchant_domain_map;
DROP POLICY IF EXISTS "cache_write_service" ON public.merchant_logo_cache;
DROP POLICY IF EXISTS "domain_write_service" ON public.merchant_domain_map;

-- RLS policies for merchant_logo_cache (read all, write service only)
CREATE POLICY "cache_read_all" ON public.merchant_logo_cache 
  FOR SELECT USING (true);

CREATE POLICY "cache_write_service" ON public.merchant_logo_cache
  FOR ALL USING (auth.role() = 'service_role') 
  WITH CHECK (auth.role() = 'service_role');

-- RLS policies for merchant_domain_map (read all, write service only)
CREATE POLICY "domain_read_all" ON public.merchant_domain_map 
  FOR SELECT USING (true);

CREATE POLICY "domain_write_service" ON public.merchant_domain_map
  FOR ALL USING (auth.role() = 'service_role') 
  WITH CHECK (auth.role() = 'service_role');

-- Storage RLS for public-assets bucket (public read, service write)
DROP POLICY IF EXISTS "Public can view public assets" ON storage.objects;
CREATE POLICY "Public can view public assets"
ON storage.objects
FOR SELECT
TO public
USING (bucket_id = 'public-assets');

DROP POLICY IF EXISTS "Service can manage public assets" ON storage.objects;
CREATE POLICY "Service can manage public assets"
ON storage.objects
FOR ALL
TO service_role
USING (bucket_id = 'public-assets')
WITH CHECK (bucket_id = 'public-assets');