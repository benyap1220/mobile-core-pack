-- Add tracking_link column to ia_advertisers to store the offer's base tracking link
ALTER TABLE ia_advertisers ADD COLUMN IF NOT EXISTS tracking_link text;

-- Add deeplink_type to ia_deeplinks to distinguish between standard deeplinks and shoplinks
ALTER TABLE ia_deeplinks ADD COLUMN IF NOT EXISTS deeplink_type text DEFAULT 'standard' CHECK (deeplink_type IN ('standard', 'shoplink'));

-- Add index for faster lookups
CREATE INDEX IF NOT EXISTS idx_ia_deeplinks_type ON ia_deeplinks(deeplink_type);
CREATE INDEX IF NOT EXISTS idx_ia_advertisers_tracking_link ON ia_advertisers(tracking_link) WHERE tracking_link IS NOT NULL;