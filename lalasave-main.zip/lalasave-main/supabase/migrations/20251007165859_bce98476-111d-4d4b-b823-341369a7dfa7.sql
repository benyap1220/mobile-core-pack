-- Enable RLS on merchant_domain_map
ALTER TABLE public.merchant_domain_map ENABLE ROW LEVEL SECURITY;

-- Allow public read access to domain mappings
CREATE POLICY "Public can read merchant domain mappings"
ON public.merchant_domain_map
FOR SELECT
TO public
USING (true);