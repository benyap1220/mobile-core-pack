-- Update compute_total_saved to include ALL used vouchers with monetary values
-- This includes amount-type vouchers AND other vouchers with display_title containing values

DROP FUNCTION IF EXISTS public.compute_total_saved(UUID, TEXT);

CREATE OR REPLACE FUNCTION public.compute_total_saved(
  p_user_id UUID,
  p_preferred_currency TEXT DEFAULT 'MYR'
)
RETURNS TABLE (
  total NUMERIC,
  has_mixed_currencies BOOLEAN
) 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_currencies TEXT[];
  v_has_mixed BOOLEAN;
  v_total NUMERIC := 0;
  v_extracted_value NUMERIC;
  voucher_record RECORD;
BEGIN
  -- Get all distinct currencies from used vouchers
  SELECT ARRAY_AGG(DISTINCT currency)
  INTO v_currencies
  FROM vouchers
  WHERE user_id = p_user_id
    AND status = 'used';

  -- Check if there are mixed currencies
  v_has_mixed := COALESCE(array_length(v_currencies, 1), 0) > 1;

  -- Loop through all used vouchers and sum values
  FOR voucher_record IN 
    SELECT value, deal_type, display_title, currency
    FROM vouchers
    WHERE user_id = p_user_id
      AND status = 'used'
  LOOP
    -- If it's an amount-type voucher with a value, add it
    IF voucher_record.deal_type = 'amount' AND voucher_record.value IS NOT NULL THEN
      v_total := v_total + voucher_record.value;
    
    -- If it's other type with a display_title, try to extract the value
    ELSIF voucher_record.deal_type = 'other' AND voucher_record.display_title IS NOT NULL THEN
      -- Extract numeric value from display_title (e.g., "RM5 OFF Rides" -> 5)
      v_extracted_value := (regexp_match(voucher_record.display_title, '(\d+(?:\.\d+)?)'))[1]::NUMERIC;
      IF v_extracted_value IS NOT NULL THEN
        v_total := v_total + v_extracted_value;
      END IF;
    END IF;
  END LOOP;

  RETURN QUERY SELECT v_total, v_has_mixed;
END;
$$;