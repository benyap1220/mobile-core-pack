-- Add display_title and source_offer_id to vouchers table
ALTER TABLE public.vouchers
  ADD COLUMN IF NOT EXISTS display_title TEXT,
  ADD COLUMN IF NOT EXISTS source_offer_id UUID REFERENCES public.affiliate_offers(id) ON DELETE SET NULL;