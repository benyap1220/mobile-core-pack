-- Create brand_logo_overrides table for curated first-party logos
create table if not exists public.brand_logo_overrides (
  brand_slug text primary key,
  storage_path text not null,
  source text,
  updated_at timestamptz default now()
);

-- Enable RLS
alter table public.brand_logo_overrides enable row level security;

-- Public read access
drop policy if exists "override select all" on public.brand_logo_overrides;
create policy "override select all" on public.brand_logo_overrides
  for select using (true);

-- Service role write access
drop policy if exists "override service write" on public.brand_logo_overrides;
create policy "override service write" on public.brand_logo_overrides
  for all to service_role using (true) with check (true);

-- Add unique index on merchant_domain_map.brand_slug
create unique index if not exists merchant_domain_map_slug_unique 
  on public.merchant_domain_map(merchant_slug);

-- Clean up bad cache entries (logistics, sub-brands)
delete from public.merchant_logo_cache 
where public_url like '%logistics%' 
   or public_url like '%seller%' 
   or public_url like '%business%'
   or public_url like '%careers%'
   or public_url like '%press%'
   or public_url like '%blog%';