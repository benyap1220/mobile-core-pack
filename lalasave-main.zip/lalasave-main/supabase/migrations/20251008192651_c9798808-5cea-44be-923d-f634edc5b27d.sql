-- Phase 5: Add style transfer columns to border_prototypes
ALTER TABLE border_prototypes 
ADD COLUMN IF NOT EXISTS style_transfer_mode boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS style_reference_path text,
ADD COLUMN IF NOT EXISTS base_frame_path text,
ADD COLUMN IF NOT EXISTS extracted_motifs jsonb,
ADD COLUMN IF NOT EXISTS composition_params jsonb DEFAULT '{"corner_emphasis": 1.0, "edge_repeat": "auto-fit"}'::jsonb;

-- Add style transfer columns to border_styles (approved borders)
ALTER TABLE border_styles
ADD COLUMN IF NOT EXISTS style_transfer_mode boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS composition_params jsonb DEFAULT '{"corner_emphasis": 1.0, "edge_repeat": "auto-fit"}'::jsonb;

COMMENT ON COLUMN border_prototypes.style_transfer_mode IS 'True if this border was created via style transfer (dual input)';
COMMENT ON COLUMN border_prototypes.style_reference_path IS 'Path to the decorative style reference image';
COMMENT ON COLUMN border_prototypes.base_frame_path IS 'Path to the structural base frame image';
COMMENT ON COLUMN border_prototypes.extracted_motifs IS 'JSON containing extracted corner and edge motifs with classifications';
COMMENT ON COLUMN border_prototypes.composition_params IS 'Parameters used for style-to-geometry mapping';