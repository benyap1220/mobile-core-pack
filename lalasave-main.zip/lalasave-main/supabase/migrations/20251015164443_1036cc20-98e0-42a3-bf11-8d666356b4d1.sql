-- Enable pg_cron and pg_net extensions for scheduled jobs
CREATE EXTENSION IF NOT EXISTS pg_cron;
CREATE EXTENSION IF NOT EXISTS pg_net;

-- Grant permissions
GRANT USAGE ON SCHEMA cron TO postgres;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA cron TO postgres;

-- Schedule ia-promos-ingest to run every 60 minutes
SELECT cron.schedule(
  'ia-promos-ingest-hourly',
  '0 * * * *',
  $$
  SELECT net.http_post(
    url:='https://cnayuxiwjgpjrzkphhwz.supabase.co/functions/v1/ia-promos-ingest',
    headers:='{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNuYXl1eGl3amdwanJ6a3BoaHd6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTk2NzM4MDYsImV4cCI6MjA3NTI0OTgwNn0.ZA_6hIEYMQCDRGvyvmc3x-xTFg_MOhgKiZvmZ9TBWJI"}'::jsonb,
    body:='{}'::jsonb
  ) as request_id;
  $$
);

-- Schedule deals-build-feed to run every 2 hours
SELECT cron.schedule(
  'deals-build-feed-2hourly',
  '0 */2 * * *',
  $$
  SELECT net.http_post(
    url:='https://cnayuxiwjgpjrzkphhwz.supabase.co/functions/v1/deals-build-feed',
    headers:='{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNuYXl1eGl3amdwanJ6a3BoaHd6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTk2NzM4MDYsImV4cCI6MjA3NTI0OTgwNn0.ZA_6hIEYMQCDRGvyvmc3x-xTFg_MOhgKiZvmZ9TBWJI"}'::jsonb,
    body:='{}'::jsonb
  ) as request_id;
  $$
);