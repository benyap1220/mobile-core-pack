-- Add target and view_box columns to border_prototypes
ALTER TABLE border_prototypes
ADD COLUMN target text CHECK (target IN ('deals', 'home')) DEFAULT 'deals',
ADD COLUMN view_box jsonb DEFAULT '{"w": 1200, "h": 675}'::jsonb;

-- Add target and view_box columns to border_styles
ALTER TABLE border_styles
ADD COLUMN target text CHECK (target IN ('deals', 'home')) NOT NULL DEFAULT 'deals',
ADD COLUMN view_box jsonb DEFAULT '{"w": 1200, "h": 675}'::jsonb;

-- Create index on target for efficient querying
CREATE INDEX idx_border_styles_target ON border_styles(target);

-- Backfill existing rows with target='deals'
UPDATE border_prototypes SET target = 'deals' WHERE target IS NULL;
UPDATE border_styles SET target = 'deals' WHERE target IS NULL;