-- Ensure ia_promos columns exist (table already created previously)
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'ia_promos' AND column_name = 'tags') THEN
    ALTER TABLE public.ia_promos ADD COLUMN tags text[];
  END IF;
END $$;

-- Add new columns to deals_feed
ALTER TABLE public.deals_feed
  ADD COLUMN IF NOT EXISTS promo_id uuid,
  ADD COLUMN IF NOT EXISTS has_coupon boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS deeplink_type text DEFAULT 'standard';

-- Add constraint for deeplink_type
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'deals_feed_deeplink_type_check') THEN
    ALTER TABLE public.deals_feed 
      ADD CONSTRAINT deals_feed_deeplink_type_check 
      CHECK (deeplink_type IN ('standard', 'shoplink'));
  END IF;
END $$;

-- Create indexes
CREATE INDEX IF NOT EXISTS deals_feed_has_coupon_idx 
  ON public.deals_feed(has_coupon) 
  WHERE has_coupon = true;

CREATE INDEX IF NOT EXISTS deals_feed_promo_id_idx 
  ON public.deals_feed(promo_id);

CREATE INDEX IF NOT EXISTS ia_promos_offer_id_idx 
  ON public.ia_promos(offer_id);

-- Ensure aff_clicks allows public inserts
DROP POLICY IF EXISTS aff_clicks_public_insert ON public.aff_clicks;
CREATE POLICY aff_clicks_public_insert ON public.aff_clicks
  FOR INSERT WITH CHECK (true);

-- Ensure aff_impressions allows public inserts  
DROP POLICY IF EXISTS aff_impressions_public_insert ON public.aff_impressions;
CREATE POLICY aff_impressions_public_insert ON public.aff_impressions
  FOR INSERT WITH CHECK (true);