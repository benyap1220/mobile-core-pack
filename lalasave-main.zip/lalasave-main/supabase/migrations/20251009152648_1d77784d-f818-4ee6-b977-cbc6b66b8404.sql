-- Add image_path and scale_mode columns for simplified PNG border system
ALTER TABLE border_prototypes 
ADD COLUMN IF NOT EXISTS image_path TEXT,
ADD COLUMN IF NOT EXISTS scale_mode TEXT DEFAULT 'cover' CHECK (scale_mode IN ('cover', 'contain'));

ALTER TABLE border_styles
ADD COLUMN IF NOT EXISTS image_path TEXT,
ADD COLUMN IF NOT EXISTS scale_mode TEXT DEFAULT 'cover' CHECK (scale_mode IN ('cover', 'contain'));