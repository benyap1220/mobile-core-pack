-- Add apply_mode column to vouchers table
ALTER TABLE public.vouchers
  ADD COLUMN IF NOT EXISTS apply_mode TEXT
  CHECK (apply_mode IN ('auto', 'added_to_card', 'manual'))
  DEFAULT 'manual';