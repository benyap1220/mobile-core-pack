-- Enable RLS policies for borders bucket uploads
-- Allow admins to upload, update, and delete border artwork

CREATE POLICY "Admins can upload to borders bucket"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'borders' 
  AND has_role(auth.uid(), 'admin'::app_role)
);

CREATE POLICY "Admins can update borders bucket files"
ON storage.objects
FOR UPDATE
TO authenticated
USING (
  bucket_id = 'borders' 
  AND has_role(auth.uid(), 'admin'::app_role)
);

CREATE POLICY "Admins can delete from borders bucket"
ON storage.objects
FOR DELETE
TO authenticated
USING (
  bucket_id = 'borders' 
  AND has_role(auth.uid(), 'admin'::app_role)
);

-- Allow admins to upload to borders_previews bucket
CREATE POLICY "Admins can upload to borders_previews bucket"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'borders_previews' 
  AND has_role(auth.uid(), 'admin'::app_role)
);

CREATE POLICY "Admins can update borders_previews bucket files"
ON storage.objects
FOR UPDATE
TO authenticated
USING (
  bucket_id = 'borders_previews' 
  AND has_role(auth.uid(), 'admin'::app_role)
);

CREATE POLICY "Admins can delete from borders_previews bucket"
ON storage.objects
FOR DELETE
TO authenticated
USING (
  bucket_id = 'borders_previews' 
  AND has_role(auth.uid(), 'admin'::app_role)
);