-- 1) Create enum type for logo_source
DO $$ BEGIN
  CREATE TYPE logo_source_enum AS ENUM ('uploaded','resolver','vision_crop','generated','none');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- 2) Clean bad values & nulls first
UPDATE public.vouchers
SET logo_source = 'none'
WHERE logo_source IS NULL OR logo_source NOT IN ('uploaded','resolver','vision_crop','generated','none');

-- 3) Ensure path column exists
ALTER TABLE public.vouchers
  ADD COLUMN IF NOT EXISTS merchant_logo_path TEXT;

-- 4) Drop old check constraint and default
ALTER TABLE public.vouchers
  DROP CONSTRAINT IF EXISTS vouchers_logo_source_check,
  ALTER COLUMN logo_source DROP DEFAULT;

-- 5) Convert to enum
ALTER TABLE public.vouchers
  ALTER COLUMN logo_source TYPE logo_source_enum USING
    CASE
      WHEN logo_source IN ('uploaded','resolver','vision_crop','generated','none') THEN logo_source::logo_source_enum
      ELSE 'none'::logo_source_enum
    END;

-- 6) Set new enum default and make not null
ALTER TABLE public.vouchers
  ALTER COLUMN logo_source SET DEFAULT 'none'::logo_source_enum,
  ALTER COLUMN logo_source SET NOT NULL;