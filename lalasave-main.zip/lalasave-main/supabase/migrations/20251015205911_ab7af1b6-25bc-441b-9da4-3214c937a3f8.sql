-- Step 1: Drop foreign key constraints
ALTER TABLE ia_promo_deeplinks 
  DROP CONSTRAINT IF EXISTS ia_promo_deeplinks_promo_id_fkey;

ALTER TABLE deals_feed
  DROP CONSTRAINT IF EXISTS deals_feed_primary_promo_id_fkey;

-- Step 2: Migrate ia_promos.id from UUID to bigint
ALTER TABLE ia_promos 
  ALTER COLUMN id DROP DEFAULT,
  ALTER COLUMN id TYPE bigint USING (
    CASE 
      WHEN id::text ~ '^\d+$' THEN id::text::bigint
      ELSE NULL
    END
  );

-- Step 3: Update ia_promo_deeplinks.promo_id to bigint
ALTER TABLE ia_promo_deeplinks
  ALTER COLUMN promo_id TYPE bigint USING (
    CASE
      WHEN promo_id::text ~ '^\d+$' THEN promo_id::text::bigint
      ELSE NULL
    END
  );

-- Step 4: Update deals_feed.primary_promo_id to bigint
ALTER TABLE deals_feed
  ALTER COLUMN primary_promo_id TYPE bigint USING (
    CASE
      WHEN primary_promo_id::text ~ '^\d+$' THEN primary_promo_id::text::bigint
      ELSE NULL
    END
  );

-- Step 5: Recreate foreign key constraints
ALTER TABLE ia_promo_deeplinks
  ADD CONSTRAINT ia_promo_deeplinks_promo_id_fkey 
  FOREIGN KEY (promo_id) REFERENCES ia_promos(id) ON DELETE CASCADE;

ALTER TABLE deals_feed
  ADD CONSTRAINT deals_feed_primary_promo_id_fkey
  FOREIGN KEY (primary_promo_id) REFERENCES ia_promos(id) ON DELETE SET NULL;

-- Step 6: Ensure ia_promos.id has unique constraint
CREATE UNIQUE INDEX IF NOT EXISTS ia_promos_id_unique ON ia_promos(id);