-- Revert the border target back to 'home'
UPDATE border_styles 
SET target = 'home' 
WHERE id = 'cd4966f2-1663-4f95-9d58-2b296e1ef8bb';