-- Add replace_base_frame and frame_meta to border tables
ALTER TABLE border_prototypes 
  ADD COLUMN IF NOT EXISTS replace_base_frame BOOLEAN DEFAULT false,
  ADD COLUMN IF NOT EXISTS frame_meta JSONB DEFAULT '{
    "viewW": 1200,
    "viewH": 675,
    "cornerRadius": 24,
    "contentInset": 20,
    "outerInset": 0,
    "hadFrameRemoved": false
  }'::jsonb;

ALTER TABLE border_styles
  ADD COLUMN IF NOT EXISTS replace_base_frame BOOLEAN DEFAULT false,
  ADD COLUMN IF NOT EXISTS frame_meta JSONB DEFAULT '{
    "viewW": 1200,
    "viewH": 675,
    "cornerRadius": 24,
    "contentInset": 20,
    "outerInset": 0,
    "hadFrameRemoved": false
  }'::jsonb;