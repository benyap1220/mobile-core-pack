-- Drop the old CHECK constraint
ALTER TABLE public.vouchers
DROP CONSTRAINT IF EXISTS vouchers_logo_source_check;

-- Add a new CHECK constraint that allows NULL
ALTER TABLE public.vouchers
ADD CONSTRAINT vouchers_logo_source_check
CHECK (logo_source IS NULL OR logo_source IN ('uploaded', 'resolver', 'vision_crop', 'generated', 'none'));

-- Update any existing NULL values to 'none'
UPDATE public.vouchers
SET logo_source = 'none'
WHERE logo_source IS NULL;