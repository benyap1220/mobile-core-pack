-- IA Advertisers (approved offer programs)
CREATE TABLE IF NOT EXISTS ia_advertisers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  offer_id BIGINT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  logo_url TEXT,
  countries TEXT[],
  categories TEXT[],
  tracking_type TEXT,
  commission_json JSONB,
  approved BOOLEAN NOT NULL DEFAULT true,
  last_seen TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- IA Landing pages per advertiser
CREATE TABLE IF NOT EXISTS ia_landings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  offer_id BIGINT NOT NULL REFERENCES ia_advertisers(offer_id) ON DELETE CASCADE,
  url TEXT NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('home','promo','category','product')),
  title TEXT,
  description TEXT,
  image_url TEXT,
  score NUMERIC DEFAULT 0,
  discovered_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (offer_id, url)
);

-- IA Deeplinks cache
CREATE TABLE IF NOT EXISTS ia_deeplinks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  offer_id BIGINT NOT NULL REFERENCES ia_advertisers(offer_id) ON DELETE CASCADE,
  landing_id UUID REFERENCES ia_landings(id) ON DELETE SET NULL,
  raw_url TEXT NOT NULL,
  deeplink_url TEXT NOT NULL,
  aff_sub TEXT,
  aff_sub2 TEXT,
  aff_sub3 TEXT,
  aff_sub4 TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at TIMESTAMPTZ
);

-- Create unique index for deeplinks
CREATE UNIQUE INDEX IF NOT EXISTS ia_deeplinks_unique_idx 
ON ia_deeplinks (offer_id, raw_url, COALESCE(aff_sub, ''), COALESCE(aff_sub2, ''), COALESCE(aff_sub3, ''), COALESCE(aff_sub4, ''));

-- Deals feed (materialized view of offers)
CREATE TABLE IF NOT EXISTS deals_feed (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  offer_id BIGINT NOT NULL,
  deeplink_id UUID NOT NULL REFERENCES ia_deeplinks(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  subtitle TEXT,
  badge TEXT,
  tags TEXT[],
  image_url TEXT,
  expires_at TIMESTAMPTZ,
  platform TEXT,
  country TEXT,
  source TEXT NOT NULL DEFAULT 'IA',
  score NUMERIC NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS deals_feed_idx ON deals_feed (score DESC, created_at DESC, id);

-- Affiliate clicks tracking
CREATE TABLE IF NOT EXISTS aff_clicks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  deeplink_id UUID REFERENCES ia_deeplinks(id) ON DELETE SET NULL,
  offer_id BIGINT,
  aff_sub TEXT,
  aff_sub2 TEXT,
  aff_sub3 TEXT,
  aff_sub4 TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Affiliate impressions tracking
CREATE TABLE IF NOT EXISTS aff_impressions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  deal_id UUID REFERENCES deals_feed(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- RLS Policies
ALTER TABLE ia_advertisers ENABLE ROW LEVEL SECURITY;
ALTER TABLE ia_landings ENABLE ROW LEVEL SECURITY;
ALTER TABLE ia_deeplinks ENABLE ROW LEVEL SECURITY;
ALTER TABLE deals_feed ENABLE ROW LEVEL SECURITY;
ALTER TABLE aff_clicks ENABLE ROW LEVEL SECURITY;
ALTER TABLE aff_impressions ENABLE ROW LEVEL SECURITY;

-- Public read for deals feed
CREATE POLICY "deals_feed_public_read" ON deals_feed FOR SELECT USING (true);

-- Service role can manage everything
CREATE POLICY "ia_advertisers_service" ON ia_advertisers FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "ia_landings_service" ON ia_landings FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "ia_deeplinks_service" ON ia_deeplinks FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "deals_feed_service" ON deals_feed FOR ALL USING (auth.role() = 'service_role');

-- Authenticated users can log clicks and impressions
CREATE POLICY "aff_clicks_insert" ON aff_clicks FOR INSERT WITH CHECK (true);
CREATE POLICY "aff_impressions_insert" ON aff_impressions FOR INSERT WITH CHECK (true);

-- Admins can manage everything
CREATE POLICY "ia_advertisers_admin" ON ia_advertisers FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "ia_landings_admin" ON ia_landings FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "deals_feed_admin" ON deals_feed FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));