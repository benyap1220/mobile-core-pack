-- Ensure brand-logos bucket exists and is public
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('brand-logos', 'brand-logos', true, 5242880, ARRAY['image/png', 'image/jpeg', 'image/svg+xml', 'image/webp'])
ON CONFLICT (id) DO UPDATE SET public = true;

-- Storage RLS policies for brand-logos
DROP POLICY IF EXISTS "public read brand-logos" ON storage.objects;
CREATE POLICY "public read brand-logos"
ON storage.objects FOR SELECT TO public
USING (bucket_id = 'brand-logos');

DROP POLICY IF EXISTS "service write brand-logos" ON storage.objects;
CREATE POLICY "service write brand-logos"
ON storage.objects FOR ALL TO service_role
USING (bucket_id = 'brand-logos')
WITH CHECK (bucket_id = 'brand-logos');

-- Recreate merchant_logo_cache with new schema
DROP TABLE IF EXISTS public.merchant_logo_cache CASCADE;
CREATE TABLE public.merchant_logo_cache (
  merchant_slug text PRIMARY KEY,
  public_url text NOT NULL,
  source text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Recreate merchant_domain_map
DROP TABLE IF EXISTS public.merchant_domain_map CASCADE;
CREATE TABLE public.merchant_domain_map (
  merchant_slug text PRIMARY KEY,
  domain text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.merchant_logo_cache ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.merchant_domain_map ENABLE ROW LEVEL SECURITY;

-- Cache policies
DROP POLICY IF EXISTS "cache select all" ON public.merchant_logo_cache;
CREATE POLICY "cache select all" ON public.merchant_logo_cache
FOR SELECT USING (true);

DROP POLICY IF EXISTS "cache service write" ON public.merchant_logo_cache;
CREATE POLICY "cache service write" ON public.merchant_logo_cache
FOR ALL TO service_role USING (true) WITH CHECK (true);

-- Domain map policies
DROP POLICY IF EXISTS "domain select all" ON public.merchant_domain_map;
CREATE POLICY "domain select all" ON public.merchant_domain_map
FOR SELECT USING (true);

DROP POLICY IF EXISTS "domain service write" ON public.merchant_domain_map;
CREATE POLICY "domain service write" ON public.merchant_domain_map
FOR ALL TO service_role USING (true) WITH CHECK (true);

-- Seed common merchant domains
INSERT INTO public.merchant_domain_map (merchant_slug, domain) VALUES
  ('grab', 'grab.com'),
  ('lazada', 'lazada.com.my'),
  ('shopee', 'shopee.com.my'),
  ('starbucks', 'starbucks.com'),
  ('mcdonalds', 'mcdonalds.com'),
  ('foodpanda', 'foodpanda.my'),
  ('temu', 'temu.com'),
  ('amazon', 'amazon.com'),
  ('taobao', 'taobao.com')
ON CONFLICT (merchant_slug) DO NOTHING;