-- Add missing columns to existing ia_promos table
ALTER TABLE public.ia_promos
  ADD COLUMN IF NOT EXISTS landing_id uuid REFERENCES public.ia_landings(id) ON DELETE CASCADE,
  ADD COLUMN IF NOT EXISTS headline text,
  ADD COLUMN IF NOT EXISTS summary text,
  ADD COLUMN IF NOT EXISTS tags text[],
  ADD COLUMN IF NOT EXISTS starts_at timestamptz,
  ADD COLUMN IF NOT EXISTS ends_at timestamptz,
  ADD COLUMN IF NOT EXISTS score numeric DEFAULT 0;

-- Copy data from old columns to new ones for migration
UPDATE public.ia_promos
SET headline = COALESCE(title, ''),
    summary = COALESCE(note, ''),
    starts_at = valid_from,
    ends_at = valid_until
WHERE headline IS NULL;

-- Add promo reference and quality tracking to deals_feed
ALTER TABLE public.deals_feed
  ADD COLUMN IF NOT EXISTS primary_promo_id uuid,
  ADD COLUMN IF NOT EXISTS has_coupon boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS quality_score numeric DEFAULT 0;

-- Create indexes
CREATE INDEX IF NOT EXISTS deals_has_coupon_idx
  ON public.deals_feed(has_coupon) WHERE has_coupon = true;

CREATE INDEX IF NOT EXISTS deals_quality_score_idx
  ON public.deals_feed(quality_score DESC);

CREATE INDEX IF NOT EXISTS ia_promos_landing_id_idx
  ON public.ia_promos(landing_id) WHERE landing_id IS NOT NULL;