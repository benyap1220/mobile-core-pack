-- Create affiliate_offers table
create table if not exists public.affiliate_offers (
  id uuid primary key default gen_random_uuid(),
  platform text not null,
  merchant text not null,
  offer_title text not null,
  offer_summary text,
  terms text,
  coupon_code text,
  deep_link text not null,
  tracking_source text default 'direct',
  image_url text,
  logo_path text,
  region text default 'MY',
  category text default 'marketplace',
  expiry_date date,
  is_active boolean default true,
  created_at timestamptz default now()
);

-- Enable RLS
alter table public.affiliate_offers enable row level security;

-- Public read policy
create policy "offers_are_public_read" 
on public.affiliate_offers 
for select 
using (true);

-- Create affiliate_clicks table
create table if not exists public.affiliate_clicks (
  id bigserial primary key,
  offer_id uuid references public.affiliate_offers(id) on delete cascade,
  user_id uuid,
  clicked_at timestamptz default now(),
  user_agent text
);

-- Enable RLS
alter table public.affiliate_clicks enable row level security;

-- Public insert policy
create policy "clicks_public_insert" 
on public.affiliate_clicks 
for insert 
with check (true);

-- Seed sample offers
insert into public.affiliate_offers (platform, merchant, offer_title, offer_summary, terms, coupon_code, deep_link, tracking_source, region, category, expiry_date, is_active) values
('shopee', 'Shopee', 'RM10 OFF First Order', 'New users get RM10 off on orders above RM30', 'Min spend RM30. Valid for new users only. One use per account.', 'NEWUSER10', 'https://shopee.com.my', 'direct', 'MY', 'marketplace', current_date + interval '30 days', true),
('lazada', 'Lazada', 'Up to 20% Cashback', 'Earn up to 20% cashback on electronics', 'Max cashback RM50. Valid on selected electronics. Check app for details.', null, 'https://lazada.com.my', 'direct', 'MY', 'marketplace', current_date + interval '14 days', true),
('grab', 'Grab', 'RM5 OFF Rides', 'Save RM5 on your next GrabCar ride', 'Valid for rides above RM15. One use per week.', 'GRAB5', 'https://grab.com/my', 'direct', 'MY', 'ehailing', current_date + interval '7 days', true),
('foodpanda', 'foodpanda', 'Free Delivery', 'Free delivery on orders above RM20', 'Min order RM20. Valid at participating restaurants only.', 'FREEDEL', 'https://foodpanda.com.my', 'direct', 'MY', 'food', current_date + interval '21 days', true),
('temu', 'Temu', '50% OFF Fashion', 'Up to 50% off on fashion items', 'Limited time offer. While stocks last.', null, 'https://temu.com', 'direct', 'MY', 'marketplace', current_date + interval '45 days', true),
('amazon', 'Amazon', 'RM15 OFF Books', 'Get RM15 off book purchases above RM50', 'Min spend RM50 on books. Valid for Prime members.', 'BOOKS15', 'https://amazon.com.my', 'direct', 'MY', 'marketplace', null, true),
('taobao', 'Taobao', '¥20 OFF Electronics', 'Save ¥20 on electronics above ¥100', 'Min spend ¥100. Valid on selected brands.', 'TECH20', 'https://taobao.com', 'direct', 'MY', 'electronics', current_date + interval '60 days', true);