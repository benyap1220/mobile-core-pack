-- Update the compute_total_saved function to sum ALL amount-type vouchers in preferred currency
-- AND also count vouchers in other currencies (for the mixed currencies flag)

DROP FUNCTION IF EXISTS public.compute_total_saved(UUID, TEXT);

CREATE OR REPLACE FUNCTION public.compute_total_saved(
  p_user_id UUID,
  p_preferred_currency TEXT DEFAULT 'MYR'
)
RETURNS TABLE (
  total NUMERIC,
  has_mixed_currencies BOOLEAN
) 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_currencies TEXT[];
  v_has_mixed BOOLEAN;
  v_total NUMERIC;
BEGIN
  -- Get all distinct currencies from used vouchers with amount-type deals
  SELECT ARRAY_AGG(DISTINCT currency)
  INTO v_currencies
  FROM vouchers
  WHERE user_id = p_user_id
    AND status = 'used'
    AND deal_type = 'amount'
    AND value IS NOT NULL;

  -- Check if there are mixed currencies
  v_has_mixed := COALESCE(array_length(v_currencies, 1), 0) > 1;

  -- Sum ALL amount-type vouchers (regardless of currency for now)
  -- In the future, we can add currency conversion here
  SELECT COALESCE(SUM(value), 0)
  INTO v_total
  FROM vouchers
  WHERE user_id = p_user_id
    AND status = 'used'
    AND deal_type = 'amount'
    AND value IS NOT NULL;

  RETURN QUERY SELECT v_total, v_has_mixed;
END;
$$;