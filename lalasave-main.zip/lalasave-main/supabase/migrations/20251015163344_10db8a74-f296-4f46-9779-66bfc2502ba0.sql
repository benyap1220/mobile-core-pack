-- Model promos (one card per promo)
CREATE TABLE IF NOT EXISTS ia_promos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  offer_id BIGINT NOT NULL,
  advertiser_name TEXT,
  promo_type TEXT CHECK (promo_type IN ('coupon','campaign')),
  promo_id TEXT,
  title TEXT,
  summary TEXT,
  code TEXT DEFAULT '',
  discount_type TEXT,
  discount_value NUMERIC,
  currency TEXT,
  min_spend NUMERIC,
  category_tags TEXT[],
  image_url TEXT,
  landing_url TEXT NOT NULL DEFAULT '',
  starts_at TIMESTAMPTZ,
  ends_at TIMESTAMPTZ,
  source_url TEXT,
  source TEXT DEFAULT 'IA',
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS ia_promos_dedup_idx ON ia_promos (offer_id, code, landing_url);

CREATE TABLE IF NOT EXISTS ia_promo_deeplinks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  promo_id UUID NOT NULL REFERENCES ia_promos(id) ON DELETE CASCADE,
  deeplink_url TEXT NOT NULL,
  deeplink_type TEXT CHECK (deeplink_type IN ('standard','shoplink')) DEFAULT 'standard',
  aff_sub TEXT DEFAULT '',
  aff_sub2 TEXT DEFAULT '',
  aff_sub3 TEXT DEFAULT '',
  aff_sub4 TEXT DEFAULT '',
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS ia_promo_deeplinks_dedup_idx ON ia_promo_deeplinks (promo_id, aff_sub, aff_sub2, aff_sub3, aff_sub4);

-- Extend deals_feed
ALTER TABLE deals_feed ADD COLUMN IF NOT EXISTS promo_id UUID REFERENCES ia_promos(id) ON DELETE CASCADE;
ALTER TABLE deals_feed ADD COLUMN IF NOT EXISTS has_coupon BOOLEAN DEFAULT false;

CREATE INDEX IF NOT EXISTS deals_feed_coupon_idx ON deals_feed (has_coupon) WHERE has_coupon = true;
CREATE INDEX IF NOT EXISTS ia_promos_ends_idx ON ia_promos (ends_at);

-- RLS policies
ALTER TABLE ia_promos ENABLE ROW LEVEL SECURITY;
ALTER TABLE ia_promo_deeplinks ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS ia_promos_public_read ON ia_promos;
CREATE POLICY ia_promos_public_read ON ia_promos FOR SELECT USING (true);

DROP POLICY IF EXISTS ia_promos_service ON ia_promos;
CREATE POLICY ia_promos_service ON ia_promos FOR ALL USING (auth.role() = 'service_role');

DROP POLICY IF EXISTS ia_promo_deeplinks_service ON ia_promo_deeplinks;
CREATE POLICY ia_promo_deeplinks_service ON ia_promo_deeplinks FOR ALL USING (auth.role() = 'service_role');