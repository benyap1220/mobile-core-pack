-- Add logo tracking columns to ia_advertisers
ALTER TABLE public.ia_advertisers
  ADD COLUMN IF NOT EXISTS logo_source text,
  ADD COLUMN IF NOT EXISTS logo_updated_at timestamptz;

-- Create index for logo backfill queries
CREATE INDEX IF NOT EXISTS ia_advertisers_logo_updated_idx
  ON public.ia_advertisers(logo_updated_at) 
  WHERE logo_url IS NULL OR logo_updated_at IS NOT NULL;