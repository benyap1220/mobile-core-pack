CREATE TABLE IF NOT EXISTS public.ia_promos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  offer_id BIGINT NOT NULL,
  advertiser_name TEXT,
  promo_type TEXT DEFAULT 'coupon',
  promo_id TEXT,
  title TEXT,
  summary TEXT,
  code TEXT,
  discount_type TEXT,
  discount_value NUMERIC,
  currency TEXT DEFAULT 'MYR',
  min_spend NUMERIC,
  category_tags TEXT[],
  image_url TEXT,
  landing_url TEXT NOT NULL,
  starts_at TIMESTAMPTZ,
  ends_at TIMESTAMPTZ,
  source_url TEXT,
  discovered_at TIMESTAMPTZ DEFAULT now(),
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(offer_id, code, landing_url)
);

ALTER TABLE public.deals_feed 
  ADD COLUMN IF NOT EXISTS has_coupon BOOLEAN DEFAULT false,
  ADD COLUMN IF NOT EXISTS primary_promo_id UUID,
  ADD COLUMN IF NOT EXISTS quality_score NUMERIC DEFAULT 0;

CREATE INDEX IF NOT EXISTS idx_ia_promos_offer_id ON public.ia_promos(offer_id);
CREATE INDEX IF NOT EXISTS idx_ia_promos_code ON public.ia_promos(code) WHERE code IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_ia_promos_ends_at ON public.ia_promos(ends_at) WHERE ends_at IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_deals_feed_has_coupon ON public.deals_feed(has_coupon);
CREATE INDEX IF NOT EXISTS idx_deals_feed_offer_id ON public.deals_feed(offer_id);
CREATE INDEX IF NOT EXISTS idx_deals_feed_rotation_batch ON public.deals_feed(rotation_batch);

ALTER TABLE public.ia_promos ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "ia_promos_public_read" ON public.ia_promos;
CREATE POLICY "ia_promos_public_read" ON public.ia_promos FOR SELECT USING (true);

DROP POLICY IF EXISTS "ia_promos_service" ON public.ia_promos;
CREATE POLICY "ia_promos_service" ON public.ia_promos FOR ALL USING (auth.role() = 'service_role');

DROP POLICY IF EXISTS "ia_promos_admin" ON public.ia_promos;
CREATE POLICY "ia_promos_admin" ON public.ia_promos FOR ALL USING (has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "deals_feed_public_read" ON public.deals_feed;
CREATE POLICY "deals_feed_public_read" ON public.deals_feed FOR SELECT USING (true);

DROP POLICY IF EXISTS "aff_clicks_public_insert" ON public.aff_clicks;
CREATE POLICY "aff_clicks_public_insert" ON public.aff_clicks FOR INSERT WITH CHECK (true);

DROP POLICY IF EXISTS "aff_impressions_public_insert" ON public.aff_impressions;
CREATE POLICY "aff_impressions_public_insert" ON public.aff_impressions FOR INSERT WITH CHECK (true);