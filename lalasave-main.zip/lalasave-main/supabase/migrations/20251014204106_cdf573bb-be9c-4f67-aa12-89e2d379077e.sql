-- Schema updates for unique-card deals grid with per-landing coupons

-- Coupons table (promos)
CREATE TABLE IF NOT EXISTS promos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  advertiser_offer_id bigint NOT NULL,
  landing_id uuid,
  source text NOT NULL,
  title text,
  code text,
  benefit text,
  min_spend numeric,
  currency text DEFAULT 'MYR',
  restrictions text,
  starts_at timestamptz,
  ends_at timestamptz,
  image_url text,
  raw_url text,
  created_at timestamptz DEFAULT now()
);

-- Add normalization columns
ALTER TABLE promos
  ADD COLUMN IF NOT EXISTS norm_code text,
  ADD COLUMN IF NOT EXISTS norm_benefit text,
  ADD COLUMN IF NOT EXISTS norm_restrictions text,
  ADD COLUMN IF NOT EXISTS dedup_key text;

-- Create unique index using normalized values
CREATE UNIQUE INDEX IF NOT EXISTS promos_dedup_idx
  ON promos (advertiser_offer_id, LOWER(COALESCE(code, '')), LOWER(COALESCE(benefit, '')), COALESCE(min_spend, 0), LOWER(COALESCE(restrictions, '')));

-- Index for de-duplication queries
CREATE INDEX IF NOT EXISTS promos_offer_norm_idx
  ON promos (advertiser_offer_id, norm_code, norm_benefit);

-- Index for landing lookups
CREATE INDEX IF NOT EXISTS promos_landing_idx
  ON promos (landing_id);

-- Index for active promos
CREATE INDEX IF NOT EXISTS promos_active_idx
  ON promos (advertiser_offer_id, starts_at, ends_at);

-- Add uniqueness key to deals_feed
ALTER TABLE deals_feed
  ADD COLUMN IF NOT EXISTS uniqueness_key text,
  ADD COLUMN IF NOT EXISTS landing_id uuid,
  ADD COLUMN IF NOT EXISTS primary_coupon_id uuid;

-- Index for uniqueness enforcement
CREATE INDEX IF NOT EXISTS deals_feed_unique_rot_idx
  ON deals_feed (rotation_batch, uniqueness_key)
  WHERE uniqueness_key IS NOT NULL;

-- Index for landing joins
CREATE INDEX IF NOT EXISTS deals_feed_landing_idx
  ON deals_feed (landing_id);

-- RLS policies for promos
ALTER TABLE promos ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "promos_public_read" ON promos;
CREATE POLICY "promos_public_read"
  ON promos FOR SELECT
  USING (true);

DROP POLICY IF EXISTS "promos_service_manage" ON promos;
CREATE POLICY "promos_service_manage"
  ON promos FOR ALL
  USING (auth.role() = 'service_role');

DROP POLICY IF EXISTS "promos_admin_manage" ON promos;
CREATE POLICY "promos_admin_manage"
  ON promos FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role));