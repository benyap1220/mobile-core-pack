-- Add logo-related columns to vouchers table
ALTER TABLE public.vouchers
  ADD COLUMN IF NOT EXISTS merchant_domain TEXT,
  ADD COLUMN IF NOT EXISTS logo_source TEXT
    CHECK (logo_source IN ('uploaded','clearbit','favicon','generated','none'))
    DEFAULT 'none',
  ADD COLUMN IF NOT EXISTS logo_cache_updated_at TIMESTAMPTZ;

-- Create private storage bucket for logos
INSERT INTO storage.buckets (id, name, public)
VALUES ('logos', 'logos', false)
ON CONFLICT (id) DO NOTHING;

-- RLS policies for logos bucket
CREATE POLICY "Users can view their own voucher logos"
ON storage.objects FOR SELECT
USING (
  bucket_id = 'logos' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Users can upload their own voucher logos"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'logos' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Users can update their own voucher logos"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'logos' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Users can delete their own voucher logos"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'logos' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

-- Add logo_lookup_enabled to user_settings
ALTER TABLE public.user_settings
  ADD COLUMN IF NOT EXISTS logo_lookup_enabled BOOLEAN DEFAULT true;