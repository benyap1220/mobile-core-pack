-- Add optional fields for merchant logo and location
ALTER TABLE public.vouchers
  ADD COLUMN IF NOT EXISTS merchant_logo_url TEXT,
  ADD COLUMN IF NOT EXISTS location TEXT;