-- Add RLS policies and index for brand_logo_overrides
-- (Table already exists from previous migration)

-- Create index for faster cache lookups
CREATE INDEX IF NOT EXISTS idx_logo_cache_slug ON public.merchant_logo_cache(merchant_slug);

-- Enable RLS on brand_logo_overrides
ALTER TABLE public.brand_logo_overrides ENABLE ROW LEVEL SECURITY;

-- Public read policy
DROP POLICY IF EXISTS "logo_ovr_read" ON public.brand_logo_overrides;
CREATE POLICY "logo_ovr_read" ON public.brand_logo_overrides
  FOR SELECT USING (true);

-- Service role write policy
DROP POLICY IF EXISTS "logo_ovr_write_service" ON public.brand_logo_overrides;
CREATE POLICY "logo_ovr_write_service" ON public.brand_logo_overrides
  FOR ALL USING (auth.role() = 'service_role') 
  WITH CHECK (auth.role() = 'service_role');