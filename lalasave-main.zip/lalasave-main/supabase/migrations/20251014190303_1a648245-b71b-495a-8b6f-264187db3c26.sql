-- Create ia_promos table for coupon/promo enrichment
CREATE TABLE IF NOT EXISTS ia_promos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  offer_id bigint NOT NULL,
  landing_url text NOT NULL,
  code text,
  title text,
  note text,
  valid_from timestamptz,
  valid_until timestamptz,
  image_url text,
  source text,
  discovered_at timestamptz DEFAULT now()
);

-- Create unique index for deduplication
CREATE UNIQUE INDEX IF NOT EXISTS ia_promos_unique_idx 
ON ia_promos (offer_id, landing_url, COALESCE(code, ''), COALESCE(title, ''));

-- Enable RLS
ALTER TABLE ia_promos ENABLE ROW LEVEL SECURITY;

-- Public read access for promos
CREATE POLICY "ia_promos_public_read" ON ia_promos FOR SELECT USING (true);

-- Service role can manage
CREATE POLICY "ia_promos_service" ON ia_promos FOR ALL USING (auth.role() = 'service_role');

-- Admin can manage
CREATE POLICY "ia_promos_admin" ON ia_promos FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));