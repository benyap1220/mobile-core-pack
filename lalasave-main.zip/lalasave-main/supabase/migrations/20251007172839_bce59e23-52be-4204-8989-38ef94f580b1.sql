-- Ensure canonical domain mappings for major brands
insert into public.merchant_domain_map (merchant_slug, domain) values
  ('starbucks', 'starbucks.com'),
  ('mcdonalds', 'mcdonalds.com'),
  ('grab', 'grab.com'),
  ('lazada', 'lazada.com'),
  ('shopee', 'shopee.com'),
  ('foodpanda', 'foodpanda.com'),
  ('temu', 'temu.com'),
  ('amazon', 'amazon.com'),
  ('taobao', 'taobao.com'),
  ('ikea', 'ikea.com'),
  ('kfc', 'kfc.com'),
  ('pizzahut', 'pizzahut.com'),
  ('dominos', 'dominos.com'),
  ('subway', 'subway.com'),
  ('nike', 'nike.com'),
  ('adidas', 'adidas.com'),
  ('uniqlo', 'uniqlo.com'),
  ('zara', 'zara.com'),
  ('hm', 'hm.com'),
  ('sephora', 'sephora.com')
on conflict (merchant_slug) 
do update set 
  domain = excluded.domain,
  updated_at = now();

-- Clear old cache entries to force high-quality logo refresh
truncate table public.merchant_logo_cache;