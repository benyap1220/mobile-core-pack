-- Add layout_mode and safe_area to border_prototypes
ALTER TABLE public.border_prototypes 
ADD COLUMN IF NOT EXISTS layout_mode text DEFAULT 'full-frame',
ADD COLUMN IF NOT EXISTS safe_area jsonb DEFAULT '{"top": 16, "right": 16, "bottom": 16, "left": 16}'::jsonb;

-- Add layout_mode and safe_area to border_styles
ALTER TABLE public.border_styles 
ADD COLUMN IF NOT EXISTS layout_mode text DEFAULT 'full-frame',
ADD COLUMN IF NOT EXISTS safe_area jsonb DEFAULT '{"top": 16, "right": 16, "bottom": 16, "left": 16}'::jsonb;

-- Add check constraint for layout_mode values
ALTER TABLE public.border_prototypes 
ADD CONSTRAINT valid_layout_mode CHECK (
  layout_mode IN ('full-frame', 'right-rail', 'left-rail', 'top-rail', 'bottom-rail', 'corners')
);

ALTER TABLE public.border_styles 
ADD CONSTRAINT valid_layout_mode_styles CHECK (
  layout_mode IN ('full-frame', 'right-rail', 'left-rail', 'top-rail', 'bottom-rail', 'corners')
);