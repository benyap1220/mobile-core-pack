-- Migrate any existing merchant_logo_url values to merchant_logo_path
UPDATE public.vouchers
SET merchant_logo_path = merchant_logo_url
WHERE merchant_logo_url IS NOT NULL 
  AND merchant_logo_path IS NULL;

-- Drop the old merchant_logo_url column
ALTER TABLE public.vouchers
DROP COLUMN IF EXISTS merchant_logo_url;