-- Security fix: User roles system for admin authorization
CREATE TYPE public.app_role AS ENUM ('admin', 'moderator', 'user');

CREATE TABLE public.user_roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    role app_role NOT NULL,
    created_at TIMESTAMPTZ DEFAULT now(),
    UNIQUE (user_id, role)
);

-- Enable RLS on user_roles
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Security definer function to check roles (prevents RLS recursion)
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;

-- Allow users to view their own roles
CREATE POLICY "Users can view their own roles"
ON public.user_roles
FOR SELECT
USING (user_id = auth.uid());

-- Only admins can manage roles
CREATE POLICY "Admins can manage all roles"
ON public.user_roles
FOR ALL
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Security fix: Merchant logo cache requires authentication
ALTER TABLE public.merchant_logo_cache ENABLE ROW LEVEL SECURITY;

-- Drop the overly permissive policies and create secure ones
DROP POLICY IF EXISTS "logo_cache_read_all" ON public.merchant_logo_cache;
DROP POLICY IF EXISTS "logo_cache_write" ON public.merchant_logo_cache;
DROP POLICY IF EXISTS "logo_cache_update" ON public.merchant_logo_cache;

-- Allow authenticated users to read cache
CREATE POLICY "Authenticated users can read logo cache"
ON public.merchant_logo_cache
FOR SELECT
TO authenticated
USING (true);

-- Only edge functions (service role) can write to cache
-- Client users cannot directly modify cache
CREATE POLICY "Service role can write logo cache"
ON public.merchant_logo_cache
FOR INSERT
TO service_role
WITH CHECK (true);

CREATE POLICY "Service role can update logo cache"
ON public.merchant_logo_cache
FOR UPDATE
TO service_role
USING (true);

-- Security fix: Affiliate clicks should validate user
DROP POLICY IF EXISTS "clicks_public_insert" ON public.affiliate_clicks;

CREATE POLICY "Authenticated or service role can log clicks"
ON public.affiliate_clicks
FOR INSERT
WITH CHECK (
  auth.role() = 'authenticated' OR 
  auth.role() = 'service_role'
);

-- Security fix: Resolve storage policy conflicts
-- Drop conflicting permissive policies from migration 20251006190943
DROP POLICY IF EXISTS "logos_read_all" ON storage.objects;
DROP POLICY IF EXISTS "logos_insert_authenticated" ON storage.objects;
DROP POLICY IF EXISTS "logos_update_authenticated" ON storage.objects;
DROP POLICY IF EXISTS "logos_delete_authenticated" ON storage.objects;

-- Keep only the secure user-scoped policies from migration 20251006155845
-- These policies enforce that users can only access their own logos via folder structure
-- Policies already exist: "Users can view their own voucher logos", etc.

-- Allow service role to manage all logos (for edge functions)
CREATE POLICY "Service role can manage all logos"
ON storage.objects
FOR ALL
TO service_role
USING (bucket_id = 'logos')
WITH CHECK (bucket_id = 'logos');