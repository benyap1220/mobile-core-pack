-- Ensure lazada domain mapping exists
INSERT INTO public.merchant_domain_map(merchant_slug, domain)
VALUES ('lazada', 'lazada.com')
ON CONFLICT (merchant_slug) 
DO UPDATE SET domain = EXCLUDED.domain, updated_at = now();

-- Clean up any bad Lazada cache entries
DELETE FROM public.merchant_logo_cache 
WHERE merchant_slug = 'lazada' 
  OR public_url LIKE '%logistics%' 
  OR public_url LIKE '%lex%';