-- Enable pgcrypto for UUID generation
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Create enum types
CREATE TYPE public.deal_type AS ENUM ('percentage', 'amount', 'bogo', 'other');
CREATE TYPE public.category_type AS ENUM ('food', 'fitness', 'travel', 'other');
CREATE TYPE public.source_type AS ENUM ('upload', 'screencap', 'video', 'email', 'manual');
CREATE TYPE public.status_type AS ENUM ('active', 'used', 'expired');

-- Create vouchers table
CREATE TABLE IF NOT EXISTS public.vouchers (
  voucher_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  merchant TEXT NOT NULL,
  deal_type public.deal_type DEFAULT 'other',
  value NUMERIC,
  currency TEXT DEFAULT 'MYR',
  category public.category_type DEFAULT 'other',
  expiry_date DATE,
  valid_from DATE,
  conditions TEXT DEFAULT '',
  tags TEXT[] DEFAULT ARRAY[]::TEXT[],
  source public.source_type DEFAULT 'upload',
  status public.status_type DEFAULT 'active',
  raw_text TEXT DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create voucher_assets table
CREATE TABLE IF NOT EXISTS public.voucher_assets (
  asset_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  voucher_id UUID NOT NULL REFERENCES public.vouchers(voucher_id) ON DELETE CASCADE,
  file_url TEXT NOT NULL,
  file_path TEXT NOT NULL,
  file_type TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create audit_log table
CREATE TABLE IF NOT EXISTS public.audit_log (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  voucher_id UUID REFERENCES public.vouchers(voucher_id) ON DELETE CASCADE,
  action TEXT NOT NULL,
  details JSONB DEFAULT '{}'::JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create user_settings table for preferences
CREATE TABLE IF NOT EXISTS public.user_settings (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  push_enabled BOOLEAN DEFAULT true,
  email_enabled BOOLEAN DEFAULT true,
  whatsapp_enabled BOOLEAN DEFAULT false,
  locale TEXT DEFAULT 'ms-MY',
  currency TEXT DEFAULT 'MYR',
  gmail_connected BOOLEAN DEFAULT false,
  gmail_refresh_token TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS TRIGGER 
LANGUAGE plpgsql 
AS $$
BEGIN 
  NEW.updated_at = now(); 
  RETURN NEW; 
END;
$$;

-- Add triggers for updated_at
DROP TRIGGER IF EXISTS trg_vouchers_updated_at ON public.vouchers;
CREATE TRIGGER trg_vouchers_updated_at
BEFORE UPDATE ON public.vouchers
FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

DROP TRIGGER IF EXISTS trg_user_settings_updated_at ON public.user_settings;
CREATE TRIGGER trg_user_settings_updated_at
BEFORE UPDATE ON public.user_settings
FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Enable Row Level Security
ALTER TABLE public.vouchers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.voucher_assets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_settings ENABLE ROW LEVEL SECURITY;

-- RLS Policies for vouchers (owner read/write)
CREATE POLICY "vouchers_owner_rw" ON public.vouchers
FOR ALL USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

-- RLS Policies for voucher_assets (owner read/write via voucher ownership)
CREATE POLICY "assets_owner_rw" ON public.voucher_assets
FOR ALL USING (
  EXISTS (SELECT 1 FROM public.vouchers v WHERE v.voucher_id = voucher_assets.voucher_id AND v.user_id = auth.uid())
) WITH CHECK (
  EXISTS (SELECT 1 FROM public.vouchers v WHERE v.voucher_id = voucher_assets.voucher_id AND v.user_id = auth.uid())
);

-- RLS Policies for audit_log (owner read only)
CREATE POLICY "audit_owner_read" ON public.audit_log
FOR SELECT USING (user_id = auth.uid());

-- RLS Policies for user_settings (owner read/write)
CREATE POLICY "settings_owner_rw" ON public.user_settings
FOR ALL USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

-- Create storage bucket for voucher images
INSERT INTO storage.buckets (id, name, public)
VALUES ('voucher-images', 'voucher-images', false)
ON CONFLICT (id) DO NOTHING;

-- Storage RLS policies (owner access only via path structure)
CREATE POLICY "voucher_images_owner_select" ON storage.objects
FOR SELECT USING (
  bucket_id = 'voucher-images' AND 
  auth.uid()::TEXT = (storage.foldername(name))[1]
);

CREATE POLICY "voucher_images_owner_insert" ON storage.objects
FOR INSERT WITH CHECK (
  bucket_id = 'voucher-images' AND 
  auth.uid()::TEXT = (storage.foldername(name))[1]
);

CREATE POLICY "voucher_images_owner_update" ON storage.objects
FOR UPDATE USING (
  bucket_id = 'voucher-images' AND 
  auth.uid()::TEXT = (storage.foldername(name))[1]
);

CREATE POLICY "voucher_images_owner_delete" ON storage.objects
FOR DELETE USING (
  bucket_id = 'voucher-images' AND 
  auth.uid()::TEXT = (storage.foldername(name))[1]
);

-- Function to auto-create user settings on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.user_settings (user_id)
  VALUES (NEW.id);
  RETURN NEW;
END;
$$;

-- Trigger to create user settings on signup
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();