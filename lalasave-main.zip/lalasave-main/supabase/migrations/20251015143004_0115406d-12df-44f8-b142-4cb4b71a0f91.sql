-- Clear merchant logo cache for fresh start
DELETE FROM merchant_logo_cache;