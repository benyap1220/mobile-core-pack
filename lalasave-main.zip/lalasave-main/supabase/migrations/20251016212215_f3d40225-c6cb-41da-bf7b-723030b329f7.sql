-- Add promo_fingerprint column for de-duplication
ALTER TABLE deals_feed
  ADD COLUMN IF NOT EXISTS promo_fingerprint text,
  ADD COLUMN IF NOT EXISTS deal_key text;

-- Create indices for fast de-duplication and quality filtering
CREATE INDEX IF NOT EXISTS deals_feed_brand_dedup_idx
  ON deals_feed (platform, promo_fingerprint, created_at DESC);

CREATE INDEX IF NOT EXISTS deals_feed_quality_idx
  ON deals_feed (has_coupon, score DESC, expires_at);

CREATE INDEX IF NOT EXISTS deals_feed_platform_score_idx
  ON deals_feed (platform, score DESC, created_at DESC);