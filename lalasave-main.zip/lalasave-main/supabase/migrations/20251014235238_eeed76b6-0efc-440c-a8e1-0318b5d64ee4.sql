-- Clear stale logo cache to force fresh resolution
TRUNCATE TABLE merchant_logo_cache;