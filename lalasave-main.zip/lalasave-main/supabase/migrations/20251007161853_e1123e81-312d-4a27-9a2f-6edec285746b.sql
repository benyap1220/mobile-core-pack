-- Border management system tables
CREATE TABLE IF NOT EXISTS public.border_prototypes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT,
  source_path TEXT NOT NULL,
  preview_path TEXT,
  svg_path TEXT,
  webm_path TEXT,
  lottie_path TEXT,
  style_tag TEXT,
  submitted_by UUID REFERENCES auth.users(id),
  quality_score NUMERIC,
  notes TEXT,
  is_approved BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.border_styles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT,
  style_tag TEXT,
  svg_path TEXT,
  webm_path TEXT,
  lottie_path TEXT,
  preview_path TEXT,
  approved_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.border_prototypes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.border_styles ENABLE ROW LEVEL SECURITY;

-- Border prototypes policies (admins only)
CREATE POLICY "Admins can manage border prototypes"
ON public.border_prototypes
FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Border styles policies (authenticated users can read, admins can write)
CREATE POLICY "Anyone can view approved border styles"
ON public.border_styles
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Admins can manage border styles"
ON public.border_styles
FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Add border_style_id columns to existing tables
ALTER TABLE public.affiliate_offers 
  ADD COLUMN IF NOT EXISTS border_style_id UUID REFERENCES public.border_styles(id);

ALTER TABLE public.vouchers 
  ADD COLUMN IF NOT EXISTS border_style_id UUID REFERENCES public.border_styles(id);

-- Create storage buckets for borders
INSERT INTO storage.buckets (id, name, public)
VALUES 
  ('borders', 'borders', true),
  ('borders_previews', 'borders_previews', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for borders (public read, service role write)
CREATE POLICY "Public can view borders"
ON storage.objects
FOR SELECT
USING (bucket_id = 'borders');

CREATE POLICY "Service role can manage borders"
ON storage.objects
FOR ALL
TO service_role
USING (bucket_id = 'borders')
WITH CHECK (bucket_id = 'borders');

CREATE POLICY "Public can view border previews"
ON storage.objects
FOR SELECT
USING (bucket_id = 'borders_previews');

CREATE POLICY "Service role can manage border previews"
ON storage.objects
FOR ALL
TO service_role
USING (bucket_id = 'borders_previews')
WITH CHECK (bucket_id = 'borders_previews');