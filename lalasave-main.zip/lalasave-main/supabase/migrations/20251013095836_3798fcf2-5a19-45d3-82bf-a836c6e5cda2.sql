-- Add rotation_batch to deals_feed for 48h rotations
ALTER TABLE deals_feed ADD COLUMN IF NOT EXISTS rotation_batch date;

-- Add promo_notes table for manual promo content
CREATE TABLE IF NOT EXISTS promo_notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  deal_id uuid NOT NULL REFERENCES deals_feed(id) ON DELETE CASCADE,
  coupon_code text,
  notes text,
  valid_from date,
  valid_until date,
  created_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid REFERENCES auth.users(id)
);

-- Enable RLS on promo_notes
ALTER TABLE promo_notes ENABLE ROW LEVEL SECURITY;

-- Public can read promo notes
CREATE POLICY "promo_notes_public_read" ON promo_notes
  FOR SELECT USING (true);

-- Admins can manage promo notes
CREATE POLICY "promo_notes_admin_manage" ON promo_notes
  FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));

-- Add index for rotation queries
CREATE INDEX IF NOT EXISTS deals_feed_rotation_idx ON deals_feed (rotation_batch, score DESC, created_at DESC);

-- Add deeplink_type to ia_deeplinks for shoplink tracking
ALTER TABLE ia_deeplinks ADD COLUMN IF NOT EXISTS deeplink_type text DEFAULT 'standard';

-- Add platform_priority to ia_advertisers
ALTER TABLE ia_advertisers ADD COLUMN IF NOT EXISTS platform_priority numeric DEFAULT 0;