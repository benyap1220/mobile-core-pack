import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    const url = new URL(req.url);
    // Extract deeplink_id from path: /go-deeplink/:deeplink_id
    const pathParts = url.pathname.split('/');
    const deeplinkId = pathParts[pathParts.length - 1];
    const pos = url.searchParams.get('pos') || 'unknown';

    if (!deeplinkId) {
      return new Response('Missing deeplink_id', { status: 400, headers: corsHeaders });
    }

    console.log(`🔗 Processing deeplink: ${deeplinkId}, pos: ${pos}`);

    // Fetch deal by deeplink_id
    const { data: deal } = await supabase
      .from('deals_feed')
      .select('deeplink_id, offer_id, promo_id, landing_id, source')
      .eq('deeplink_id', deeplinkId)
      .maybeSingle();

    if (!deal) {
      console.error(`❌ No deal found for deeplink_id: ${deeplinkId}`);
      return new Response('Deal not found', { status: 404, headers: corsHeaders });
    }

    // Get deeplink - check promo_deeplinks first, then ia_deeplinks
    let deeplinkUrl = null;
    
    if (deal.deeplink_id) {
      // Try promo_deeplinks first
      const { data: promoDeeplink } = await supabase
        .from('ia_promo_deeplinks')
        .select('deeplink_url')
        .eq('id', deal.deeplink_id)
        .maybeSingle();
      
      if (promoDeeplink) {
        deeplinkUrl = promoDeeplink.deeplink_url;
      } else {
        // Fallback to ia_deeplinks
        const { data: deeplink } = await supabase
          .from('ia_deeplinks')
          .select('deeplink_url')
          .eq('id', deal.deeplink_id)
          .maybeSingle();
        
        if (deeplink) {
          deeplinkUrl = deeplink.deeplink_url;
        }
      }
    }

    // If no deeplink, try to generate one (for promo or landing)
    if (!deeplinkUrl && (deal.promo_id || deal.landing_id)) {
      const payload: any = {
        offer_id: deal.offer_id,
        aff_sub: 'dealsgrid',
        aff_sub2: `card_${pos}`,
        aff_sub3: String(deal.offer_id),
        aff_sub4: 'redirect',
      };

      if (deal.promo_id) {
        // Get promo landing URL
        const { data: promo } = await supabase
          .from('ia_promos')
          .select('landing_url')
          .eq('id', deal.promo_id)
          .single();
        
        if (promo) {
          payload.promo_id = deal.promo_id;
          payload.raw_url = promo.landing_url;
        }
      } else if (deal.landing_id) {
        // Get landing URL
        const { data: landing } = await supabase
          .from('ia_landings')
          .select('url')
          .eq('id', deal.landing_id)
          .single();
        
        if (landing) {
          payload.landing_id = deal.landing_id;
          payload.raw_url = landing.url;
        }
      }

      if (payload.raw_url) {
        const { data: genData } = await supabase.functions.invoke('ia-deeplink-generate', {
          body: payload
        });

        if (genData?.deeplink_url) {
          deeplinkUrl = genData.deeplink_url;
        }
      }
    }

    // Fallback to promo or landing URL directly
    if (!deeplinkUrl) {
      if (deal.promo_id) {
        const { data: promo } = await supabase
          .from('ia_promos')
          .select('landing_url')
          .eq('id', deal.promo_id)
          .single();
        
        if (promo) deeplinkUrl = promo.landing_url;
      } else if (deal.landing_id) {
        const { data: landing } = await supabase
          .from('ia_landings')
          .select('url')
          .eq('id', deal.landing_id)
          .single();
        
        if (landing) deeplinkUrl = landing.url;
      }
    }

    if (!deeplinkUrl) {
      console.error(`❌ No redirect URL found for deeplink_id: ${deeplinkId}`);
      return new Response('No redirect URL found', { status: 404, headers: corsHeaders });
    }

    console.log(`✅ Redirecting to: ${deeplinkUrl}`);

    // Log click
    console.log(`📊 Logging click: offer_id=${deal.offer_id}, pos=${pos}`);
    await supabase.from('aff_clicks').insert({
      offer_id: deal.offer_id,
      deeplink_id: deal.deeplink_id,
      aff_sub: 'dealsgrid',
      aff_sub2: pos,
      aff_sub3: String(deal.offer_id),
      aff_sub4: deal.source || 'IA',
    });

    // 302 redirect
    return new Response(null, {
      status: 302,
      headers: {
        ...corsHeaders,
        'Location': deeplinkUrl,
      },
    });
  } catch (error) {
    console.error('❌ go-deeplink error:', error);
    return new Response(
      JSON.stringify({ error: String(error) }), 
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
