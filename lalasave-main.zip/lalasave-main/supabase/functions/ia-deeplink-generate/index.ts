import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Token bucket for rate limiting (20 requests/min)
class TokenBucket {
  private tokens: number;
  private lastRefill: number;
  private readonly capacity = 20;
  private readonly refillRate = 20 / 60000; // 20 tokens per minute

  constructor() {
    this.tokens = this.capacity;
    this.lastRefill = Date.now();
  }

  async acquire(): Promise<void> {
    const now = Date.now();
    const elapsed = now - this.lastRefill;
    this.tokens = Math.min(this.capacity, this.tokens + elapsed * this.refillRate);
    this.lastRefill = now;

    if (this.tokens >= 1) {
      this.tokens -= 1;
      return;
    }

    // Wait until we have a token
    const waitTime = (1 - this.tokens) / this.refillRate;
    await new Promise(resolve => setTimeout(resolve, waitTime));
    this.tokens = 0;
  }
}

const rateLimiter = new TokenBucket();

// Helper: get or create promo deeplink
async function getOrCreatePromoDeeplink(
  supabase: any,
  promoId: string,
  offerId: number,
  landingUrl: string,
  subs: { aff_sub?: string; aff_sub2?: string; aff_sub3?: string; aff_sub4?: string } = {}
) {
  const { aff_sub = '', aff_sub2 = '', aff_sub3 = '', aff_sub4 = '' } = subs;

  // Check cache
  const { data: cached } = await supabase
    .from('ia_deeplinks')
    .select('*')
    .eq('offer_id', offerId)
    .eq('raw_url', landingUrl)
    .eq('aff_sub', aff_sub)
    .eq('aff_sub2', aff_sub2)
    .eq('aff_sub3', aff_sub3)
    .eq('aff_sub4', aff_sub4)
    .maybeSingle();

  if (cached) {
    return { deeplink_url: cached.deeplink_url, deeplink_type: cached.deeplink_type, deeplink_id: cached.id };
  }

  // Generate new
  const iaApiKey = Deno.env.get('IA_API_KEY')!;
  const iaApiSecret = Deno.env.get('IA_API_SECRET')!;
  const iaBaseUrl = Deno.env.get('IA_API_BASE_URL') || 'https://api.involve.asia';

  const authRes = await fetch(`${iaBaseUrl}/api/authenticate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ key: iaApiKey, secret: iaApiSecret }),
  });

  const { data: authData } = await authRes.json();
  const token = authData?.token;

  await rateLimiter.acquire();

  const deeplinkRes = await fetch(`${iaBaseUrl}/api/deeplink/generate`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      offer_id: offerId,
      url: landingUrl,
      aff_sub,
      aff_sub2,
      aff_sub3,
      aff_sub4,
    }),
  });

  let deeplinkUrl = '';
  let deeplinkType = 'standard';

  if (deeplinkRes.ok) {
    const data = await deeplinkRes.json();
    deeplinkUrl = data.deeplink_url || data.url || '';
    deeplinkType = 'standard';
  } else {
    // Fallback to shoplink
    const params = new URLSearchParams({ 
      offer_id: offerId.toString(),
      url: landingUrl,
      aff_sub, aff_sub2, aff_sub3, aff_sub4 
    });
    deeplinkUrl = `https://invol.co/aff_m?${params.toString()}`;
    deeplinkType = 'shoplink';
  }

  // Cache the deeplink (30 days expiry)
  const expiresAt = new Date();
  expiresAt.setDate(expiresAt.getDate() + 30);

  const { data: inserted } = await supabase
    .from('ia_deeplinks')
    .insert({
      offer_id: offerId,
      raw_url: landingUrl,
      deeplink_url: deeplinkUrl,
      deeplink_type: deeplinkType,
      aff_sub,
      aff_sub2,
      aff_sub3,
      aff_sub4,
      expires_at: expiresAt.toISOString(),
    })
    .select()
    .single();

  return { deeplink_url: deeplinkUrl, deeplink_type: deeplinkType, deeplink_id: inserted.id };
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const iaApiKey = Deno.env.get('IA_API_KEY')!;
    const iaApiSecret = Deno.env.get('IA_API_SECRET')!;
    const iaDeeplinkUrl = Deno.env.get('IA_DEEPLINK_API_URL') || 'https://api.involve.asia/api/deeplink/generate';

    const supabase = createClient(supabaseUrl, supabaseKey);

    const { offer_id, raw_url, promo_id, landing_id, subs, aff_sub, aff_sub2, aff_sub3, aff_sub4 } = await req.json();

    // If promo_id provided, use promo deeplink helper
    if (promo_id) {
      const result = await getOrCreatePromoDeeplink(
        supabase,
        promo_id,
        offer_id,
        raw_url,
        { aff_sub, aff_sub2, aff_sub3, aff_sub4 }
      );
      return new Response(JSON.stringify(result), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Authenticate with IA API to get token
    const authResponse = await fetch('https://api.involve.asia/api/authenticate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ key: iaApiKey, secret: iaApiSecret }),
    });

    if (!authResponse.ok) {
      const errorText = await authResponse.text();
      console.error('IA Authentication failed:', authResponse.status, errorText);
      return new Response(
        JSON.stringify({ 
          ok: false,
          where: 'ia-deeplink-generate.authenticate',
          error: `IA Authentication failed: ${authResponse.status}`,
          details: errorText.substring(0, 300),
        }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const authData = await authResponse.json();
    const token = authData?.data?.token;

    if (!token) {
      console.error('No token in auth response:', authData);
      return new Response(
        JSON.stringify({ 
          ok: false,
          where: 'ia-deeplink-generate.authenticate',
          error: 'No token received from IA API',
        }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('IA Authentication successful');

    // Original flow (non-promo)
    if (!offer_id || !raw_url) {
      return new Response(
        JSON.stringify({ error: 'offer_id and raw_url are required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const subAff = subs?.sub1 || aff_sub || '';
    const subAff2 = subs?.sub2 || aff_sub2 || '';
    const subAff3 = subs?.sub3 || aff_sub3 || '';
    const subAff4 = subs?.sub4 || aff_sub4 || '';

    // Check cache first
    const { data: existing } = await supabase
      .from('ia_deeplinks')
      .select('*')
      .eq('offer_id', offer_id)
      .eq('raw_url', raw_url)
      .eq('aff_sub', subAff)
      .eq('aff_sub2', subAff2)
      .eq('aff_sub3', subAff3)
      .eq('aff_sub4', subAff4)
      .maybeSingle();

    if (existing) {
      console.log(`Using cached deeplink (type: ${existing.deeplink_type})`);
      return new Response(
        JSON.stringify({ 
          deeplink_url: existing.deeplink_url, 
          deeplink_id: existing.id,
          deeplink_type: existing.deeplink_type,
          cached: true,
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get advertiser info for fallback tracking_link
    const { data: advertiser } = await supabase
      .from('ia_advertisers')
      .select('tracking_link')
      .eq('offer_id', offer_id)
      .maybeSingle();

    // STRATEGY 1: Try Deeplink API (Primary)
    await rateLimiter.acquire();
    console.log('Strategy 1: Attempting deeplink API...');

    const iaHeaders: Record<string, string> = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
    };

    const iaResponse = await fetch(iaDeeplinkUrl, {
      method: 'POST',
      headers: iaHeaders,
      body: JSON.stringify({
        offer_id,
        url: raw_url,
        aff_sub: subAff,
        aff_sub2: subAff2,
        aff_sub3: subAff3,
        aff_sub4: subAff4,
      }),
    });

    let deeplinkUrl: string | null = null;
    let deeplinkType = 'standard';
    let fallbackReason: string | null = null;

    if (iaResponse.ok) {
      const iaData = await iaResponse.json();
      deeplinkUrl = iaData.deeplink_url || iaData.url;
      
      if (deeplinkUrl) {
        console.log('Strategy 1 SUCCESS: Deeplink API returned URL');
      }
    } else {
      const errorText = await iaResponse.text();
      console.log(`Strategy 1 FAILED: ${iaResponse.status} - ${errorText.substring(0, 100)}`);
      fallbackReason = `deeplink-api-${iaResponse.status}`;
    }

    // STRATEGY 2: Fallback A - Use tracking_link from advertiser
    if (!deeplinkUrl && advertiser?.tracking_link) {
      console.log('Strategy 2: Using advertiser tracking_link...');
      const trackingLink = advertiser.tracking_link;
      
      try {
        const trackingUrl = new URL(trackingLink);
        
        // Try to append deep target if invol.co supports it
        if (trackingUrl.hostname.includes('invol.co') || trackingUrl.hostname.includes('involve.asia')) {
          // Check if it already has a url parameter
          if (!trackingUrl.searchParams.has('url')) {
            trackingUrl.searchParams.set('url', raw_url);
          }
        }
        
        // Append SubIDs (safe for invol.co links)
        if (subAff) trackingUrl.searchParams.set('aff_sub', subAff);
        if (subAff2) trackingUrl.searchParams.set('aff_sub2', subAff2);
        if (subAff3) trackingUrl.searchParams.set('aff_sub3', subAff3);
        if (subAff4) trackingUrl.searchParams.set('aff_sub4', subAff4);
        
        deeplinkUrl = trackingUrl.toString();
        deeplinkType = 'shoplink';
        console.log('Strategy 2 SUCCESS: Built shoplink from tracking_link');
      } catch (e) {
        console.log('Strategy 2 FAILED: Invalid tracking_link URL');
      }
    }

    // STRATEGY 3: Fallback B - Generic invol.co link
    if (!deeplinkUrl) {
      console.log('Strategy 3: Building generic invol.co link...');
      const genericUrl = new URL('https://invol.co/aff_m');
      genericUrl.searchParams.set('offer_id', String(offer_id));
      
      if (subAff) genericUrl.searchParams.set('aff_sub', subAff);
      if (subAff2) genericUrl.searchParams.set('aff_sub2', subAff2);
      if (subAff3) genericUrl.searchParams.set('aff_sub3', subAff3);
      if (subAff4) genericUrl.searchParams.set('aff_sub4', subAff4);
      
      deeplinkUrl = genericUrl.toString();
      deeplinkType = 'shoplink';
      fallbackReason = fallbackReason || 'no-tracking-link';
      console.log('Strategy 3 SUCCESS: Built generic shoplink');
    }

    if (!deeplinkUrl) {
      return new Response(
        JSON.stringify({
          ok: false,
          where: 'ia-deeplink-generate.allStrategiesFailed',
          error: 'All deeplink generation strategies failed',
        }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Cache the deeplink (30 days expiry)
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 30);

    const { data: inserted, error: insertError } = await supabase
      .from('ia_deeplinks')
      .insert({
        offer_id,
        landing_id,
        raw_url,
        deeplink_url: deeplinkUrl,
        deeplink_type: deeplinkType,
        aff_sub: subAff,
        aff_sub2: subAff2,
        aff_sub3: subAff3,
        aff_sub4: subAff4,
        expires_at: expiresAt.toISOString(),
      })
      .select()
      .single();

    if (insertError) {
      console.error('Error caching deeplink:', insertError);
      // Return deeplink even if caching fails
      return new Response(
        JSON.stringify({ 
          deeplink_url: deeplinkUrl, 
          deeplink_id: null,
          deeplink_type: deeplinkType,
          fallback_reason: fallbackReason,
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`✅ Deeplink generated (type: ${deeplinkType}${fallbackReason ? `, reason: ${fallbackReason}` : ''})`);

    return new Response(
      JSON.stringify({ 
        deeplink_url: deeplinkUrl, 
        deeplink_id: inserted.id,
        deeplink_type: deeplinkType,
        fallback_reason: fallbackReason,
        cached: false,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error generating deeplink:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    const errorDetails = error instanceof Error ? error.toString() : String(error);

    return new Response(
      JSON.stringify({ 
        ok: false,
        where: 'ia-deeplink-generate.catch',
        error: errorMessage,
        details: errorDetails,
      }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
