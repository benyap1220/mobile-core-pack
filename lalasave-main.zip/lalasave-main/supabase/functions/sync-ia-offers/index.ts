import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const iaApiKey = Deno.env.get('IA_API_KEY')!;
    const iaApiSecret = Deno.env.get('IA_API_SECRET')!;
    const iaBaseUrl = Deno.env.get('IA_API_BASE_URL') || 'https://api.involve.asia';

    const supabase = createClient(supabaseUrl, supabaseKey);

    console.log('Fetching offers from Involve Asia API...');

    // Fetch offers from Involve Asia
    const iaResponse = await fetch(`${iaBaseUrl}/merchants/offers`, {
      headers: {
        'X-API-Key': iaApiKey,
        'X-API-Secret': iaApiSecret,
        'Content-Type': 'application/json',
      },
    });

    if (!iaResponse.ok) {
      const errorText = await iaResponse.text();
      console.error('IA API Error:', iaResponse.status, errorText);
      throw new Error(`Involve Asia API error: ${iaResponse.status} - ${errorText}`);
    }

    const iaData = await iaResponse.json();
    console.log(`Fetched ${iaData.data?.length || 0} offers from IA`);

    if (!iaData.data || !Array.isArray(iaData.data)) {
      throw new Error('Invalid response format from Involve Asia API');
    }

    // Transform IA offers to our format
    const offers = iaData.data.map((offer: any) => ({
      platform: 'involveasia',
      merchant: offer.merchant_name || offer.advertiser_name || 'Unknown',
      offer_title: offer.title || offer.name || 'Special Offer',
      offer_summary: offer.description || null,
      terms: offer.terms || null,
      coupon_code: offer.code || null,
      deep_link: offer.tracking_link || offer.url || '',
      logo_path: null, // Will be resolved by logo-resolver
      region: offer.region || 'MY',
      category: mapCategory(offer.category),
      expiry_date: offer.end_date ? new Date(offer.end_date).toISOString().split('T')[0] : null,
      is_active: true,
      tracking_source: 'involveasia',
    }));

    // Upsert offers to database
    const { data: inserted, error: insertError } = await supabase
      .from('affiliate_offers')
      .upsert(offers, { 
        onConflict: 'deep_link',
        ignoreDuplicates: false 
      })
      .select();

    if (insertError) {
      console.error('Database insert error:', insertError);
      throw insertError;
    }

    console.log(`Successfully synced ${inserted?.length || 0} offers`);

    return new Response(
      JSON.stringify({
        success: true,
        synced: inserted?.length || 0,
        message: `Synced ${inserted?.length || 0} offers from Involve Asia`,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error syncing IA offers:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    const errorDetails = error instanceof Error ? error.toString() : String(error);
    
    return new Response(
      JSON.stringify({ 
        error: errorMessage,
        details: errorDetails
      }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});

function mapCategory(iaCategory: string | null): string {
  if (!iaCategory) return 'marketplace';
  
  const categoryMap: Record<string, string> = {
    'ecommerce': 'marketplace',
    'marketplace': 'marketplace',
    'food': 'fooddelivery',
    'delivery': 'fooddelivery',
    'ride': 'ehailing',
    'transport': 'ehailing',
    'travel': 'travel',
    'fashion': 'marketplace',
    'electronics': 'marketplace',
  };

  const normalized = iaCategory.toLowerCase();
  for (const [key, value] of Object.entries(categoryMap)) {
    if (normalized.includes(key)) return value;
  }
  
  return 'marketplace';
}
