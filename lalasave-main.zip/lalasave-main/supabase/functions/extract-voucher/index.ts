import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Input validation schema
const RequestSchema = z.object({
  voucherId: z.string().uuid({ message: "Invalid voucher ID format" }),
});

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const body = await req.json();
    
    // Validate input
    const validation = RequestSchema.safeParse(body);
    if (!validation.success) {
      console.error("Validation error:", validation.error.format());
      return new Response(
        JSON.stringify({ error: "Invalid request data" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    
    const { voucherId } = validation.data;

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const lovableApiKey = Deno.env.get("LOVABLE_API_KEY")!;
    
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Get voucher assets
    const { data: assets, error: assetsError } = await supabase
      .from("voucher_assets")
      .select("*")
      .eq("voucher_id", voucherId);

    if (assetsError) {
      console.error("Assets fetch error:", assetsError.message);
      throw new Error("Failed to fetch assets");
    }

    if (!assets || assets.length === 0) {
      return new Response(
        JSON.stringify({ error: "No assets found for voucher" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Get signed URL for first asset
    const { data: signedData, error: signedError } = await supabase.storage
      .from("voucher-images")
      .createSignedUrl(assets[0].file_path, 3600);

    if (signedError || !signedData?.signedUrl) {
      console.error("Signed URL error:", signedError?.message || "No URL");
      return new Response(
        JSON.stringify({ error: "Failed to generate signed URL for asset" }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Call Lovable AI for OCR
    const aiResponse = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${lovableApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          {
            role: "user",
            content: [
              { 
                type: "text", 
                text: `Extract voucher data and return ONLY valid JSON with this structure:
{
  "merchant": "string",
  "deal_type": "percentage" | "amount" | "bogo" | "other",
  "value": number or null,
  "currency": "MYR" or other,
  "expiry_date": "YYYY-MM-DD" or null,
  "valid_from": "YYYY-MM-DD" or null,
  "conditions": "string",
  "tags": ["array", "of", "strings"]
}

Only include what you can clearly read. Use null for missing values.` 
              },
              { type: "image_url", image_url: { url: signedData.signedUrl } }
            ]
          }
        ],
      }),
    });

    if (!aiResponse.ok) {
      console.error("AI API error:", aiResponse.status, aiResponse.statusText);
      
      if (aiResponse.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again later." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      
      if (aiResponse.status === 402) {
        return new Response(
          JSON.stringify({ error: "AI credits exhausted. Please add credits." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      throw new Error("AI API request failed");
    }

    const aiData = await aiResponse.json();
    const contentText = aiData.choices?.[0]?.message?.content || "{}";
    
    // Parse JSON from response
    let extracted;
    try {
      const jsonMatch = contentText.match(/\{[\s\S]*\}/);
      extracted = JSON.parse(jsonMatch ? jsonMatch[0] : contentText);
    } catch (parseError) {
      console.error("JSON parse error:", parseError instanceof Error ? parseError.message : "Unknown");
      extracted = {
        merchant: "Manual review needed",
        deal_type: "other",
      };
    }

    // Update voucher
    const { error: updateError } = await supabase.from("vouchers").update({
      merchant: extracted.merchant || "Unknown",
      deal_type: extracted.deal_type || "other",
      value: extracted.value,
      currency: extracted.currency || "MYR",
      expiry_date: extracted.expiry_date,
      valid_from: extracted.valid_from,
      conditions: extracted.conditions || "",
      tags: Array.isArray(extracted.tags) ? extracted.tags : [],
      raw_text: contentText,
    }).eq("voucher_id", voucherId);

    if (updateError) {
      console.error("Update error:", updateError.message);
      throw new Error("Failed to update voucher");
    }

    // Log audit
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      await supabase.from("audit_log").insert({
        user_id: user.id,
        voucher_id: voucherId,
        action: "OCR_RAN",
        details: { extracted },
      });
    }

    // Trigger logo autofill in background
    if (extracted.merchant) {
      fetch(`${supabaseUrl}/functions/v1/logo-autofill`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${supabaseKey}`,
        },
        body: JSON.stringify({
          voucherId,
          merchant: extracted.merchant,
          domain: extracted.merchant_domain,
          voucherImagePath: assets[0].file_path,
        }),
      }).catch(() => {/* Ignore background errors */});
    }

    return new Response(JSON.stringify({ success: true, extracted }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Extraction error:", error instanceof Error ? error.message : "Unknown");
    return new Response(
      JSON.stringify({ error: "An error occurred processing your request" }), 
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
