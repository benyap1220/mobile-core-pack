import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const iaApiKey = Deno.env.get('IA_API_KEY')!;
    const iaApiSecret = Deno.env.get('IA_API_SECRET')!;
    const iaBaseUrl = 'https://api.involve.asia';
    const campaignsEndpoint = '/api/campaigns/all';

    console.log('📦 Fetching approved advertisers...');
    const { data: advertisers } = await supabase
      .from('ia_advertisers')
      .select('offer_id, name, countries')
      .eq('approved', true);

    if (!advertisers || advertisers.length === 0) {
      return new Response(JSON.stringify({ error: 'No approved advertisers' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const allowedOfferIds = new Set(advertisers.map(a => a.offer_id));
    const offerIdToName = new Map(advertisers.map(a => [a.offer_id, a.name]));
    
    let promosIngested = 0;
    let promosSkipped = 0;
    const invalidPromos: string[] = [];
    const stats = {
      fetched: 0,
      filtered_by_offer: 0,
      invalid_landing: 0,
      expired: 0,
      upserted: 0,
      deeplink_created: 0,
      deeplink_cached: 0,
    };

    // Step 1: Authenticate to get bearer token (same as ia-offers-ingest)
    console.log('Step 1: Authenticating with IA API...');
    const authResponse = await fetch('https://api.involve.asia/api/authenticate', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        key: iaApiKey,
        secret: iaApiSecret,
      }).toString(),
    });

    const authData = await authResponse.json();
    if (!authResponse.ok || authData.status !== 'success') {
      const authText = JSON.stringify(authData);
      console.error('IA Authentication failed:', authResponse.status, authText);
      throw new Error(`IA Authentication failed: ${authResponse.status} - ${authText}`);
    }

    const token = authData.data?.token;
    if (!token) {
      throw new Error('No token received from IA API');
    }

    console.log('✅ Authentication successful');
    console.log(`📢 Fetching campaigns from ${iaBaseUrl}${campaignsEndpoint}...`);

    // Build form data - removed coupons_only and country filters (too restrictive)
    const formData = new URLSearchParams({
      page: '1',
      limit: '200',
      'filters[offer_status]': 'Active|Paused',
      'filters[application_status]': 'Approved|Pending',
      'filters[with_banners]': 'true',
      'filters[start_date]': '2024-01-01',
      'filters[end_date]': '2099-12-31',
      sort_by: 'recent',
    });

    console.log(`📤 Request body: ${formData.toString()}`);

    const campaignsRes = await fetch(`${iaBaseUrl}${campaignsEndpoint}`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: formData.toString(),
    });

    console.log(`📊 Campaigns response status: ${campaignsRes.status}`);
    console.log(`📊 Response headers: ${JSON.stringify([...campaignsRes.headers.entries()])}`);

    if (!campaignsRes.ok) {
      const errorText = await campaignsRes.text();
      console.error(`❌ Campaigns API error ${campaignsRes.status}: ${errorText.substring(0, 800)}`);
      throw new Error(`Campaigns API returned ${campaignsRes.status}`);
    }

    const campaignsText = await campaignsRes.text();
    console.log(`📦 Campaigns FULL raw response (first 2000 chars): ${campaignsText.substring(0, 2000)}`);

    const json = JSON.parse(campaignsText);
    console.log(`📦 Campaigns parsed type: ${Array.isArray(json) ? 'array' : typeof json}`);
    console.log(`📦 Campaigns top-level keys: ${Object.keys(json).join(', ')}`);

    // Parse nested structure: json?.data?.data || []
    const campaigns = json?.data?.data || [];
    stats.fetched = campaigns.length;
    console.log(`✅ Parsed ${campaigns.length} campaigns from response`);

    // No need for retry logic anymore since we removed restrictive filters

    for (const campaign of campaigns) {
      const campaignBannerId = campaign.campaign_banner_id || campaign.id;
      const offerId = campaign.offer_id || campaign.merchant_id;
      
      if (!allowedOfferIds.has(offerId)) {
        stats.filtered_by_offer++;
        continue;
      }

      // Extract landing URL from tracking_link by parsing the 'url' query param
      const trackingLink = campaign.tracking_link || '';
      let landingUrl = '';
      try {
        const trackingUrl = new URL(trackingLink);
        landingUrl = trackingUrl.searchParams.get('url') || trackingLink;
      } catch {
        landingUrl = trackingLink;
      }

      if (!landingUrl || /\/(cart|checkout|login|privacy|help|terms)/i.test(landingUrl)) {
        invalidPromos.push(`Campaign ${campaignBannerId}: invalid landing`);
        stats.invalid_landing++;
        continue;
      }

      const endsAt = campaign.date_campaign_end || null;
      if (endsAt && new Date(endsAt) < new Date()) {
        invalidPromos.push(`Campaign ${campaignBannerId}: expired`);
        stats.expired++;
        continue;
      }

      const title = campaign.campaign_name || campaign.offer_name || 'Special Offer';
      const code = campaign.voucher_code || null;

      // Upsert promo with proper field mapping
      const { error: upsertError } = await supabase.from('ia_promos').upsert({
        id: campaignBannerId,
        offer_id: offerId,
        title: title,
        summary: campaign.description || null,
        code: code,
        starts_at: campaign.date_campaign_start || null,
        ends_at: endsAt,
        image_url: campaign.banner_image_url || null,
        landing_url: landingUrl,
        tags: campaign.categories ? [campaign.categories] : null,
        source: 'campaign',
        headline: title,
        note: null,
      }, {
        onConflict: 'id',
        ignoreDuplicates: false,
      });

      if (upsertError) {
        console.error(`❌ Upsert error for campaign ${campaignBannerId}:`, upsertError);
        continue;
      }

      stats.upserted++;
      promosIngested++;

      // Generate or reuse deeplink
      try {
        const subs = {
          aff_sub: 'grid',
          aff_sub2: 'card',
          aff_sub3: String(offerId),
          aff_sub4: String(campaignBannerId),
        };

        // Check cache first
        const { data: existingDeeplink } = await supabase
          .from('ia_promo_deeplinks')
          .select('id, deeplink_url')
          .eq('promo_id', campaignBannerId)
          .eq('aff_sub', subs.aff_sub)
          .eq('aff_sub2', subs.aff_sub2)
          .eq('aff_sub3', subs.aff_sub3)
          .eq('aff_sub4', subs.aff_sub4)
          .maybeSingle();

        if (existingDeeplink) {
          stats.deeplink_cached++;
          continue;
        }

        // Generate new deeplink via ia-deeplink-generate
        const { data: deeplinkResult, error: deeplinkError } = await supabase.functions.invoke('ia-deeplink-generate', {
          body: {
            offer_id: offerId,
            raw_url: landingUrl,
            promo_id: campaignBannerId,
            subs,
          },
        });

        if (!deeplinkError && deeplinkResult?.deeplink_url) {
          stats.deeplink_created++;
        }
      } catch (deeplinkErr) {
        console.warn(`⚠️ Deeplink generation failed for ${campaignBannerId}:`, deeplinkErr);
      }
    }

    // Cleanup expired
    const { count: deletedCount } = await supabase
      .from('ia_promos')
      .delete({ count: 'exact' })
      .not('ends_at', 'is', null)
      .lt('ends_at', new Date().toISOString());

    console.log(`🗑️ Deleted ${deletedCount || 0} expired promos`);
    console.log(`✅ Promos ingested: ${promosIngested}`);
    console.log(`📊 Stats:`, stats);
    console.log(`❌ Invalid promos: ${invalidPromos.length}`);

    return new Response(JSON.stringify({
      success: true,
      ingested: promosIngested,
      skipped: promosSkipped,
      invalid: invalidPromos.length,
      invalidSamples: invalidPromos.slice(0, 10),
      stats,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('❌ Error:', error);
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : String(error) }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
