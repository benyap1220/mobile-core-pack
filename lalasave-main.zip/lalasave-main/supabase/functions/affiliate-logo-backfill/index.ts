import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Merchant to domain mapping for logo resolution
const merchantDomains: Record<string, string> = {
  shopee: "shopee.com",
  lazada: "lazada.com",
  grab: "grab.com",
  foodpanda: "foodpanda.com",
  temu: "temu.com",
  amazon: "amazon.com",
  taobao: "taobao.com",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    console.log("Starting affiliate logo backfill...");

    // Fetch all affiliate offers without logos
    const { data: offers, error: fetchError } = await supabase
      .from("affiliate_offers")
      .select("*")
      .is("logo_path", null);

    if (fetchError) {
      console.error("Error fetching offers:", fetchError);
      throw fetchError;
    }

    console.log(`Found ${offers?.length || 0} offers without logos`);

    const results = [];

    for (const offer of offers || []) {
      try {
        const domain = merchantDomains[offer.platform.toLowerCase()] || offer.platform;
        
        console.log(`Resolving logo for ${offer.merchant} (${domain})...`);

        // Try logo sources in order
        const logoUrl = await tryLogoSources(domain);

        if (logoUrl) {
          // Download the logo
          const logoResponse = await fetch(logoUrl);
          if (!logoResponse.ok) throw new Error(`Failed to download logo from ${logoUrl}`);

          const logoBlob = await logoResponse.arrayBuffer();
          const contentType = logoResponse.headers.get("content-type") || "image/png";
          const extension = contentType.includes("svg") ? "svg" : "png";

          // Upload to storage
          const fileName = `affiliate-logos/${offer.platform}-${Date.now()}.${extension}`;
          const { error: uploadError } = await supabase.storage
            .from("logos")
            .upload(fileName, logoBlob, {
              contentType,
              upsert: false,
            });

          if (uploadError) {
            console.error(`Upload error for ${offer.merchant}:`, uploadError);
            continue;
          }

          // Update the offer with logo path
          const { error: updateError } = await supabase
            .from("affiliate_offers")
            .update({ logo_path: fileName })
            .eq("id", offer.id);

          if (updateError) {
            console.error(`Update error for ${offer.merchant}:`, updateError);
            continue;
          }

          console.log(`✓ Logo resolved for ${offer.merchant}: ${fileName}`);
          results.push({ merchant: offer.merchant, success: true, logo_path: fileName });
        } else {
          console.log(`✗ No logo found for ${offer.merchant}`);
          results.push({ merchant: offer.merchant, success: false, error: "No logo source available" });
        }
      } catch (error) {
        console.error(`Error processing ${offer.merchant}:`, error);
        results.push({
          merchant: offer.merchant,
          success: false,
          error: error instanceof Error ? error.message : "Unknown error",
        });
      }
    }

    return new Response(
      JSON.stringify({
        message: "Backfill completed",
        processed: results.length,
        results,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Backfill error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

async function tryLogoSources(domain: string): Promise<string | null> {
  const sources = [
    `https://logo.clearbit.com/${domain}`,
    `https://unavatar.io/${domain}`,
    `https://www.google.com/s2/favicons?domain=${domain}&sz=256`,
  ];

  for (const url of sources) {
    try {
      const response = await fetch(url, { method: "HEAD" });
      if (response.ok) {
        console.log(`Found logo at: ${url}`);
        return url;
      }
    } catch (error) {
      console.log(`Failed to fetch from ${url}:`, error);
    }
  }

  return null;
}
