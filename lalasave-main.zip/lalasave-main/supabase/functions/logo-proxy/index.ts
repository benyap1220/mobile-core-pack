import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

type Body = { merchant_name: string; merchant_domain?: string; force?: boolean };

function canonicalBrandSlug(name: string): string {
  const s = (name || '').toLowerCase().replace(/[''`"]/g, '').trim();
  if (s.includes('lazada')) return 'lazada';
  if (s === 'lex' || s.includes('lex ')) return 'lazada';
  if (s.includes('mcdonald')) return 'mcdonalds';
  if (s.includes('grab')) return 'grab';
  if (s.includes('shopee')) return 'shopee';
  return s.replace(/\s+/g, ' ').trim();
}

function slugifyMerchant(name: string): string {
  const canonical = canonicalBrandSlug(name);
  return canonical.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { merchant_name, merchant_domain, force }: Body = await req.json();
    
    if (!merchant_name) {
      return json({ error: "missing merchant_name" }, 400);
    }

    const merchant_slug = slugifyMerchant(merchant_name);
    console.log(`[logo-proxy] ${merchant_name} -> ${merchant_slug}`);

    // Check cache AND verify file exists if not forced
    if (!force) {
      const { data: cached } = await supabase
        .from("merchant_logo_cache")
        .select("*")
        .eq("merchant_slug", merchant_slug)
        .maybeSingle();

      if (cached?.public_url) {
        // Verify file actually exists in storage
        const fileName = `${merchant_slug}.png`;
        const { data: fileList } = await supabase.storage
          .from("brand-logos")
          .list('', { search: fileName });
        
        if (fileList && fileList.length > 0) {
          console.log(`✓ Cache hit + file verified: ${merchant_slug}`);
          return json({ logo_url: cached.public_url, source: cached.source ?? "cached", slug: merchant_slug, status: "ok" });
        } else {
          console.log(`⚠ Cache found but file missing, re-fetching: ${merchant_slug}`);
        }
      }
    }

    const brandToDomain: Record<string, string> = {
      'lazada': 'lazada.com.my', 'shopee': 'shopee.com.my', 'grab': 'grab.com',
      'foodpanda': 'foodpanda.my', 'zalora': 'zalora.com.my', 'watsons': 'watsons.com.my',
      'sephora': 'sephora.my', 'guardian': 'guardian.com.my', 'uniqlo': 'uniqlo.com',
      'shein': 'shein.com', 'zara': 'zara.com', 'nike': 'nike.com', 'adidas': 'adidas.com',
      'traveloka': 'traveloka.com', 'airasia': 'airasia.com', 'agoda': 'agoda.com',
      'taobao': 'taobao.com', 'aliexpress': 'aliexpress.com', 'amazon': 'amazon.com',
      'mcdonalds': 'mcdonalds.com', 'kfc': 'kfc.com', 'starbucks': 'starbucks.com',
      'apple': 'apple.com', 'samsung': 'samsung.com',
    };
    
    const domain = merchant_domain || brandToDomain[merchant_slug] || guessDomain(merchant_slug);
    const candidates = [
      `https://logo.clearbit.com/${domain}`,
      `https://unavatar.io/${domain}`,
      `https://img.logo.dev/${domain}?token=pk_X-1ZO13CRkmOfEogs3mzvQ`,
      `https://www.google.com/s2/favicons?domain=${domain}&sz=256`,
    ];

    let picked: { buf: Uint8Array; source: string } | null = null;

    for (const [idx, url] of candidates.entries()) {
      try {
        const r = await fetch(url, { 
          signal: AbortSignal.timeout(5000),
          headers: { 'User-Agent': 'Mozilla/5.0' }
        });
        if (!r.ok) continue;
        
        const buf = new Uint8Array(await r.arrayBuffer());
        if (buf.byteLength < 100) continue;
        
        picked = { 
          buf, 
          source: idx === 0 ? "clearbit" : idx === 1 ? "unavatar" : idx === 2 ? "logo.dev" : "google" 
        };
        console.log(`✓ ${picked.source}: ${buf.byteLength}b`);
        break;
      } catch (err) {
        continue;
      }
    }

    let logo_url: string;
    let source: string;

    if (picked) {
      const path = `${merchant_slug}.png`;
      
      // CRITICAL: Actually upload the file
      const { error: uploadError } = await supabase.storage
        .from("brand-logos")
        .upload(path, picked.buf, {
          contentType: "image/png",
          upsert: true,
          cacheControl: "31536000",
        });

      if (uploadError) {
        console.error(`✗ Upload failed:`, uploadError);
        throw new Error(`Upload failed: ${uploadError.message}`);
      }

      // Verify file was uploaded successfully
      const { data: fileList } = await supabase.storage
        .from("brand-logos")
        .list('', { search: `${merchant_slug}.png` });
      
      if (!fileList || fileList.length === 0) {
        console.error(`✗ File verification failed after upload: ${path}`);
        throw new Error(`File not found after upload: ${path}`);
      }

      const { data: pub } = supabase.storage.from("brand-logos").getPublicUrl(path);
      logo_url = pub.publicUrl;
      source = picked.source;
      console.log(`✓ Uploaded & verified: ${path}`);
    } else {
      // Fallback SVG
      const initial = merchant_name.charAt(0).toUpperCase();
      const svg = generateSVGLogo(initial);
      const path = `${merchant_slug}.svg`;
      
      await supabase.storage.from("brand-logos").upload(path, new TextEncoder().encode(svg), {
        contentType: "image/svg+xml",
        upsert: true,
        cacheControl: "31536000",
      });

      const { data: pub } = supabase.storage.from("brand-logos").getPublicUrl(path);
      logo_url = pub.publicUrl;
      source = "generated";
      console.log(`✓ SVG: ${path}`);
    }

    // Cache it + update ia_advertisers
    await supabase.from("merchant_logo_cache").upsert({
      merchant_slug,
      public_url: logo_url,
      source,
      updated_at: new Date().toISOString(),
    }, { onConflict: 'merchant_slug' });

    // Update ia_advertisers logo_url for all advertisers with matching name
    await supabase
      .from("ia_advertisers")
      .update({ logo_url, logo_source: source, logo_updated_at: new Date().toISOString() })
      .ilike('name', `%${canonicalBrandSlug(merchant_name)}%`);

    return json({ logo_url, source, slug: merchant_slug, status: "ok" });
  } catch (e) {
    console.error("[logo-proxy]", e);
    return json({ error: String(e), logo_url: null, source: "none", status: "error" }, 500);
  }
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "content-type": "application/json" },
  });
}

function guessDomain(m: string) {
  return m.replace(/[^a-z0-9]+/g, "") + ".com";
}

function generateSVGLogo(initial: string): string {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200">
    <defs>
      <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" style="stop-color:#667eea;stop-opacity:1" />
        <stop offset="100%" style="stop-color:#764ba2;stop-opacity:1" />
      </linearGradient>
    </defs>
    <rect width="200" height="200" fill="url(#grad)" rx="20"/>
    <text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="white" font-size="100" font-family="Arial, sans-serif" font-weight="bold">${initial}</text>
  </svg>`;
}
