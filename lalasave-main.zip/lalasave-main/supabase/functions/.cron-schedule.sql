-- Schedule ia-promos-ingest to run every 3 hours
SELECT cron.schedule(
  'ia-promos-ingest-3hourly',
  '0 */3 * * *',
  $$
  SELECT net.http_post(
    url:='https://cnayuxiwjgpjrzkphhwz.supabase.co/functions/v1/ia-promos-ingest',
    headers:='{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNuYXl1eGl3amdwanJ6a3BoaHd6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTk2NzM4MDYsImV4cCI6MjA3NTI0OTgwNn0.ZA_6hIEYMQCDRGvyvmc3x-xTFg_MOhgKiZvmZ9TBWJI"}'::jsonb,
    body:='{}'::jsonb
  ) as request_id;
  $$
);

-- Schedule deals-build-feed to run every 2 hours
SELECT cron.schedule(
  'deals-build-feed-2hourly',
  '0 */2 * * *', -- Every 2 hours at minute 0
  $$
  SELECT net.http_post(
    url:='https://cnayuxiwjgpjrzkphhwz.supabase.co/functions/v1/deals-build-feed',
    headers:='{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNuYXl1eGl3amdwanJ6a3BoaHd6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTk2NzM4MDYsImV4cCI6MjA3NTI0OTgwNn0.ZA_6hIEYMQCDRGvyvmc3x-xTFg_MOhgKiZvmZ9TBWJI"}'::jsonb,
    body:='{}'::jsonb
  ) as request_id;
  $$
);
