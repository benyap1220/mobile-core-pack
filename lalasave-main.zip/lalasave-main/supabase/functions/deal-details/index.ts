import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, serviceKey);

    const url = new URL(req.url);
    const dealId = url.searchParams.get('deal_id');

    if (!dealId) {
      return new Response(
        JSON.stringify({ error: 'Missing deal_id parameter' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Fetch deal with joined deeplink
    const { data: deal, error: dealError } = await supabase
      .from('deals_feed')
      .select('*')
      .eq('id', dealId)
      .single();

    if (dealError || !deal) {
      return new Response(
        JSON.stringify({ error: 'Deal not found' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Clean advertiser name helper - remove country codes and tracking suffixes
    const cleanAdvertiserName = (name: string): string => {
      return name
        .replace(/\s*\([A-Z]{2,3}\)\s*/g, '') // Remove (MY), (SG), (USA) etc.
        .replace(/\s*-\s*CPS\s*$/i, '') // Remove - CPS at end
        .replace(/\s*-\s*CPA\s*$/i, '') // Remove - CPA at end  
        .replace(/\s*-\s*CPL\s*$/i, '') // Remove - CPL at end
        .replace(/\s*-\s*Affiliate.*$/i, '') // Remove - Affiliate...
        .replace(/\s*\(CPS\)\s*$/i, '') // Remove (CPS) at end
        .replace(/\s*\(CPA\)\s*$/i, '') // Remove (CPA) at end
        .replace(/\s+/g, ' ') // Normalize whitespace
        .trim();
    };

    // Fetch advertiser info with logo
    const { data: advertiser } = await supabase
      .from('ia_advertisers')
      .select('name, logo_url')
      .eq('offer_id', deal.offer_id)
      .single();

    // Fetch primary promo if available
    let promo = null;
    if (deal.primary_promo_id) {
      const { data: promoData } = await supabase
        .from('ia_promos')
        .select('*')
        .eq('id', deal.primary_promo_id)
        .single();
      promo = promoData;
    }

    // Fallback to promo_notes if no ia_promos found
    if (!promo && deal.landing_id) {
      const { data: noteData } = await supabase
        .from('promo_notes')
        .select('*')
        .eq('deal_id', deal.landing_id)
        .order('created_at', { ascending: false })
        .limit(1)
        .single();
      
      if (noteData) {
        promo = {
          headline: 'Special Offer',
          summary: noteData.notes,
          code: noteData.coupon_code,
          ends_at: noteData.valid_until,
          tags: [],
          image_url: null,
        };
      }
    }

    // Build response
    const cleanPlatform = advertiser?.name ? cleanAdvertiserName(advertiser.name) : (deal.platform || 'Platform');
    
    const response = {
      deal_id: deal.id,
      platform: cleanPlatform,
      platform_logo: advertiser?.logo_url || null,
      title: promo?.headline || deal.title || 'Special Deal',
      summary: promo?.summary || deal.subtitle || '',
      tags: promo?.tags || deal.tags || [],
      coupon_code: promo?.code || null,
      expires_at: promo?.ends_at || deal.expires_at,
      image_url: promo?.image_url || deal.image_url,
      deeplink_redirect: `/go/${deal.deeplink_id}`,
    };

    return new Response(
      JSON.stringify(response),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in deal-details:', error);
    const message = error instanceof Error ? error.message : String(error);
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
