import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    const url = new URL(req.url);
    const limit = parseInt(url.searchParams.get('limit') || '24');
    const cursorScore = url.searchParams.get('cursor_score');
    const cursorDate = url.searchParams.get('cursor_date');
    const cursorId = url.searchParams.get('cursor_id');

    // Quality gate: only show deals with good scores
    let query = supabase
      .from('deals_feed')
      .select('*')
      .gte('score', 40) // Minimum quality threshold
      .or(`has_coupon.eq.true,deal_key.not.is.null`) // Must have code OR deal value
      .order('score', { ascending: false })
      .order('created_at', { ascending: false })
      .order('id', { ascending: false })
      .limit(limit * 2); // Fetch 2x to allow diversity filtering

    // Keyset pagination
    if (cursorScore && cursorDate && cursorId) {
      query = query.or(
        `score.lt.${cursorScore},and(score.eq.${cursorScore},created_at.lt.${cursorDate}),and(score.eq.${cursorScore},created_at.eq.${cursorDate},id.lt.${cursorId})`
      );
    }

    const { data: deals, error } = await query;

    if (error) {
      console.error('Query error:', error);
      return new Response(
        JSON.stringify({ error: error.message, hint: 'Database query failed' }),
        { status: 500, headers: { ...corsHeaders, 'content-type': 'application/json' } }
      );
    }

    if (!deals || deals.length === 0) {
      return new Response(
        JSON.stringify({ items: [], next_cursor: null }),
        { headers: { ...corsHeaders, 'content-type': 'application/json' } }
      );
    }

    // Apply per-page diversity: max 2 deals per platform in a single page
    const diverseDeals: typeof deals = [];
    const platformCountInPage: Record<string, number> = {};
    
    for (const deal of deals) {
      const platformKey = (deal.platform || "").toLowerCase();
      const count = platformCountInPage[platformKey] || 0;
      
      if (count < 2) {
        diverseDeals.push(deal);
        platformCountInPage[platformKey] = count + 1;
      }
      
      // Stop once we have enough deals for this page
      if (diverseDeals.length >= limit) break;
    }

    // Fetch promos for deals that have promo_id
    const promoIds = diverseDeals.filter(d => d.promo_id || d.primary_promo_id).map(d => d.promo_id || d.primary_promo_id);
    const { data: promos } = await supabase
      .from('ia_promos')
      .select('*')
      .in('id', promoIds);

    const promoMap = new Map(promos?.map(p => [p.id, p]) || []);

    // Fetch advertisers for logos
    const offerIds = [...new Set(diverseDeals.map(d => d.offer_id))];
    const { data: advertisers } = await supabase
      .from('ia_advertisers')
      .select('offer_id, logo_url, name')
      .in('offer_id', offerIds);

    // Ensure logos are valid, call logo-proxy if needed
    const logoMap = new Map();
    for (const adv of advertisers || []) {
      let logoUrl = adv.logo_url;
      
      // If logo is missing or not a valid Supabase storage URL, fetch it now
      if (!logoUrl || !logoUrl.includes('supabase.co/storage')) {
        console.log(`⚠ Missing/invalid logo for ${adv.name}, fetching...`);
        try {
          const { data: logoData } = await supabase.functions.invoke('logo-proxy', {
            body: { merchant_name: adv.name }
          });
          if (logoData?.logo_url) {
            logoUrl = logoData.logo_url;
          }
        } catch (err) {
          console.error(`Logo fetch failed for ${adv.name}:`, err);
        }
      }
      
      logoMap.set(adv.offer_id, { logo_url: logoUrl, name: adv.name });
    }

    // Fetch approved borders
    const { data: borders } = await supabase
      .from('border_styles')
      .select('*')
      .eq('target', 'deals')
      .not('approved_by', 'is', null);

    // Shuffle borders to ensure non-repeating
    const shuffledBorders = borders ? [...borders].sort(() => Math.random() - 0.5) : [];

    // Enrich deals - use pre-generated title/subtitle/tags from deals_feed
    const enrichedDeals = diverseDeals.map((deal, index) => {
      const promo = (deal.promo_id || deal.primary_promo_id) ? promoMap.get(deal.promo_id || deal.primary_promo_id) : null;
      const advertiser = logoMap.get(deal.offer_id);
      const border = shuffledBorders[index % shuffledBorders.length];

      return {
        id: deal.id,
        offer_id: deal.offer_id,
        deeplink_id: deal.deeplink_id,
        deeplink_type: deal.deeplink_type || 'standard',
        
        // Use pre-generated title/subtitle/tags from deals_feed
        title: deal.title,
        summary: deal.subtitle || '',
        code: promo?.code || null,
        tags: deal.tags || [],
        image_url: promo?.image_url || deal.image_url,
        
        // Metadata - use pre-cleaned platform name from deals_feed
        expires_at: promo?.ends_at || deal.expires_at,
        platform: deal.platform, // Already cleaned during feed build
        platform_logo: advertiser?.logo_url || null,
        country: deal.country,
        source: deal.source,
        has_coupon: deal.has_coupon,
        
        // Border
        border: border ? {
          id: border.id,
          svg_path: border.svg_path,
          layout_mode: border.layout_mode,
          safe_area: border.safe_area,
          frame_meta: border.frame_meta,
          view_box: border.view_box,
          image_path: border.image_path,
        } : null,
      };
    });

    // Calculate next cursor from the last DIVERSE deal
    const lastDeal = diverseDeals[diverseDeals.length - 1];
    const nextCursor = lastDeal ? {
      score: lastDeal.score,
      created_at: lastDeal.created_at,
      id: lastDeal.id,
    } : null;

    return new Response(
      JSON.stringify({ items: enrichedDeals, next_cursor: nextCursor }),
      { headers: { ...corsHeaders, 'content-type': 'application/json' } }
    );
  } catch (error) {
    console.error('deals-list error:', error);
    return new Response(
      JSON.stringify({ error: String(error), hint: 'Unexpected server error' }),
      { status: 500, headers: { ...corsHeaders, 'content-type': 'application/json' } }
    );
  }
});
