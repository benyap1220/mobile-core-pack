import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Input validation
const QuerySchema = z.object({
  offerId: z.string().uuid({ message: "Invalid offer ID" }),
  uid: z.string().uuid({ message: "Invalid user ID" }).optional(),
});

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const params = {
      offerId: url.searchParams.get("offerId"),
      uid: url.searchParams.get("uid") || undefined,
    };

    // Validate input
    const validation = QuerySchema.safeParse(params);
    if (!validation.success) {
      console.error("Validation error:", validation.error.format());
      return new Response("Invalid request parameters", { 
        status: 400,
        headers: corsHeaders 
      });
    }

    const { offerId, uid } = validation.data;

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Fetch the offer
    const { data: offer, error: offerError } = await supabase
      .from("affiliate_offers")
      .select("*")
      .eq("id", offerId)
      .eq("is_active", true)
      .single();

    if (offerError || !offer) {
      console.error("Offer fetch error:", offerError?.message || "Not found");
      return new Response("Offer not found", { status: 404, headers: corsHeaders });
    }

    // Log the click
    const userAgent = req.headers.get("user-agent")?.substring(0, 500) || "unknown";
    const { error: clickError } = await supabase
      .from("affiliate_clicks")
      .insert({
        offer_id: offerId,
        user_id: uid || null,
        user_agent: userAgent,
      });

    if (clickError) {
      console.error("Click logging error:", clickError.message);
    }

    // Build final URL with UTM params
    let finalUrl = offer.deep_link;
    const urlObj = new URL(finalUrl);
    
    // Add UTM params if not present
    if (!urlObj.searchParams.has("utm_source")) {
      urlObj.searchParams.set("utm_source", "promoparser");
    }
    if (!urlObj.searchParams.has("utm_medium")) {
      urlObj.searchParams.set("utm_medium", "affiliate");
    }
    if (!urlObj.searchParams.has("utm_campaign")) {
      urlObj.searchParams.set("utm_campaign", offer.platform);
    }

    finalUrl = urlObj.toString();

    console.log("Redirect processed successfully");

    // 302 redirect
    return new Response(null, {
      status: 302,
      headers: {
        ...corsHeaders,
        Location: finalUrl,
      },
    });
  } catch (error) {
    console.error("Redirect error:", error instanceof Error ? error.message : "Unknown");
    return new Response("An error occurred", { 
      status: 500,
      headers: corsHeaders 
    });
  }
});
