import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { offer_id, test_url } = await req.json();

    // Use default values if not provided
    const testOfferId = offer_id || 3579; // AliExpress
    const testUrl = test_url || 'https://www.lazada.com.my/';

    console.log(`Testing deeplink generation for offer ${testOfferId} with URL: ${testUrl}`);

    // Get advertiser info
    const { data: advertiser } = await supabase
      .from('ia_advertisers')
      .select('*')
      .eq('offer_id', testOfferId)
      .maybeSingle();

    if (!advertiser) {
      return new Response(
        JSON.stringify({
          ok: false,
          error: 'Advertiser not found',
          hint: 'Run "Ingest IA Offers" first',
        }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Call deeplink generation
    const deeplinkRes = await fetch(`${supabaseUrl}/functions/v1/ia-deeplink-generate`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${supabaseKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        offer_id: testOfferId,
        raw_url: testUrl,
        subs: {
          sub1: 'test',
          sub2: 'admin',
          sub3: String(testOfferId),
          sub4: 'diagnostic',
        },
      }),
    });

    const deeplinkData = await deeplinkRes.json();

    // Build diagnostic response
    const diagnostic = {
      ok: true,
      test_params: {
        offer_id: testOfferId,
        advertiser_name: advertiser.name,
        test_url: testUrl,
        has_tracking_link: !!advertiser.tracking_link,
        tracking_link: advertiser.tracking_link,
      },
      deeplink_result: {
        success: !!deeplinkData.deeplink_id,
        deeplink_type: deeplinkData.deeplink_type || 'unknown',
        deeplink_url: deeplinkData.deeplink_url || null,
        deeplink_id: deeplinkData.deeplink_id || null,
        cached: deeplinkData.cached || false,
        fallback_reason: deeplinkData.fallback_reason || null,
      },
      api_response: deeplinkRes.ok ? null : {
        status: deeplinkRes.status,
        ok: deeplinkData.ok,
        error: deeplinkData.error,
        where: deeplinkData.where,
        details: deeplinkData.details,
      },
      interpretation: getInterpretation(deeplinkData, advertiser),
    };

    return new Response(
      JSON.stringify(diagnostic),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in test deeplink:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    
    return new Response(
      JSON.stringify({ 
        ok: false,
        error: errorMessage,
      }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

function getInterpretation(deeplinkData: any, advertiser: any): string {
  if (!deeplinkData.deeplink_id) {
    return '❌ All strategies failed. Check if offer_id is valid and IA API credentials are correct.';
  }

  if (deeplinkData.deeplink_type === 'standard' && !deeplinkData.cached) {
    return '✅ SUCCESS: Deeplink API working perfectly! Generated new standard deeplink.';
  }

  if (deeplinkData.deeplink_type === 'standard' && deeplinkData.cached) {
    return '✅ Using cached standard deeplink from previous generation.';
  }

  if (deeplinkData.deeplink_type === 'shoplink' && deeplinkData.fallback_reason?.includes('500')) {
    return `⚠️ Deeplink API returned 500 error, used shoplink fallback. ${
      advertiser.tracking_link 
        ? 'Used advertiser tracking_link.' 
        : 'Used generic invol.co link.'
    } This still works for tracking!`;
  }

  if (deeplinkData.deeplink_type === 'shoplink') {
    return `⚠️ Using shoplink fallback (reason: ${deeplinkData.fallback_reason}). ${
      advertiser.tracking_link 
        ? 'Built from advertiser tracking_link.' 
        : 'Built generic invol.co link.'
    } Attribution still works!`;
  }

  return 'ℹ️ Deeplink generated successfully.';
}
