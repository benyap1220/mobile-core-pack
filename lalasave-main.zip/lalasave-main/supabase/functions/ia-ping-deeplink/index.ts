import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const iaApiKey = Deno.env.get('IA_API_KEY')!;
    const iaApiSecret = Deno.env.get('IA_API_SECRET')!;

    console.log('Step 1: Authenticating with IA API...');

    // Step 1: Authenticate to get bearer token
    const authResponse = await fetch('https://api.involve.asia/api/authenticate', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        key: iaApiKey,
        secret: iaApiSecret,
      }).toString(),
    });

    const authText = await authResponse.text();
    let authData;
    try {
      authData = JSON.parse(authText);
    } catch {
      authData = { raw: authText };
    }

    if (!authResponse.ok || authData.status !== 'success') {
      console.error('IA Authentication failed:', authResponse.status, authText);
      return new Response(
        JSON.stringify({
          ok: false,
          step: 'authentication',
          status: authResponse.status,
          error: authText,
          details: authData,
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const token = authData.data?.token;
    if (!token) {
      return new Response(
        JSON.stringify({
          ok: false,
          step: 'authentication',
          error: 'No token received',
          details: authData,
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('Step 2: Authentication successful! Token obtained.');

    // Return success with token info
    return new Response(
      JSON.stringify({
        ok: true,
        message: 'IA Connection successful',
        authSchemeUsed: 'bearer',
        tokenObtained: true,
        tokenExpiresIn: '2 hours',
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );


  } catch (error) {
    console.error('Error in ping test:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    const errorDetails = error instanceof Error ? error.toString() : String(error);

    return new Response(
      JSON.stringify({ ok: false, error: errorMessage, details: errorDetails }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
