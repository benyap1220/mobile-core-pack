import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.58.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    console.log('Starting display_title backfill...');

    // Get vouchers without display_title
    const { data: vouchers, error: fetchError } = await supabase
      .from('vouchers')
      .select('voucher_id, source_offer_id, deal_type, value, currency, conditions, merchant_logo_path')
      .is('display_title', null);

    if (fetchError) {
      console.error('Error fetching vouchers:', fetchError);
      throw fetchError;
    }

    console.log(`Found ${vouchers?.length || 0} vouchers to backfill`);
    let updated = 0;
    let skipped = 0;

    for (const voucher of vouchers || []) {
      let displayTitle: string | null = null;
      let logoPath: string | null = voucher.merchant_logo_path;

      // Try to get from source_offer_id first
      if (voucher.source_offer_id) {
        const { data: offer } = await supabase
          .from('affiliate_offers')
          .select('offer_title, logo_path')
          .eq('id', voucher.source_offer_id)
          .single();

        if (offer) {
          displayTitle = offer.offer_title;
          logoPath = offer.logo_path || logoPath;
          console.log(`✓ Found offer title for voucher ${voucher.voucher_id}: ${displayTitle}`);
        }
      }

      // Fallback: infer from deal_type/value or conditions
      if (!displayTitle) {
        if (voucher.deal_type === 'percentage' && voucher.value) {
          displayTitle = `${Math.round(voucher.value)}% OFF`;
        } else if (voucher.deal_type === 'amount' && voucher.value) {
          displayTitle = `${voucher.currency || 'MYR'} ${voucher.value} OFF`;
        } else if (voucher.deal_type === 'bogo') {
          displayTitle = 'Buy 1 Get 1 Free';
        } else if (voucher.conditions) {
          // Try to extract a headline from conditions
          const percentMatch = voucher.conditions.match(/(\d+)%/);
          const amountMatch = voucher.conditions.match(/(RM|PHP|SGD|USD)\s*(\d+)/i);
          
          if (percentMatch) {
            displayTitle = `${percentMatch[1]}% OFF`;
          } else if (amountMatch) {
            displayTitle = `${amountMatch[1]} ${amountMatch[2]} OFF`;
          } else {
            // Use first sentence as headline
            const firstSentence = voucher.conditions.split(/[.!?]/)[0].trim();
            displayTitle = firstSentence.slice(0, 60); // max 60 chars
          }
        }
      }

      // Update if we have a display_title
      if (displayTitle) {
        const { error: updateError } = await supabase
          .from('vouchers')
          .update({ 
            display_title: displayTitle,
            merchant_logo_path: logoPath
          })
          .eq('voucher_id', voucher.voucher_id);

        if (updateError) {
          console.error(`Error updating voucher ${voucher.voucher_id}:`, updateError);
        } else {
          updated++;
          console.log(`✓ Updated voucher ${voucher.voucher_id}: ${displayTitle}`);
        }
      } else {
        skipped++;
        console.log(`⚠ Skipped voucher ${voucher.voucher_id} - no title found`);
      }
    }

    const result = {
      success: true,
      total: vouchers?.length || 0,
      updated,
      skipped,
    };

    console.log('Backfill complete:', result);

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Backfill error:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
