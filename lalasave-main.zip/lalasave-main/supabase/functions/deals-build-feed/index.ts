import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// ===== ENHANCED PROMO PARSING & QUALITY GATING =====
const CURRENCIES = ['RM','MYR','SGD','USD','IDR'];

// Enhanced blacklist for low-value promos
const TITLE_BLACKLIST = [
  /evergreen/i,
  /always\s*on/i,
  /generic\s*brand/i,
  /brand\s*banner/i,
  /homepage/i,
  /home\s*deals/i,
  /top\s*deals/i,
  /this\s*month/i,
  /storewide\s*banners?/i,
  /banner(?!\s*code)/i, // banner without explicit code
];

type ParsedPromo = {
  pct?: number;
  amount?: { value:number, currency:string };
  freeShip?: boolean;
  bogo?: boolean;
  category?: string;
  minSpend?: { value:number, currency:string };
  newUsers?: boolean;
  appOnly?: boolean;
  bank?: string;
  scope?: string;
};

const clamp = (n:number,min:number,max:number)=>Math.max(min,Math.min(max,n));

function parsePromoText(text: string): ParsedPromo {
  const p: ParsedPromo = {};
  const s = (text||'').replace(/\s+/g,' ').trim();

  // % OFF - cap at 95% to filter suspicious deals
  const pct = s.match(/(\d{1,2})\s*%/);
  if (pct) {
    const val = parseInt(pct[1],10);
    // Filter out suspicious >95% deals
    if (val <= 95) p.pct = clamp(val, 1, 95);
  }

  // Currency OFF
  const money = s.match(/\b(RM|MYR|SGD|USD|IDR|\$)\s?(\d{1,5})(?:\b|[^a-z])/i);
  if (money) {
    const cur = money[1].toUpperCase()==='$' ? 'USD' : money[1].toUpperCase();
    p.amount = { currency: cur, value: parseInt(money[2],10) };
  }

  // Free shipping
  if (/\bfree(?:\s*|-)ship/i.test(s)) p.freeShip = true;

  // BOGO
  if (/buy\s*\d+\s*get\s*\d+/i.test(s) || /\bbogo\b/i.test(s)) p.bogo = true;

  // Min spend
  const min = s.match(/min(?:imum)?\s*(?:spend|purchase)?\s*(RM|MYR|SGD|USD|IDR|\$)\s?(\d{1,6})/i);
  if (min) {
    const cur = min[1].toUpperCase()==='$' ? 'USD' : min[1].toUpperCase();
    p.minSpend = { currency: cur, value: parseInt(min[2],10) };
  }

  // New users / app only / bank
  if (/new\s*user/i.test(s)) p.newUsers = true;
  if (/\bapp[-\s]*only\b/i.test(s) || /\bin[-\s]*app\b/i.test(s)) p.appOnly = true;
  const bank = s.match(/\b(Maybank|CIMB|RHB|HSBC|AmBank|Public Bank)\b/i);
  if (bank) p.bank = bank[1];

  // Scope
  if (/\bsite[-\s]*wide\b/i.test(s)) p.scope = 'sitewide';
  else if (/selected|specific|certain|chosen/i.test(s)) p.scope = 'selected items';
  else if (/\bframes?\b/i.test(s)) p.scope = 'frames';
  else if (/\blenses?\b/i.test(s)) p.scope = 'lenses';

  // Category
  const cat = s.match(/\b(Fashion|Electronics|Beauty|Travel|Food|Grocer(?:y)?|Home|Marketplace|Eyewear|Frames|Lenses)\b/i);
  if (cat) p.category = cat[1];

  return p;
}

function isBlacklisted(title:string, summary?:string): boolean {
  const text = ((title||'') + ' ' + (summary||'')).toLowerCase();
  return TITLE_BLACKLIST.some(rx => rx.test(text));
}

function hasNoValue(text:string, hasCode:boolean): boolean {
  // If no code and no discount indicators, it's worthless
  if (hasCode) return false;
  const s = text.toLowerCase();
  const hasIndicator = /(%|rm|sgd|usd|off|voucher|code|free|bogo)/i.test(s);
  return !hasIndicator;
}

function fmtCurrency(amount:{value:number,currency:string}|undefined) {
  if (!amount) return '';
  const cur = amount.currency === 'MYR' ? 'RM' : amount.currency;
  return `${cur}${amount.value}`;
}

function buildDealKey(p: ParsedPromo): string | null {
  const parts: string[] = [];
  if (p.pct) parts.push(`pct:${p.pct}`);
  if (p.amount) parts.push(`amt:${fmtCurrency(p.amount).toLowerCase().replace(/\s/g,'')}`);
  if (p.scope) parts.push(`scope:${p.scope.toLowerCase().replace(/\s/g,'')}`);
  if (p.minSpend) parts.push(`min:${fmtCurrency(p.minSpend).toLowerCase().replace(/\s/g,'')}`);
  return parts.length > 0 ? parts.join('|') : null;
}

function buildTitle(p: ParsedPromo, brand: string, country?: string): string {
  const suffix = country ? ` (${country})` : '';
  
  // Priority: % > amount > Free Ship > BOGO > Category
  if (p.pct) return `${p.pct}% OFF at ${brand}${suffix}`;
  if (p.amount) {
    const minPart = p.minSpend ? ` ${fmtCurrency(p.minSpend)}+` : '';
    return `${fmtCurrency(p.amount)} OFF${minPart} at ${brand}${suffix}`;
  }
  if (p.freeShip) return `Free Shipping at ${brand}${suffix}`;
  if (p.bogo) return `Buy More, Get More at ${brand}`;
  if (p.category) return `${p.category} Deals at ${brand}`;
  return `Deals at ${brand}`;
}

function buildSubtitle(p: ParsedPromo, rawSummary?: string): string {
  const bits:string[] = [];
  
  // Add parsed conditions first
  if (p.scope && p.scope!=='sitewide') bits.push(p.scope.charAt(0).toUpperCase() + p.scope.slice(1));
  if (p.minSpend) bits.push(`Min ${fmtCurrency(p.minSpend)}`);
  if (p.newUsers) bits.push('New users');
  if (p.appOnly) bits.push('App only');
  if (p.bank) bits.push(`${p.bank} cards`);
  
  // If we have room and rawSummary exists, add a short excerpt (max 90 chars total)
  const constructed = bits.join(' • ');
  if (constructed.length < 60 && rawSummary) {
    const clean = rawSummary.replace(/\s+/g, ' ').trim();
    const remainingSpace = 90 - constructed.length - 3; // -3 for ' • '
    if (remainingSpace > 20) {
      const excerpt = clean.substring(0, remainingSpace).trim();
      if (excerpt && !constructed.toLowerCase().includes(excerpt.toLowerCase())) {
        return constructed ? `${constructed} • ${excerpt}` : excerpt;
      }
    }
  }
  
  return constructed;
}

function buildTags(p: ParsedPromo, country?: string): string[] {
  const t:string[] = [];
  if (p.minSpend) t.push(`Min ${fmtCurrency(p.minSpend)}`);
  if (p.scope === 'sitewide') t.push('Sitewide');
  else if (p.scope) t.push(p.scope.charAt(0).toUpperCase() + p.scope.slice(1));
  if (p.appOnly) t.push('App only');
  if (p.newUsers) t.push('New users');
  if (p.bank) t.push(p.bank);
  if (p.category) t.push(p.category);
  if (country) t.push(country);
  return t.slice(0,5);
}

function calculateScore(p: ParsedPromo, hasCode: boolean, title: string, expiresAt?: Date): number {
  let score = 0;
  
  // Code present
  if (hasCode) score += 40;
  
  // Percentage discount
  if (p.pct) {
    if (p.pct >= 10) score += 25;
    else score += Math.floor(p.pct * 2.5); // scale smaller discounts
  }
  
  // Amount discount
  if (p.amount) {
    const value = p.amount.value;
    if (value >= 30) score += 15;
    else score += Math.floor(value / 2); // scale smaller amounts
  }
  
  // Scope
  if (p.scope === 'sitewide') score += 8;
  else if (p.category) score += 5;
  
  // Penalties for bad titles
  if (isBlacklisted(title, '')) score -= 10;
  
  // Penalty for long expiry
  if (expiresAt) {
    const daysToExpiry = Math.floor((expiresAt.getTime() - Date.now()) / (1000 * 60 * 60 * 24));
    if (daysToExpiry > 60) score -= 8;
  }
  
  return Math.max(0, score);
}

function cleanPlatformName(name: string): string {
  return name
    .replace(/\s*-\s*(CPS|CPA)\s*$/i, '')
    .replace(/\s*\((Deeplinkable|Non-deeplinkable)\)\s*/i, '')
    .trim();
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const rotationBatch = new Date().toISOString().split('T')[0];

    console.log('📦 Fetching valid promos from ia_promos...');
    const { data: promos, error: promosError } = await supabase
      .from('ia_promos')
      .select(`
        *,
        ia_advertisers!inner(name)
      `)
      .or(`ends_at.is.null,ends_at.gte.${new Date().toISOString()}`)
      .order('discovered_at', { ascending: false });

    if (promosError) {
      console.error('Error fetching promos:', promosError);
      return new Response(JSON.stringify({ error: promosError.message }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log(`Found ${promos.length} total promos`);

    // Stats tracking
    let droppedBlacklist = 0;
    let droppedNoValue = 0;
    let droppedDuplicate = 0;
    let kept = 0;

    // Track deals per advertiser for diversity (max 3 per advertiser)
    const perAdvertiserCount: Record<string, number> = {};

    // Filter and process promos
    const validPromos = promos.filter((p) => {
      const now = Date.now();
      const exp = p.ends_at ? new Date(p.ends_at).getTime() : Infinity;
      if (exp < now) return false;

      const rawTitle = (p.title || "").trim();
      const rawSummary = (p.summary || p.headline || "").trim();
      const hasCode = !!p.code;

      // 1) ABSOLUTE BLACKLIST - reject even with codes
      if (isBlacklisted(rawTitle, rawSummary)) {
        droppedBlacklist++;
        return false;
      }

      // 2) NO VALUE - no code and no discount indicators
      const textForParse = [rawTitle, rawSummary].join(" • ");
      if (hasNoValue(textForParse, hasCode)) {
        droppedNoValue++;
        return false;
      }

      return true;
    });

    console.log(`Filtered to ${validPromos.length} valid promos`);

    let deeplinksGenerated = 0;
    let withCoupons = 0;
    let withoutCoupons = 0;

    for (const promo of validPromos) {
      try {
        const rawTitle = (promo.title || "").trim();
        const rawSummary = (promo.summary || promo.headline || "").trim();
        const textForParse = [rawTitle, rawSummary].join(" • ");

        // Parse promo signals
        const parsed = parsePromoText(textForParse);

        // Get brand info
        const brand = cleanPlatformName(promo.ia_advertisers?.name || "Unknown");
        const platform = brand;
        const country = promo.country || "MY";
        const hasCode = !!promo.code;

        // Build deal_key
        const dealKey = buildDealKey(parsed);

        // Build promo_fingerprint
        let promoFingerprint: string | null = null;
        if (hasCode && promo.code) {
          promoFingerprint = `${platform.toLowerCase()}|${promo.code.toLowerCase()}`;
        } else if (dealKey) {
          promoFingerprint = `${platform.toLowerCase()}|${dealKey}`;
        }

        // Skip if no fingerprint (shouldn't happen after filters)
        if (!promoFingerprint) {
          droppedNoValue++;
          continue;
        }

        // Check for existing deal with same fingerprint in last 45 days
        const cutoff = new Date(Date.now() - 45 * 24 * 60 * 60 * 1000).toISOString();
        const { data: existing } = await supabase
          .from("deals_feed")
          .select("id, score, expires_at")
          .eq("platform", platform)
          .eq("promo_fingerprint", promoFingerprint)
          .gte("created_at", cutoff)
          .order("score", { ascending: false })
          .limit(1)
          .maybeSingle();

        // Generate title, subtitle, tags
        const title = buildTitle(parsed, brand, country);
        const subtitle = buildSubtitle(parsed, rawSummary);
        const tags = buildTags(parsed, country);

        // Calculate score
        const expiresAt = promo.ends_at ? new Date(promo.ends_at) : undefined;
        const score = calculateScore(parsed, hasCode, title, expiresAt);

        // If existing deal has higher score, skip this one
        if (existing && existing.score >= score) {
          droppedDuplicate++;
          continue;
        }

        // Check advertiser count limit (max 3 per advertiser)
        const advertiserKey = platform.toLowerCase();
        perAdvertiserCount[advertiserKey] = (perAdvertiserCount[advertiserKey] || 0);
        if (perAdvertiserCount[advertiserKey] >= 3) {
          droppedDuplicate++;
          continue;
        }

        // If we have existing with lower score, delete it
        if (existing) {
          await supabase.from("deals_feed").delete().eq("id", existing.id);
        }

        // Generate deeplink
        const deeplinkPayload = {
          promo_id: promo.id,
          offer_id: promo.offer_id,
          raw_url: promo.landing_url,
          aff_sub: 'dealsgrid',
          aff_sub2: `promo_${promo.id}`,
          aff_sub3: promo.offer_id.toString(),
          aff_sub4: 'promo',
        };

        const deeplinkRes = await supabase.functions.invoke('ia-deeplink-generate', {
          body: deeplinkPayload,
        });

        if (deeplinkRes.error || !deeplinkRes.data?.deeplink_id) {
          console.warn(`Failed to generate deeplink for promo ${promo.id}`);
          continue;
        }

        const { deeplink_id, deeplink_type } = deeplinkRes.data;
        deeplinksGenerated++;

        // Upsert into deals_feed
        const { error: upsertError } = await supabase.from("deals_feed").upsert(
          {
            offer_id: promo.offer_id,
            deeplink_id,
            primary_promo_id: promo.id,
            title,
            subtitle,
            badge: hasCode ? "Code" : "Campaign",
            tags,
            image_url: promo.image_url,
            platform,
            country,
            has_coupon: hasCode,
            expires_at: promo.ends_at,
            score,
            quality_score: score,
            rotation_batch: rotationBatch,
            deeplink_type,
            source: 'IA',
            promo_fingerprint: promoFingerprint,
            deal_key: dealKey,
          },
          { onConflict: "offer_id,deeplink_id", ignoreDuplicates: false }
        );

        if (upsertError) {
          console.error(`❌ Failed to upsert deal for promo ${promo.id}:`, upsertError);
          continue;
        }

        // Update counters
        kept++;
        perAdvertiserCount[advertiserKey] = perAdvertiserCount[advertiserKey] + 1;
        if (hasCode) withCoupons++;
        else withoutCoupons++;

      } catch (err) {
        console.error(`Error processing promo ${promo.id}:`, err);
      }
    }

    console.log('=== Feed Build Summary ===');
    console.log(`Total promos fetched: ${promos.length}`);
    console.log(`Dropped (blacklist): ${droppedBlacklist}`);
    console.log(`Dropped (no value): ${droppedNoValue}`);
    console.log(`Dropped (duplicate): ${droppedDuplicate}`);
    console.log(`Deals kept: ${kept}`);
    console.log(`Deeplinks generated: ${deeplinksGenerated}`);
    console.log(`- With coupons: ${withCoupons}`);
    console.log(`- Without coupons: ${withoutCoupons}`);
    console.log('=== Feed Build Summary ===');

    return new Response(JSON.stringify({
      success: true,
      total_promos: promos.length,
      dropped_blacklist: droppedBlacklist,
      dropped_no_value: droppedNoValue,
      dropped_duplicate: droppedDuplicate,
      deals_kept: kept,
      deals_with_coupons: withCoupons,
      deeplinks_generated: deeplinksGenerated,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error building deals feed:', error);
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : String(error) }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
