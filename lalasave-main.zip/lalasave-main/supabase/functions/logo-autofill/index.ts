import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

type LogoSource = 'uploaded' | 'resolver' | 'vision_crop' | 'generated' | 'none';

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Normalize merchant name for caching
function normalizeMerchantKey(merchant: string): string {
  return merchant
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, "")
    .replace(/\s+/g, "_")
    .trim();
}

// Fetch with retry and timeout
async function fetchWithRetry(
  url: string,
  options: RequestInit = {},
  retries = 2,
  timeout = 4500
): Promise<Response> {
  for (let i = 0; i <= retries; i++) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeout);

      const response = await fetch(url, {
        ...options,
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (response.ok) return response;
    } catch (err) {
      if (i === retries) throw err;
      await new Promise((r) => setTimeout(r, 500 * (i + 1)));
    }
  }
  throw new Error("Max retries reached");
}

// Get file extension from content type
function getExtensionFromContentType(contentType: string): string {
  if (contentType.includes("svg")) return "svg";
  if (contentType.includes("png")) return "png";
  if (contentType.includes("jpeg") || contentType.includes("jpg")) return "jpg";
  if (contentType.includes("webp")) return "webp";
  return "png";
}

// Convert image to PNG
async function convertToPNG(arrayBuffer: ArrayBuffer): Promise<ArrayBuffer> {
  // For now, just return as-is. In production, use a proper image conversion library
  return arrayBuffer;
}

// Infer domains from merchant name
function inferDomains(merchant: string): string[] {
  const normalized = merchant.toLowerCase().replace(/[^a-z0-9]/g, "");
  return [
    `${normalized}.com`,
    `${normalized}.co`,
    `${normalized}.net`,
    `${normalized}.com.my`,
    `${normalized}.com.sg`,
    `${normalized}.co.id`,
    `${normalized}.com.ph`,
    `${normalized}.co.th`,
    `${normalized}.com.vn`,
  ];
}

// Upload logo to storage and cache
async function uploadAndCache(
  supabase: any,
  merchantKey: string,
  domain: string | undefined,
  voucherId: string,
  arrayBuffer: ArrayBuffer,
  source: LogoSource
): Promise<{ logoPath: string; signedUrl: string }> {
  const logoPath = `${merchantKey}.png`;

  console.log(`Uploading logo to storage: ${logoPath}`);

  // Upload to storage
  const { error: uploadError } = await supabase.storage
    .from("logos")
    .upload(logoPath, arrayBuffer, {
      contentType: "image/png",
      upsert: true,
    });

  if (uploadError) {
    console.error("Upload error:", uploadError);
    throw uploadError;
  }

  // Update cache
  await supabase
    .from("merchant_logo_cache")
    .upsert({
      merchant_key: merchantKey,
      domain: domain || null,
      logo_path: logoPath,
      logo_source: source,
      updated_at: new Date().toISOString(),
    });

  // Update voucher
  await supabase
    .from("vouchers")
    .update({
      merchant_logo_path: logoPath,
      logo_source: source,
      logo_cache_updated_at: new Date().toISOString(),
    })
    .eq("voucher_id", voucherId);

  // Generate signed URL
  const { data: urlData } = await supabase.storage
    .from("logos")
    .createSignedUrl(logoPath, 7200);

  return { logoPath, signedUrl: urlData?.signedUrl || "" };
}

// Try web sources
async function tryWebSources(
  merchant: string,
  domain?: string
): Promise<{ arrayBuffer: ArrayBuffer; source: LogoSource } | null> {
  const domains = domain ? [domain, ...inferDomains(merchant)] : inferDomains(merchant);

  console.log("Trying domains:", domains.slice(0, 5).join(", "));

  // Try Clearbit
  for (const d of domains) {
    try {
      const url = `https://logo.clearbit.com/${d}`;
      const resp = await fetchWithRetry(url);
      if (resp.ok && resp.headers.get("content-type")?.includes("image")) {
        console.log(`Clearbit success for ${d}`);
        const source: LogoSource = 'resolver';
        return {
          arrayBuffer: await resp.arrayBuffer(),
          source,
        };
      }
    } catch {}
  }

  // Try Unavatar
  for (const d of domains) {
    try {
      const url = `https://unavatar.io/${d}`;
      const resp = await fetchWithRetry(url);
      if (resp.ok && resp.headers.get("content-type")?.includes("image")) {
        console.log(`Unavatar success for ${d}`);
        const source: LogoSource = 'resolver';
        return {
          arrayBuffer: await resp.arrayBuffer(),
          source,
        };
      }
    } catch {}
  }

  // Try Google Favicon
  for (const d of domains) {
    try {
      const url = `https://www.google.com/s2/favicons?domain=${d}&sz=256`;
      const resp = await fetchWithRetry(url);
      if (resp.ok && resp.headers.get("content-type")?.includes("image")) {
        const buffer = await resp.arrayBuffer();
        // Check if it's not a generic icon (too small)
        if (buffer.byteLength > 1000) {
          console.log(`Google Favicon success for ${d}`);
          const source: LogoSource = 'resolver';
          return { arrayBuffer: buffer, source };
        }
      }
    } catch {}
  }

  return null;
}

// Generate AI logo
async function generateAILogo(
  merchant: string,
  supabase: any,
  merchantKey: string,
  voucherId: string
): Promise<{ logoPath: string; signedUrl: string }> {
  console.log(`Generating AI logo for ${merchant}`);

  const OPENAI_API_KEY = Deno.env.get("OPENAI_API_KEY");
  if (!OPENAI_API_KEY) {
    throw new Error("OPENAI_API_KEY not configured");
  }

  const firstLetter = merchant.charAt(0).toUpperCase();

  const prompt = `Design a modern, flat circular app icon for the merchant named '${merchant}'. Use a soft blue gradient background and a bold initial letter '${firstLetter}'. No brand wordmarks or trademarked shapes. Simple, clean, professional.`;

  const response = await fetch("https://api.openai.com/v1/images/generations", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${OPENAI_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "gpt-image-1",
      prompt,
      n: 1,
      size: "256x256",
      output_format: "png",
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    console.error("OpenAI error:", error);
    throw new Error(`OpenAI API error: ${response.status}`);
  }

  const data = await response.json();
  const imageUrl = data.data?.[0]?.url;

  if (!imageUrl) {
    throw new Error("No image URL in OpenAI response");
  }

  // Fetch the generated image
  const imageResponse = await fetch(imageUrl);
  const arrayBuffer = await imageResponse.arrayBuffer();
  const source: LogoSource = 'generated';

  return uploadAndCache(supabase, merchantKey, undefined, voucherId, arrayBuffer, source);
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { voucherId, merchant, domain, voucherImagePath, force } = await req.json();

    if (!voucherId || !merchant) {
      return new Response(
        JSON.stringify({ error: "voucherId and merchant are required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    const merchantKey = normalizeMerchantKey(merchant);

    console.log(`Logo autofill request: merchant="${merchant}", key="${merchantKey}", force=${force}`);

    // Check cache
    if (!force) {
      const { data: cached } = await supabase
        .from("merchant_logo_cache")
        .select("logo_path, logo_source")
        .eq("merchant_key", merchantKey)
        .maybeSingle();

      if (cached?.logo_path) {
        console.log(`Cache hit for ${merchantKey}: ${cached.logo_source}`);

        // Update voucher to use cached logo
        await supabase
          .from("vouchers")
          .update({
            merchant_logo_path: cached.logo_path,
            logo_source: cached.logo_source,
            logo_cache_updated_at: new Date().toISOString(),
          })
          .eq("voucher_id", voucherId);

        return new Response(
          JSON.stringify({
            ok: true,
            logoPath: cached.logo_path,
            source: cached.logo_source,
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    }

    // Try web sources
    const webResult = await tryWebSources(merchant, domain);
    if (webResult) {
      const { logoPath, signedUrl } = await uploadAndCache(
        supabase,
        merchantKey,
        domain,
        voucherId,
        webResult.arrayBuffer,
        webResult.source as LogoSource
      );

      return new Response(
        JSON.stringify({ ok: true, logoPath, source: "resolver" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // TODO: Vision crop from voucher image (requires image processing library)
    // For now, skip to AI generation

    // AI generation fallback
    try {
      const { logoPath, signedUrl } = await generateAILogo(merchant, supabase, merchantKey, voucherId);

      return new Response(
        JSON.stringify({ ok: true, logoPath, source: "generated" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    } catch (aiError) {
      console.error("AI generation failed:", aiError);

      // Ultimate fallback: return ok but no logo
      const source: LogoSource = 'none';
      return new Response(
        JSON.stringify({ ok: true, logoPath: null, source }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
  } catch (error: any) {
    console.error("Logo autofill error:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
