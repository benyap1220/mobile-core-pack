import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

Deno.serve(async () => {
  try {
    console.log('[seed-lazada] Starting Lazada logo seeding...');
    
    const brand_slug = 'lazada';
    const storage_path = 'lazada.png'; // Official 91KB heart logo already in storage
    
    console.log(`[seed-lazada] Using existing official logo at ${storage_path}`);
    
    // 1. Verify the file exists
    const { data: fileCheck } = await supabase.storage
      .from("brand-logos")
      .list('', { search: storage_path });
    
    if (!fileCheck || fileCheck.length === 0) {
      throw new Error(`Logo file ${storage_path} not found in storage!`);
    }
    
    console.log(`[seed-lazada] Verified file exists (${fileCheck[0].metadata?.size || 'unknown'} bytes)`);
    
    // 2. Insert/update override entry
    const { error: upsertError } = await supabase
      .from("brand_logo_overrides")
      .upsert({
        brand_slug,
        storage_path,
        mime: 'image/png',
        updated_at: new Date().toISOString(),
      });
    
    if (upsertError) throw upsertError;
    console.log(`[seed-lazada] Created override entry for official logo`);
    
    // 3. Purge ALL bad cache entries (including logistics variants)
    const { error: deleteError } = await supabase
      .from("merchant_logo_cache")
      .delete()
      .eq("merchant_slug", brand_slug);
    
    if (deleteError) console.warn('[seed-lazada] Cache delete warning:', deleteError);
    
    // Also purge any accidentally cached logistics variants
    await supabase
      .from("merchant_logo_cache")
      .delete()
      .or("public_url.ilike.%logistics%,public_url.ilike.%lex%");
    
    console.log(`[seed-lazada] Purged old cache entries`);
    
    // 4. Get public URL
    const { data: pub } = supabase.storage
      .from("brand-logos")
      .getPublicUrl(storage_path);
    
    console.log(`[seed-lazada] Public URL: ${pub.publicUrl}`);
    
    // 5. Call resolve-logo to populate cache with override
    const resolveRes = await fetch(
      `${Deno.env.get("SUPABASE_URL")}/functions/v1/resolve-logo`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "apikey": Deno.env.get("SUPABASE_ANON_KEY")!,
        },
        body: JSON.stringify({ slug: brand_slug }),
      }
    );
    
    const resolveData = await resolveRes.json();
    console.log(`[seed-lazada] Resolve result:`, resolveData);
    
    // Verify override is being used
    if (resolveData.source !== 'override') {
      console.warn(`[seed-lazada] WARNING: Expected source='override', got '${resolveData.source}'`);
    }
    
    return new Response(JSON.stringify({
      success: true,
      brand_slug,
      publicUrl: pub.publicUrl,
      storage_path,
      override_active: resolveData.source === 'override',
      resolveResult: resolveData
    }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("[seed-lazada]", e);
    return new Response(JSON.stringify({ 
      success: false,
      error: String(e) 
    }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
});
