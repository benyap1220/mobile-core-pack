import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, serviceKey);

    const { advertiser_id, name, domain, force } = await req.json();

    if (!advertiser_id || !name) {
      return new Response(
        JSON.stringify({ error: 'advertiser_id and name required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Resolving logo for advertiser: ${name}`);

    // Call the existing resolve-logo function
    const resolveLogoUrl = `${supabaseUrl}/functions/v1/resolve-logo`;
    const resolveResponse = await fetch(resolveLogoUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${serviceKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        slug: name.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
        domain: domain || null,
        force: force || false,
      }),
    });

    if (!resolveResponse.ok) {
      throw new Error(`resolve-logo failed: ${resolveResponse.status}`);
    }

    const { logo_url, source } = await resolveResponse.json();

    // Update the advertiser with the resolved logo
    const { error: updateError } = await supabase
      .from('ia_advertisers')
      .update({ 
        logo_url,
        logo_source: source,
        logo_updated_at: new Date().toISOString(),
      })
      .eq('id', advertiser_id);

    if (updateError) {
      console.error('Error updating advertiser logo:', updateError);
      throw updateError;
    }

    console.log(`✓ Logo resolved for ${name}: ${logo_url} (${source})`);

    return new Response(
      JSON.stringify({ ok: true, logo_url, source }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error resolving IA logo:', error);
    const message = error instanceof Error ? error.message : String(error);
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
