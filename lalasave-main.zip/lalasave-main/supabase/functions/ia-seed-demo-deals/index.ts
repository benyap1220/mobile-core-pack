import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    console.log('Seeding 5 demo deals...');

    // Demo data with known good URLs
    const demoDeals = [
      {
        offer_id: 999001,
        title: 'Lazada Flash Sale - Up to 70% OFF',
        subtitle: 'Electronics, Fashion & More',
        badge: 'Hot Deal',
        tags: ['flash-sale', 'electronics'],
        image_url: 'https://laz-img-cdn.alicdn.com/images/ims-web/TB1T458bjDpK1RjSZFrXXa78VXa.png',
        platform: 'Lazada',
        country: 'MY',
        score: 0.85,
      },
      {
        offer_id: 999002,
        title: 'Shopee 11.11 Mega Sale',
        subtitle: 'Biggest Deals of the Year',
        badge: '11.11 Sale',
        tags: ['mega-sale', 'fashion'],
        image_url: 'https://cf.shopee.com.my/file/14c52c08c56b78b2c6f6f81dbe5cfb83',
        platform: 'Shopee',
        country: 'MY',
        score: 0.90,
      },
      {
        offer_id: 999003,
        title: 'Grab Food RM10 OFF First Order',
        subtitle: 'New Users Only',
        badge: 'New User',
        tags: ['food-delivery', 'new-user'],
        image_url: 'https://d1rgpf387mknul.cloudfront.net/products/PDP/0/sg-11134004-7rbmc-lrxmhd2rn0j9c6/lg.jpg',
        platform: 'Grab',
        country: 'MY',
        score: 0.75,
      },
      {
        offer_id: 999004,
        title: 'Foodpanda Exclusive Vouchers',
        subtitle: 'Free Delivery on All Orders',
        badge: 'Free Delivery',
        tags: ['food-delivery', 'free-shipping'],
        image_url: 'https://images.deliveryhero.io/image/foodpanda/hero-images/homepage-refresh/hp-refresh-my-opt.jpg',
        platform: 'Foodpanda',
        country: 'MY',
        score: 0.70,
      },
      {
        offer_id: 999005,
        title: 'Temu Super Deals - Shop Like a Billionaire',
        subtitle: 'Free Shipping Worldwide',
        badge: 'Free Ship',
        tags: ['marketplace', 'fashion'],
        image_url: 'https://aimg.kwcdn.com/upload_aimg/temu/478e3cd4-bb3c-4e9c-87ee-2dc3b5ddeb74.png',
        platform: 'Temu',
        country: 'MY',
        score: 0.65,
      },
    ];

    // Create demo deeplinks first
    const demoDeeplinks: any[] = [];
    
    for (const deal of demoDeals) {
      const demoUrl = `https://example.com/${deal.platform.toLowerCase()}/promo`;
      
      const { data: insertedDeeplink, error: deeplinkError } = await supabase
        .from('ia_deeplinks')
        .insert({
          offer_id: deal.offer_id,
          raw_url: demoUrl,
          deeplink_url: demoUrl, // In demo, just use same URL
          aff_sub: 'dealsgrid',
          aff_sub2: 'demo',
          aff_sub3: String(deal.offer_id),
          aff_sub4: 'promo',
          deeplink_type: 'standard',
        })
        .select()
        .single();

      if (deeplinkError) {
        console.error('Error creating demo deeplink:', deeplinkError);
        continue;
      }

      demoDeeplinks.push(insertedDeeplink);
    }

    // Create demo deals
    let inserted = 0;
    
    for (let i = 0; i < demoDeals.length; i++) {
      const deal = demoDeals[i];
      const deeplink = demoDeeplinks[i];
      
      if (!deeplink) continue;

      const { error } = await supabase
        .from('deals_feed')
        .upsert({
          offer_id: deal.offer_id,
          deeplink_id: deeplink.id,
          title: deal.title,
          subtitle: deal.subtitle,
          badge: deal.badge,
          tags: deal.tags,
          image_url: deal.image_url,
          platform: deal.platform,
          country: deal.country,
          source: 'DEMO',
          score: deal.score,
        }, { onConflict: 'offer_id,deeplink_id', ignoreDuplicates: false });

      if (!error) inserted++;
    }

    console.log(`Demo seed complete: ${inserted} deals created`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        demo_deals_created: inserted,
        message: `Created ${inserted} demo deals for testing`,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error seeding demo deals:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';

    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
