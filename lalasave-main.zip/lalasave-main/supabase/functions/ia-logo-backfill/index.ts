import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, serviceKey);

    const { limit = 50 } = await req.json().catch(() => ({}));

    // Find advertisers without logos or with stale logos (>90 days)
    const staleDate = new Date();
    staleDate.setDate(staleDate.getDate() - 90);

    const { data: advertisers, error } = await supabase
      .from('ia_advertisers')
      .select('id, name, offer_id')
      .is('logo_url', null)
      .eq('approved', true)
      .limit(limit);

    if (error) throw error;

    if (!advertisers || advertisers.length === 0) {
      return new Response(
        JSON.stringify({ 
          ok: true, 
          message: 'No advertisers need logo updates',
          processed: 0 
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Processing ${advertisers.length} advertisers for logo resolution...`);

    const results = {
      total: advertisers.length,
      success: 0,
      failed: 0,
      errors: [] as string[],
    };

    // Process each advertiser
    for (const advertiser of advertisers) {
      try {
        // Try to infer domain from advertiser name
        const domain = inferDomain(advertiser.name);

        const resolveLogoUrl = `${supabaseUrl}/functions/v1/resolve-logo`;
        const response = await fetch(resolveLogoUrl, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${serviceKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            slug: advertiser.name.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
            domain: domain || null,
            force: false,
          }),
        });

        if (!response.ok) {
          throw new Error(`resolve-logo returned ${response.status}`);
        }

        const { logo_url, source } = await response.json();

        // Update advertiser
        const { error: updateError } = await supabase
          .from('ia_advertisers')
          .update({
            logo_url,
            logo_source: source,
            logo_updated_at: new Date().toISOString(),
          })
          .eq('id', advertiser.id);

        if (updateError) throw updateError;

        console.log(`✓ ${advertiser.name}: ${source}`);
        results.success++;

        // Rate limit: 5 requests per second
        await new Promise(resolve => setTimeout(resolve, 200));

      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        console.error(`✗ ${advertiser.name}:`, message);
        results.failed++;
        results.errors.push(`${advertiser.name}: ${message}`);
      }
    }

    return new Response(
      JSON.stringify({
        ok: true,
        ...results,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Backfill error:', error);
    const message = error instanceof Error ? error.message : String(error);
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

function inferDomain(name: string): string | null {
  const lower = name.toLowerCase();
  
  // Known platform mappings
  const mappings: Record<string, string> = {
    'lazada': 'lazada.com.my',
    'shopee': 'shopee.com.my',
    'grab': 'grab.com',
    'foodpanda': 'foodpanda.my',
    'temu': 'temu.com',
    'amazon': 'amazon.com',
    'taobao': 'taobao.com',
    'zalora': 'zalora.com.my',
    'watsons': 'watsons.com.my',
    'uniqlo': 'uniqlo.com',
    'traveloka': 'traveloka.com',
    'airasia': 'airasia.com',
  };

  for (const [key, domain] of Object.entries(mappings)) {
    if (lower.includes(key)) {
      return domain;
    }
  }

  // Try to guess domain from name
  const cleaned = lower.replace(/[^a-z0-9]/g, '');
  return cleaned ? `${cleaned}.com` : null;
}
