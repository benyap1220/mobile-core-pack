import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    console.log("Starting logo backfill...");

    // Find vouchers needing logos
    const { data: vouchers, error } = await supabase
      .from("vouchers")
      .select("voucher_id, merchant, merchant_domain")
      .or(
        "merchant_logo_path.is.null,logo_cache_updated_at.lt." +
          new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString()
      )
      .limit(100);

    if (error) throw error;

    if (!vouchers || vouchers.length === 0) {
      console.log("No vouchers need logo backfill");
      return new Response(
        JSON.stringify({ ok: true, processed: 0 }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`Backfilling logos for ${vouchers.length} vouchers`);

    let processed = 0;
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL");

    for (const voucher of vouchers) {
      try {
        // Rate limit: 200ms between requests
        await new Promise((r) => setTimeout(r, 200));

        // Call logo-autofill function
        const response = await fetch(`${SUPABASE_URL}/functions/v1/logo-autofill`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")}`,
          },
          body: JSON.stringify({
            voucherId: voucher.voucher_id,
            merchant: voucher.merchant,
            domain: voucher.merchant_domain,
          }),
        });

        if (response.ok) {
          processed++;
          console.log(`✓ Processed ${voucher.merchant}`);
        } else {
          console.error(`✗ Failed ${voucher.merchant}`);
        }
      } catch (err) {
        console.error(`Error processing ${voucher.merchant}:`, err);
      }
    }

    console.log(`Backfill complete: ${processed}/${vouchers.length} processed`);

    return new Response(
      JSON.stringify({ ok: true, processed, total: vouchers.length }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: any) {
    console.error("Logo backfill error:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
