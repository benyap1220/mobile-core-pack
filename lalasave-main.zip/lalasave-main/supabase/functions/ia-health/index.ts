import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Get advertiser counts
    const { count: totalAdvertisers } = await supabase
      .from('ia_advertisers')
      .select('*', { count: 'exact', head: true });

    const { count: approvedAdvertisers } = await supabase
      .from('ia_advertisers')
      .select('*', { count: 'exact', head: true })
      .eq('approved', true);

    // Get landing counts
    const { count: totalLandings } = await supabase
      .from('ia_landings')
      .select('*', { count: 'exact', head: true });

    const { count: deeplinkableLandings } = await supabase
      .from('ia_landings')
      .select('*', { count: 'exact', head: true })
      .eq('deeplinkable', true);

    const { data: lastLandingCheck } = await supabase
      .from('ia_landings')
      .select('last_checked_at')
      .order('last_checked_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    // Get deeplink counts
    const { count: totalDeeplinks } = await supabase
      .from('ia_deeplinks')
      .select('*', { count: 'exact', head: true });

    const { data: deeplinksByType } = await supabase
      .from('ia_deeplinks')
      .select('deeplink_type')
      .then(res => {
        const counts: Record<string, number> = {};
        res.data?.forEach(row => {
          const type = row.deeplink_type || 'standard';
          counts[type] = (counts[type] || 0) + 1;
        });
        return counts;
      });

    // Get deals feed counts
    const { count: totalDeals } = await supabase
      .from('deals_feed')
      .select('*', { count: 'exact', head: true });

    const { data: latestDeal } = await supabase
      .from('deals_feed')
      .select('created_at, rotation_batch')
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    // Get click/impression counts (last 24h)
    const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();

    const { count: clicks24h } = await supabase
      .from('aff_clicks')
      .select('*', { count: 'exact', head: true })
      .gte('created_at', yesterday);

    const { count: impressions24h } = await supabase
      .from('aff_impressions')
      .select('*', { count: 'exact', head: true })
      .gte('created_at', yesterday);

    const health = {
      ia_advertisers: {
        total: totalAdvertisers || 0,
        approved: approvedAdvertisers || 0,
      },
      ia_landings: {
        total: totalLandings || 0,
        deeplinkable: deeplinkableLandings || 0,
        last_checked_at: lastLandingCheck?.last_checked_at || null,
      },
      ia_deeplinks: {
        total: totalDeeplinks || 0,
        by_type: deeplinksByType || {},
      },
      deals_feed: {
        total: totalDeals || 0,
        current_rotation_batch: latestDeal?.rotation_batch || null,
        latest_created_at: latestDeal?.created_at || null,
      },
      analytics_24h: {
        clicks: clicks24h || 0,
        impressions: impressions24h || 0,
      },
      status: (totalDeals || 0) > 0 ? 'healthy' : 'needs_data',
      timestamp: new Date().toISOString(),
    };

    console.log('Health check:', JSON.stringify(health, null, 2));

    return new Response(
      JSON.stringify(health),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in health check:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';

    return new Response(
      JSON.stringify({ 
        error: errorMessage,
        status: 'error',
        timestamp: new Date().toISOString(),
      }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
