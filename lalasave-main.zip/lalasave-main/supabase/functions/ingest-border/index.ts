import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

/******************************************************************************
 * SIMPLIFIED PNG BORDER UPLOAD - No Vectorization
 ******************************************************************************/

interface ShapeConfig {
  viewBox: { w: number; h: number };
  safeInset: number;
  cornerRadius: number;
}

const DEALS_CFG: ShapeConfig = {
  viewBox: { w: 1200, h: 675 },
  safeInset: 18,
  cornerRadius: 24,
};

const HOME_CFG: ShapeConfig = {
  viewBox: { w: 1080, h: 1280 },
  safeInset: 20,
  cornerRadius: 24,
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseClient = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_ANON_KEY") ?? "",
    {
      global: {
        headers: { Authorization: req.headers.get("Authorization")! },
      },
    }
  );

  try {
    // Parse request body
    const body = await req.json();
    const {
      filePath,
      options = {},
    } = body;

    if (!filePath || typeof filePath !== "string") {
      return new Response(
        JSON.stringify({ error: "Missing or invalid filePath" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const target = options.target || 'deals';
    const cfg = target === 'home' ? HOME_CFG : DEALS_CFG;

    const {
      styleTag = "decorative",
      layoutMode = "full-overlay",
      contentInset = cfg.safeInset,
      scaleMode = "cover",
    } = options;

    console.log("📦 Simplified Border Upload");
    console.log(`Target: ${target}, Source: ${filePath}`);
    console.log(`Layout: ${layoutMode}, Padding: ${contentInset}px, Scale: ${scaleMode}`);

    // Generate unique prototype ID
    const prototypeId = crypto.randomUUID();

    // Step 1: Download source image from storage
    console.log("\n📥 Downloading source image...");
    const { data: sourceBlob, error: downloadError } = await supabaseClient.storage
      .from("borders")
      .download(filePath);

    if (downloadError || !sourceBlob) {
      console.error("❌ Download failed:", downloadError);
      return new Response(
        JSON.stringify({ error: "Failed to download source image" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const sourceBytes = new Uint8Array(await sourceBlob.arrayBuffer());
    console.log(`✓ Downloaded ${sourceBytes.length} bytes`);

    // Detect file extension
    const ext = filePath.toLowerCase().endsWith(".jpg") || 
                filePath.toLowerCase().endsWith(".jpeg") ? "jpg" : "png";

    // Step 2: Store image as-is in borders/{target}/{id}/original.{ext}
    console.log(`\n📤 Storing original image as ${ext}...`);
    const imagePath = `${target}/${prototypeId}/original.${ext}`;
    const { error: uploadError } = await supabaseClient.storage
      .from("borders")
      .upload(imagePath, sourceBytes, {
        contentType: ext === "jpg" ? "image/jpeg" : "image/png",
        upsert: true,
      });

    if (uploadError) {
      console.error("❌ Upload failed:", uploadError);
      return new Response(
        JSON.stringify({ error: "Failed to upload border image" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`✓ Stored at: ${imagePath}`);

    // Step 3: Create preview (same image)
    console.log("\n📸 Creating preview...");
    const previewPath = `${target}/${prototypeId}/preview.${ext}`;
    await supabaseClient.storage
      .from("borders_previews")
      .upload(previewPath, sourceBytes, {
        contentType: ext === "jpg" ? "image/jpeg" : "image/png",
        upsert: true,
      });

    // Step 4: Save metadata to border_prototypes
    console.log("\n💾 Saving prototype metadata...");
    const { data: prototype, error: dbError } = await supabaseClient
      .from("border_prototypes")
      .insert({
        id: prototypeId,
        title: options.title || "Untitled Border",
        style_tag: styleTag,
        layout_mode: layoutMode,
        image_path: imagePath,
        scale_mode: scaleMode,
        preview_path: previewPath,
        source_path: filePath,
        is_approved: false,
        target: target,
        view_box: cfg.viewBox,
        safe_area: {
          top: cfg.safeInset,
          right: cfg.safeInset,
          bottom: cfg.safeInset,
          left: cfg.safeInset,
        },
        frame_meta: {
          viewW: cfg.viewBox.w,
          viewH: cfg.viewBox.h,
          contentInset,
          cornerRadius: cfg.cornerRadius,
        },
      })
      .select()
      .single();

    if (dbError) {
      console.error("❌ Database insert failed:", dbError);
      return new Response(
        JSON.stringify({ error: "Failed to save border metadata" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("✅ Border prototype created successfully!");

    return new Response(
      JSON.stringify({
        success: true,
        prototypeId,
        imagePath,
        previewPath,
        layoutMode,
        contentPadding: contentInset,
        scaleMode,
        prototype,
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("❌ Unexpected error:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(
      JSON.stringify({ error: "Internal server error", details: errorMessage }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
