import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const RequestSchema = z.object({
  prototype_id: z.string().uuid(),
});

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Authenticate user
    const authHeader = req.headers.get("Authorization")!;
    const { data: { user }, error: authError } = await supabase.auth.getUser(
      authHeader.replace("Bearer ", "")
    );

    if (authError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Validate input
    const body = await req.json();
    const validation = RequestSchema.safeParse(body);
    if (!validation.success) {
      return new Response(
        JSON.stringify({ error: "Invalid request" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { prototype_id } = validation.data;

    // Get prototype
    const { data: prototype, error: fetchError } = await supabase
      .from("border_prototypes")
      .select("*")
      .eq("id", prototype_id)
      .single();

    if (fetchError || !prototype) {
      return new Response(
        JSON.stringify({ error: "Prototype not found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Create border_style from prototype
    const { data: borderStyle, error: styleError } = await supabase
      .from("border_styles")
      .insert({
        title: prototype.title,
        style_tag: prototype.style_tag,
        svg_path: prototype.svg_path,
        webm_path: prototype.webm_path,
        lottie_path: prototype.lottie_path,
        image_path: prototype.image_path,
        scale_mode: prototype.scale_mode,
        preview_path: prototype.preview_path,
        layout_mode: prototype.layout_mode,
        safe_area: prototype.safe_area,
        frame_meta: prototype.frame_meta,
        replace_base_frame: prototype.replace_base_frame,
        target: prototype.target,
        view_box: prototype.view_box,
        approved_by: user.id,
      })
      .select()
      .single();

    if (styleError) {
      throw new Error(`Failed to create border style: ${styleError.message}`);
    }

    // Mark prototype as approved
    const { error: updateError } = await supabase
      .from("border_prototypes")
      .update({ is_approved: true })
      .eq("id", prototype_id);

    if (updateError) {
      throw new Error(`Failed to update prototype: ${updateError.message}`);
    }

    return new Response(
      JSON.stringify({
        success: true,
        border_style_id: borderStyle.id,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Approve error:", error instanceof Error ? error.message : "Unknown");
    return new Response(
      JSON.stringify({ error: "Approval failed" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
