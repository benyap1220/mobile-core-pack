import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const REGIONAL_TLDS = [".com", ".co", ".net", ".com.my", ".com.sg", ".co.id", ".com.ph", ".co.th", ".com.vn"];

// Input validation schema
const RequestSchema = z.object({
  voucherId: z.string().uuid({ message: "Invalid voucher ID" }),
  merchant: z.string().min(1).max(100, { message: "Merchant name too long" }),
  domain: z.string().max(100).optional(),
  force: z.boolean().optional(),
});

// Utility: Fetch with retry and timeout
async function fetchWithRetry(
  url: string,
  options: RequestInit = {},
  timeoutMs = 4500,
  retries = 2,
  backoffMs = 300
): Promise<Response | null> {
  for (let i = 0; i <= retries; i++) {
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), timeoutMs);
      
      const response = await fetch(url, {
        ...options,
        signal: controller.signal,
      });
      
      clearTimeout(timeout);
      
      if (response.ok) return response;
      if (i < retries) await new Promise(r => setTimeout(r, backoffMs * (i + 1)));
    } catch (error) {
      console.log(`Fetch attempt ${i + 1} failed for ${url}:`, error);
      if (i < retries) await new Promise(r => setTimeout(r, backoffMs * (i + 1)));
    }
  }
  return null;
}

// Normalize merchant name for caching
function normalizeMerchantKey(merchant: string): string {
  return merchant
    .trim()
    .toLowerCase()
    .replace(/[^\w\s]/g, "") // Remove punctuation/emoji
    .replace(/\s+/g, " ") // Collapse spaces
    .trim();
}

// Get file extension from content-type
function getExtensionFromContentType(contentType: string): string {
  if (contentType.includes("svg")) return "svg";
  if (contentType.includes("jpeg") || contentType.includes("jpg")) return "jpg";
  if (contentType.includes("png")) return "png";
  if (contentType.includes("ico")) return "ico";
  if (contentType.includes("webp")) return "webp";
  return "png";
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const openaiKey = Deno.env.get("OPENAI_API_KEY");
    
    const authHeader = req.headers.get("Authorization")!;
    const supabaseClient = createClient(supabaseUrl, supabaseKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: { user }, error: userError } = await supabaseClient.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({ ok: false, reason: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json();
    
    // Validate input
    const validation = RequestSchema.safeParse(body);
    if (!validation.success) {
      console.error("Validation error:", validation.error.format());
      return new Response(JSON.stringify({ ok: false, reason: "Invalid request data" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { voucherId, merchant, domain, force } = validation.data;
    const merchantKey = normalizeMerchantKey(merchant);
    console.log(`Logo resolver: merchant="${merchant.substring(0, 50)}", force=${force}`);

    // Check user settings for logo lookup
    const { data: settings } = await supabaseClient
      .from("user_settings")
      .select("logo_lookup_enabled")
      .eq("user_id", user.id)
      .maybeSingle();

    const logoLookupEnabled = settings?.logo_lookup_enabled !== false;

    // Step 1: Cache hit (if not forced)
    if (!force && logoLookupEnabled) {
      const { data: cached } = await supabaseClient
        .from("merchant_logo_cache")
        .select("logo_path, logo_source")
        .eq("merchant_key", merchantKey)
        .maybeSingle();

      if (cached?.logo_path) {
        console.log(`Cache hit for ${merchantKey}: ${cached.logo_source}`);
        
        // Update voucher with storage path (not signed URL)
        await supabaseClient
          .from("vouchers")
          .update({
            merchant_logo_path: cached.logo_path,
            logo_source: cached.logo_source,
            logo_cache_updated_at: new Date().toISOString(),
          })
          .eq("voucher_id", voucherId);

        // Create signed URL for response
        const { data: signedUrlData } = await supabaseClient.storage
          .from("logos")
          .createSignedUrl(cached.logo_path, 3600);

        return new Response(
          JSON.stringify({ ok: true, logoUrl: signedUrlData?.signedUrl || cached.logo_path, source: cached.logo_source }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    }

    // Step 2: Check for manual upload
    const { data: voucher } = await supabaseClient
      .from("vouchers")
      .select("merchant_logo_path, logo_source")
      .eq("voucher_id", voucherId)
      .maybeSingle();

    if (voucher?.logo_source === "uploaded" && voucher.merchant_logo_path) {
      console.log(`Manual upload exists for ${voucherId}`);
      return new Response(
        JSON.stringify({ ok: true, logoUrl: voucher.merchant_logo_path, source: "uploaded" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!logoLookupEnabled) {
      // Skip web sources, go straight to AI generation
      console.log("Logo lookup disabled, generating AI logo");
      return await generateAILogo(supabaseClient, voucherId, merchant, merchantKey, user.id, openaiKey);
    }

    // Generate candidate domains
    const domains = domain ? [domain] : inferDomains(merchant);
    console.log(`Trying domains: ${domains.join(", ")}`);

    // Step 3: Try Clearbit
    for (const d of domains) {
      const clearbitUrl = `https://logo.clearbit.com/${d}`;
      const response = await fetchWithRetry(clearbitUrl);
      
      if (response && response.headers.get("content-type")?.startsWith("image/")) {
        console.log(`Clearbit success for ${d}`);
        const arrayBuffer = await response.arrayBuffer();
        return await uploadAndCache(
          supabaseClient,
          voucherId,
          merchant,
          merchantKey,
          user.id,
          d,
          arrayBuffer,
          response.headers.get("content-type") || "image/png",
          "clearbit"
        );
      }
    }

    // Step 4: Try Unavatar
    for (const d of [domain, merchant].filter(Boolean)) {
      const unavatarUrl = `https://unavatar.io/${d}`;
      const response = await fetchWithRetry(unavatarUrl);
      
      if (response && response.headers.get("content-type")?.startsWith("image/")) {
        console.log(`Unavatar success for ${d}`);
        const arrayBuffer = await response.arrayBuffer();
        return await uploadAndCache(
          supabaseClient,
          voucherId,
          merchant,
          merchantKey,
          user.id,
          d || "unavatar",
          arrayBuffer,
          response.headers.get("content-type") || "image/png",
          "unavatar"
        );
      }
    }

    // Step 5: Try Favicon providers (skip .ico, prefer PNG)
    for (const d of domains) {
      // Only use Google favicons which returns PNG at higher resolution
      const faviconUrl = `https://www.google.com/s2/favicons?domain=${d}&sz=128`;
      const response = await fetchWithRetry(faviconUrl);
      
      if (response && response.headers.get("content-type")?.startsWith("image/")) {
        const contentType = response.headers.get("content-type") || "";
        // Skip .ico files as they render poorly
        if (contentType.includes("ico")) {
          console.log(`Skipping .ico for ${d}`);
          continue;
        }
        
        console.log(`Favicon success for ${d}`);
        const arrayBuffer = await response.arrayBuffer();
        return await uploadAndCache(
          supabaseClient,
          voucherId,
          merchant,
          merchantKey,
          user.id,
          d,
          arrayBuffer,
          "image/png",
          "favicon"
        );
      }
    }

    // Step 6: AI-generated fallback (always succeeds)
    console.log("All sources failed, generating AI logo");
    return await generateAILogo(supabaseClient, voucherId, merchant, merchantKey, user.id, openaiKey);

  } catch (error) {
    console.error("Logo resolver error:", error instanceof Error ? error.message : "Unknown");
    return new Response(
      JSON.stringify({ ok: false, reason: "An error occurred" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

async function uploadAndCache(
  supabase: any,
  voucherId: string,
  merchant: string,
  merchantKey: string,
  userId: string,
  domain: string,
  arrayBuffer: ArrayBuffer,
  contentType: string,
  source: string
) {
  // Always save as PNG for consistency
  const filePath = `${voucherId}.png`;

  const { error: uploadError } = await supabase.storage
    .from("logos")
    .upload(filePath, arrayBuffer, {
      contentType: "image/png",
      upsert: true,
    });

  if (uploadError) {
    console.error("Upload error:", uploadError.message);
    throw uploadError;
  }

  // Update cache with storage path
  await supabase
    .from("merchant_logo_cache")
    .upsert({
      merchant_key: merchantKey,
      domain,
      logo_path: filePath,
      logo_source: source,
      updated_at: new Date().toISOString(),
    });

  // Update voucher with storage path (not signed URL)
  await supabase
    .from("vouchers")
    .update({
      merchant_domain: domain,
      merchant_logo_path: filePath,
      logo_source: source,
      logo_cache_updated_at: new Date().toISOString(),
    })
    .eq("voucher_id", voucherId);

  // Create signed URL for response
  const { data: signedUrlData } = await supabase.storage
    .from("logos")
    .createSignedUrl(filePath, 3600);

  return new Response(
    JSON.stringify({ ok: true, logoUrl: signedUrlData?.signedUrl || filePath, source }),
    { headers: { ...corsHeaders, "Content-Type": "application/json" } }
  );
}

async function generateAILogo(
  supabase: any,
  voucherId: string,
  merchant: string,
  merchantKey: string,
  userId: string,
  openaiKey?: string
) {
  const firstLetter = merchant.charAt(0).toUpperCase();
  
  if (!openaiKey) {
    console.log("No OpenAI key, returning fallback");
    return new Response(
      JSON.stringify({ ok: false, reason: "No AI key configured" }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  try {
    const response = await fetch("https://api.openai.com/v1/images/generations", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${openaiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-image-1",
        prompt: `Create a modern, flat circular app icon with the letter '${firstLetter}' centered, soft blue gradient background. No brand wordmarks or trademark shapes. Simple and clean design.`,
        n: 1,
        size: "1024x1024",
        quality: "medium",
        output_format: "png",
      }),
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.statusText}`);
    }

    const data = await response.json();
    const imageData = data.data?.[0];
    
    if (!imageData?.b64_json) {
      throw new Error("No image data returned from OpenAI");
    }

    // Convert base64 to ArrayBuffer
    const base64Data = imageData.b64_json;
    const binaryString = atob(base64Data);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }

    return await uploadAndCache(
      supabase,
      voucherId,
      merchant,
      merchantKey,
      userId,
      "generated",
      bytes.buffer,
      "image/png",
      "generated"
    );
  } catch (error) {
    console.error("AI logo error:", error instanceof Error ? error.message : "Unknown");
    return new Response(
      JSON.stringify({ ok: false, reason: "Logo generation failed" }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
}

function inferDomains(merchant: string): string[] {
  const normalized = merchant.toLowerCase().replace(/[^a-z0-9\s]/g, "").trim();
  const words = normalized.split(/\s+/);
  const lastWord = words[words.length - 1];
  const firstWord = words[0];
  
  const candidates = new Set<string>();
  
  // Full name
  const fullName = words.join("");
  REGIONAL_TLDS.forEach(tld => candidates.add(`${fullName}${tld}`));
  
  // Last word
  if (words.length > 1) {
    REGIONAL_TLDS.forEach(tld => candidates.add(`${lastWord}${tld}`));
  }
  
  // First word
  if (words.length > 1) {
    REGIONAL_TLDS.forEach(tld => candidates.add(`${firstWord}${tld}`));
  }
  
  return Array.from(candidates);
}