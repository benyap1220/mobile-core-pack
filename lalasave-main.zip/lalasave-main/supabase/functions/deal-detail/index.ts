import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    const url = new URL(req.url);
    const dealId = url.searchParams.get('deal_id');

    if (!dealId) {
      return new Response(
        JSON.stringify({ error: 'Missing deal_id parameter' }),
        { status: 400, headers: { ...corsHeaders, 'content-type': 'application/json' } }
      );
    }

    // Fetch deal
    const { data: deal, error: dealError } = await supabase
      .from('deals_feed')
      .select('*')
      .eq('id', dealId)
      .single();

    if (dealError || !deal) {
      return new Response(
        JSON.stringify({ error: 'Deal not found' }),
        { status: 404, headers: { ...corsHeaders, 'content-type': 'application/json' } }
      );
    }

    // Fetch promo if exists
    let promo = null;
    if (deal.promo_id) {
      const { data } = await supabase
        .from('ia_promos')
        .select('*')
        .eq('id', deal.promo_id)
        .single();
      promo = data;
    }

    // Fetch advertiser for logo
    const { data: advertiser } = await supabase
      .from('ia_advertisers')
      .select('logo_url, name')
      .eq('offer_id', deal.offer_id)
      .single();

    // Fetch border if exists
    let border = null;
    if (deal.primary_coupon_id) {
      const { data } = await supabase
        .from('border_styles')
        .select('*')
        .eq('target', 'deals')
        .not('approved_by', 'is', null)
        .limit(1)
        .single();
      border = data;
    }

    const enrichedDeal = {
      id: deal.id,
      offer_id: deal.offer_id,
      deeplink_id: deal.deeplink_id,
      deeplink_type: deal.deeplink_type || 'standard',
      
      // Promo-first data
      title: promo?.title || deal.title,
      summary: promo?.summary || deal.subtitle,
      code: promo?.code || null,
      tags: promo?.tags || deal.tags || [],
      image_url: promo?.image_url || deal.image_url,
      note: promo?.note || null,
      
      // Metadata
      expires_at: promo?.ends_at || deal.expires_at,
      platform: advertiser?.name || deal.platform,
      platform_logo: advertiser?.logo_url || null,
      country: deal.country,
      source: deal.source,
      has_coupon: deal.has_coupon,
      
      // Border
      border: border ? {
        id: border.id,
        svg_path: border.svg_path,
        layout_mode: border.layout_mode,
        safe_area: border.safe_area,
        frame_meta: border.frame_meta,
        view_box: border.view_box,
        image_path: border.image_path,
      } : null,
    };

    return new Response(
      JSON.stringify(enrichedDeal),
      { headers: { ...corsHeaders, 'content-type': 'application/json' } }
    );
  } catch (error) {
    console.error('deal-detail error:', error);
    return new Response(
      JSON.stringify({ error: String(error), hint: 'Unexpected server error' }),
      { status: 500, headers: { ...corsHeaders, 'content-type': 'application/json' } }
    );
  }
});
