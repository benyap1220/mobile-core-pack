import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { brandSlug, sourceUrl } = await req.json();
    
    if (!brandSlug) {
      return json({ error: "missing brandSlug" }, 400);
    }

    // Fetch the logo from source
    const logoUrl = sourceUrl || `https://cdn.jsdelivr.net/npm/simple-icons@latest/icons/${brandSlug}.svg`;
    
    console.log(`[upload-curated-logo] Fetching ${brandSlug} from ${logoUrl}`);
    
    const response = await fetch(logoUrl);
    if (!response.ok) {
      throw new Error(`Failed to fetch logo: ${response.status}`);
    }

    const contentType = response.headers.get("content-type") || "";
    const isSvg = contentType.includes("svg") || contentType.includes("xml") || logoUrl.endsWith('.svg');
    const extension = isSvg ? "svg" : "png";
    
    const logoBytes = new Uint8Array(await response.arrayBuffer());
    
    console.log(`[upload-curated-logo] Downloaded ${logoBytes.byteLength} bytes`);

    // Upload to curated folder
    const storagePath = `_curated/${brandSlug}.${extension}`;
    
    await supabase.storage
      .from("brand-logos")
      .upload(storagePath, logoBytes, {
        contentType: isSvg ? "image/svg+xml" : "image/png",
        upsert: true,
        cacheControl: "public, max-age=604800, stale-while-revalidate=86400",
      });

    // Get public URL
    const { data: pub } = supabase.storage
      .from("brand-logos")
      .getPublicUrl(storagePath);

    // Upsert into overrides table
    await supabase.from("brand_logo_overrides").upsert({
      brand_slug: brandSlug,
      storage_path: storagePath,
      source: sourceUrl ? 'custom' : 'simple-icons',
      updated_at: new Date().toISOString(),
    });

    // Delete any existing cache for this brand to force refresh
    await supabase
      .from("merchant_logo_cache")
      .delete()
      .eq("merchant_slug", brandSlug);

    console.log(`[upload-curated-logo] Uploaded curated logo to ${storagePath}`);

    return json({ 
      publicUrl: pub.publicUrl, 
      storagePath,
      source: sourceUrl ? 'custom' : 'simple-icons'
    });
  } catch (e) {
    console.error("[upload-curated-logo]", e);
    return json({ 
      error: String(e), 
      publicUrl: null 
    }, 500);
  }
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      ...corsHeaders,
      "content-type": "application/json",
    },
  });
}
