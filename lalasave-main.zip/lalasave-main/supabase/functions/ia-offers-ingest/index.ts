import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// ============ URL Validator (inlined) ============

function getRelaxFlags() {
  return {
    viewport: Deno.env.get('IA_RELAX_VIEWPORT_CHECK') === 'true',
    region: Deno.env.get('IA_RELAX_REGION_CHECK') === 'true',
    deeplink: Deno.env.get('IA_RELAX_DEEPLINK_CHECK') === 'true',
    allowEmptyPromo: Deno.env.get('IA_ALLOW_EMPTY_PROMO') === 'true',
  };
}

interface ValidationResult {
  ok: boolean;
  reason?: string;
  mobileOk?: boolean;
  regionOk?: boolean;
  deeplinkType?: 'deeplink' | 'shoplink';
  metaOk?: boolean;
  responseTime?: number;
}

interface SelectionReason {
  kind: string;
  checks: {
    reachable: boolean;
    mobile: boolean;
    region: boolean;
    deeplinkable: boolean;
  };
  boosts: {
    platform: number;
    cps: number;
    meta: number;
  };
  penalties: {
    viewport: number;
    slow: number;
    region: number;
  };
  score: number;
}

// MY domain allowlist per platform
const MY_DOMAINS: Record<string, string[]> = {
  'lazada': ['lazada.com.my'],
  'shopee': ['shopee.com.my'],
  'grab': ['grab.com'],
  'foodpanda': ['foodpanda.my'],
  'temu': ['temu.com'],
  'amazon': ['amazon.com', 'amazon.sg'],
  'taobao': ['taobao.com', 'world.taobao.com'],
  'zalora': ['zalora.com.my'],
  'sephora': ['sephora.my'],
  'adidas': ['adidas.com.my'],
  'nike': ['nike.com'],
};

function isBlockedUrl(url: string): boolean {
  const patterns = [
    /\/cart\b/i,
    /\/checkout\b/i,
    /\/login\b/i,
    /\/privacy\b/i,
    /\/terms\b/i,
    /\/help\b/i,
    /mailto:/i,
    /tel:/i,
  ];
  return patterns.some(pattern => pattern.test(url));
}

function hostMatchesCountry(url: string, country: string, platformName: string): boolean {
  if (country !== 'MY') return true;
  
  try {
    const hostname = new URL(url).hostname.toLowerCase();
    const platformKey = Object.keys(MY_DOMAINS).find(k => 
      platformName.toLowerCase().includes(k)
    );
    
    if (!platformKey) return true;
    
    const allowedDomains = MY_DOMAINS[platformKey];
    return allowedDomains.some(domain => hostname.includes(domain));
  } catch {
    return false;
  }
}

function hasViewportMeta(html: string): boolean {
  return /<meta\s+name=["']viewport["'][^>]*>/i.test(html);
}

function hasOGMeta(html: string): boolean {
  const hasImage = /<meta\s+property=["']og:image["'][^>]*>/i.test(html);
  const hasTitle = /<meta\s+property=["']og:title["'][^>]*>/i.test(html);
  return hasImage && hasTitle;
}

function hasDealCues(text: string): boolean {
  return /sale|voucher|promo|discount|flash|deal|offer/i.test(text);
}

async function validateUrl(
  url: string, 
  country: string, 
  platformName: string
): Promise<ValidationResult> {
  const relaxFlags = getRelaxFlags();
  
  if (isBlockedUrl(url)) {
    return { ok: false, reason: 'blocked' };
  }

  const startTime = Date.now();
  let html = '';
  let reachable = false;
  
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 2000);
    
    const response = await fetch(url, {
      method: 'GET',
      signal: controller.signal,
      headers: {
        'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15',
      },
    });
    
    clearTimeout(timeoutId);
    
    if (response.ok) {
      reachable = true;
      const contentType = response.headers.get('content-type') || '';
      if (contentType.includes('text/html')) {
        html = await response.text();
      }
    }
  } catch (error) {
    console.log(`URL validation failed for ${url}:`, error);
    return { ok: false, reason: 'unreachable' };
  }

  const responseTime = Date.now() - startTime;
  
  if (!reachable) {
    return { ok: false, reason: 'unreachable' };
  }

  const mobileOk = html ? hasViewportMeta(html) : true;
  const regionOk = hostMatchesCountry(url, country, platformName);
  const metaOk = html ? hasOGMeta(html) : false;

  const effectiveMobileOk = relaxFlags.viewport || mobileOk;
  const effectiveRegionOk = relaxFlags.region || regionOk;

  return {
    ok: true,
    mobileOk: effectiveMobileOk,
    regionOk: effectiveRegionOk,
    metaOk,
    responseTime,
    deeplinkType: 'deeplink',
  };
}

function calculateScore(
  kind: string,
  validation: ValidationResult,
  platformPriority: number,
  isCPS: boolean,
  titleText: string
): { score: number; reason: SelectionReason } {
  const baseScores: Record<string, number> = {
    'promo': 0.55,
    'product': 0.50,
    'category': 0.40,
    'home': 0.30,
  };
  
  let score = baseScores[kind] || 0.20;
  
  const boosts = {
    platform: 0,
    cps: 0,
    meta: 0,
  };
  
  const penalties = {
    viewport: 0,
    slow: 0,
    region: 0,
  };
  
  if (platformPriority > 0) {
    boosts.platform = 0.10;
    score += 0.10;
  }
  
  if (isCPS) {
    boosts.cps = 0.05;
    score += 0.05;
  }
  
  if (validation.metaOk) {
    boosts.meta = 0.05;
    score += 0.05;
  }
  
  if (hasDealCues(titleText)) {
    boosts.meta += 0.05;
    score += 0.05;
  }
  
  if (validation.mobileOk === false) {
    penalties.viewport = -0.10;
    score -= 0.10;
  }
  
  if (validation.responseTime && validation.responseTime > 2000) {
    penalties.slow = -0.10;
    score -= 0.10;
  }
  
  if (validation.regionOk === false) {
    penalties.region = -0.15;
    score -= 0.15;
  }
  
  score = Math.max(0, Math.min(1, score));
  
  return {
    score,
    reason: {
      kind,
      checks: {
        reachable: true,
        mobile: validation.mobileOk !== false,
        region: validation.regionOk !== false,
        deeplinkable: true,
      },
      boosts,
      penalties,
      score,
    },
  };
}

function sanitizeUrl(url: string): string {
  try {
    const parsed = new URL(url);
    const keepParams = ['spm', 'scm', 'from', 'gad'];
    const newParams = new URLSearchParams();
    
    for (const [key, value] of parsed.searchParams) {
      if (keepParams.some(k => key.toLowerCase().startsWith(k))) {
        newParams.set(key, value);
      }
    }
    
    parsed.search = newParams.toString();
    return parsed.toString();
  } catch {
    return url;
  }
}

// ============ End URL Validator ============

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface IAOffer {
  offer_id: number;
  merchant_id?: number;
  offer_name?: string;
  description?: string;
  tracking_type?: string;
  offer_country?: string;
  logo?: string;
  directory_page?: string;
  tracking_link?: string;
  application_status?: string;
  offer_status?: string;
  status?: string;
  categories?: string;
}

// Priority platforms (used for scoring, not hard filtering)
const PRIORITY_PLATFORMS = [
  'Lazada', 'Shopee', 'Grab', 'Foodpanda', 'Temu', 'Amazon', 'Taobao',
  'Zalora', 'Watsons', 'Guardian', 'Sephora', 'ASOS', 'Nike',
  'Adidas', 'Uniqlo', 'H&M', 'Zara', 'Booking.com', 'Agoda',
  'Klook', 'Traveloka', 'AirAsia', 'McDonald', 'KFC', 'Pizza Hut'
];

// Promo keywords for scraping
const PROMO_KEYWORDS = ['promo', 'voucher', 'coupon', 'deal', 'discount', 'flash', 'sale', 'offers', 'campaign'];

// Platform priority boost calculation (0 or 1, null-safe)
function getPlatformPriority(name?: string): number {
  if (!name) return 0;
  const isPriority = PRIORITY_PLATFORMS.some(p => 
    name.toLowerCase().includes(p.toLowerCase())
  );
  return isPriority ? 1 : 0;
}

function parseCountries(countryStr?: string): string[] {
  if (!countryStr) return ['MY'];
  if (countryStr.toLowerCase().includes('malaysia')) return ['MY'];
  return ['MY'];
}

function parseCategories(catStr?: string): string[] {
  if (!catStr) return [];
  return catStr.split(/[|,]/).map(c => c.trim()).filter(Boolean);
}

function buildCommissionJson(offer: IAOffer): any {
  return { type: offer.tracking_type || 'CPS' };
}

// URL patterns to block
const BLOCK_PATTERNS = [
  /\/cart\b/i,
  /\/checkout\b/i,
  /\/login\b/i,
  /\/privacy\b/i,
  /\/terms\b/i,
  /\/help\b/i,
  /mailto:/i,
  /tel:/i,
];

// Promo URL path patterns to try
const PROMO_URL_PATTERNS = [
  '/promotions', '/promo', '/vouchers', '/deals', '/campaign', 
  '/offers', '/sale', '/discount', '/flash-sale', '/special-offers'
];

// Helper to get boolean ENV vars
function getBoolEnv(key: string, defaultValue: boolean): boolean {
  const val = Deno.env.get(key);
  if (!val) return defaultValue;
  return val.toLowerCase() === 'true' || val === '1';
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const iaApiKey = Deno.env.get('IA_API_KEY')!;
    const iaApiSecret = Deno.env.get('IA_API_SECRET')!;

    const supabase = createClient(supabaseUrl, supabaseKey);

    // ENV toggles
    const COUNTRY = Deno.env.get('IA_COUNTRY') || 'MY';
    const USE_APPROVED_ONLY = getBoolEnv('IA_USE_APPROVED_ONLY', true);
    const INCLUDE_PENDING = getBoolEnv('IA_INCLUDE_PENDING', true);
    const RELAX_COUNTRY_IF_EMPTY = getBoolEnv('IA_RELAX_COUNTRY_IF_EMPTY', true);
    const ALLOWLIST_PLATFORMS = Deno.env.get('IA_ALLOWLIST_PLATFORMS') || '';
    const MIN_SCORE = parseFloat(Deno.env.get('IA_MIN_SCORE') || '0.15');
    const PROMO_SCRAPER_ENABLED = getBoolEnv('IA_PROMO_SCRAPER_ENABLED', true);
    const PROMO_TIMEOUT_MS = parseInt(Deno.env.get('IA_PROMO_SCRAPER_TIMEOUT_MS') || '2500');
    const PROMO_KEYWORDS_ENV = Deno.env.get('IA_PROMO_KEYWORDS') || PROMO_KEYWORDS.join(',');

    console.log('Starting IA offers ingestion from approved advertisers...');
    console.log('ENV config:', {
      country: COUNTRY,
      useApprovedOnly: USE_APPROVED_ONLY,
      includePending: INCLUDE_PENDING,
      relaxCountryIfEmpty: RELAX_COUNTRY_IF_EMPTY,
      allowlistPlatforms: ALLOWLIST_PLATFORMS || '(none - using priority scoring)',
      minScore: MIN_SCORE,
      promoScraperEnabled: PROMO_SCRAPER_ENABLED,
    });

    // Step 1: Authenticate to get bearer token
    console.log('Step 1: Authenticating with IA API...');
    const authResponse = await fetch('https://api.involve.asia/api/authenticate', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        key: iaApiKey,
        secret: iaApiSecret,
      }).toString(),
    });

    const authData = await authResponse.json();
    if (!authResponse.ok || authData.status !== 'success') {
      const authText = JSON.stringify(authData);
      console.error('IA Authentication failed:', authResponse.status, authText);
      throw new Error(`IA Authentication failed: ${authResponse.status} - ${authText}`);
    }

    const token = authData.data?.token;
    if (!token) {
      throw new Error('No token received from IA API');
    }

    console.log('Step 2: Fetching offers with token...');

    // Stage counters + structured logs
    const stats = {
      raw: 0,
      afterStatus: 0,
      afterCountry: 0,
      afterAllowlist: 0,
      upsertedAdvertisers: 0,
      seededLandings: 0,
      skipped: 0,
      pages: 0,
    };

    const rejectionReasons: Record<string, number> = {
      blocked: 0,
      unreachable: 0,
      region: 0,
      not_deeplinkable: 0,
      duplicate: 0,
    };
    
    let page = 1;
    const perPage = 100;
    let hasMore = true;
    const allRawOffers: IAOffer[] = [];
    const droppedExamples: Array<{stage: string; offer: any}> = [];

    while (hasMore) {
      console.log(`Fetching page ${page}...`);
      stats.pages++;

      // Build filters for server-side filtering (removed for now - accept all)
      const filters: any = {
        page: page.toString(),
        limit: perPage.toString(),
      };

      const iaResponse = await fetch('https://api.involve.asia/api/offers/all', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams(filters).toString(),
      });

      if (!iaResponse.ok) {
        const errorText = await iaResponse.text();
        console.error('IA API Error:', iaResponse.status, errorText);
        return new Response(
          JSON.stringify({ 
            ok: false,
            where: 'ia-offers-ingest.fetchOffers',
            error: `IA API returned ${iaResponse.status}`,
            status: iaResponse.status,
            url: 'https://api.involve.asia/api/offers/all',
            authSchemeUsed: 'bearer',
            body: errorText.substring(0, 300),
            hint: 'Check IA_API_SECRET / auth scheme / rate limit',
          }),
          { status: iaResponse.status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const iaData = await iaResponse.json();
      
      // IA API returns nested structure: { data: { data: [...offers] } }
      let offers: IAOffer[] = [];
      
      if (iaData.data && Array.isArray(iaData.data.data)) {
        offers = iaData.data.data;
      } else if (Array.isArray(iaData.data)) {
        offers = iaData.data;
      } else if (Array.isArray(iaData.offers)) {
        offers = iaData.offers;
      }

      console.log(`Fetched ${offers.length} offers from page ${page}`);
      allRawOffers.push(...offers);

      if (offers.length < perPage) {
        hasMore = false;
      } else {
        await new Promise(resolve => setTimeout(resolve, 3000));
        page++;
      }
    }

    stats.raw = allRawOffers.length;
    console.log(`Total raw offers: ${stats.raw}`);
    
    // Log first offer to see structure
    if (allRawOffers.length > 0) {
      console.log('Sample offer structure:', JSON.stringify(allRawOffers[0], null, 2));
    }

    // Stage 1: Status validation - VERY LENIENT (accept almost everything)
    const statusFiltered = allRawOffers.filter(o => {
      // Accept offer if it has ANY of these fields with ANY value (not explicitly rejected)
      const appStatus = (o.application_status || '')?.toLowerCase();
      const offerStatus = (o.offer_status || '')?.toLowerCase();
      const status = (o.status || '')?.toLowerCase();
      
      // Reject only if explicitly 'rejected', 'disabled', 'deleted', 'expired'
      const rejectedStatuses = ['rejected', 'disabled', 'deleted', 'expired', 'declined', 'suspended'];
      const isRejected = rejectedStatuses.some(r => 
        appStatus.includes(r) || offerStatus.includes(r) || status.includes(r)
      );
      
      const valid = !isRejected;
      
      if (!valid && droppedExamples.length < 3) {
        droppedExamples.push({
          stage: 'status',
          offer: {
            offer_id: o.offer_id,
            offer_name: o.offer_name,
            application_status: o.application_status,
            offer_status: o.offer_status,
            status: o.status,
            offer_country: o.offer_country,
          }
        });
      }
      return valid;
    });
    
    stats.afterStatus = statusFiltered.length;
    console.log(`After status filter: ${stats.afterStatus} (dropped ${stats.raw - stats.afterStatus})`);

    // Stage 2: Country validation (with relaxation fallback)
    let countryFiltered = statusFiltered.filter(o => {
      const country = (o.offer_country || '')?.toLowerCase();
      const targetCountry = COUNTRY.toLowerCase();
      const isTargetCountry = country.includes(targetCountry);
      const isIntl = country.includes('international') || country === '' || !country;
      const valid = isTargetCountry || (RELAX_COUNTRY_IF_EMPTY && isIntl);
      if (!valid && droppedExamples.length < 6) {
        droppedExamples.push({
          stage: 'country',
          offer: {
            offer_id: o.offer_id,
            offer_name: o.offer_name,
            application_status: o.application_status,
            offer_country: o.offer_country,
          }
        });
      }
      return valid;
    });
    
    stats.afterCountry = countryFiltered.length;
    console.log(`After country filter: ${stats.afterCountry} (dropped ${stats.afterStatus - stats.afterCountry})`);

    // Fallback if country filtering dropped everything
    if (stats.afterCountry === 0 && RELAX_COUNTRY_IF_EMPTY && statusFiltered.length > 0) {
      console.log('[FALLBACK_COUNTRY] Country filter dropped all offers. Relaxing to include all.');
      countryFiltered = statusFiltered;
      stats.afterCountry = countryFiltered.length;
    }

    // Stage 3: Allowlist filter (optional - only if ALLOWLIST_PLATFORMS is set)
    let finalOffers = countryFiltered;
    
    if (ALLOWLIST_PLATFORMS) {
      const allowlistArray = ALLOWLIST_PLATFORMS.split(',').map(p => p.trim()).filter(Boolean);
      finalOffers = countryFiltered.filter(o => {
        const offerName = (o.offer_name || '').toLowerCase();
        const matchesAllowlist = allowlistArray.some(p => offerName.includes(p.toLowerCase()));
        
        if (!matchesAllowlist) {
          stats.skipped++;
          if (droppedExamples.length < 9) {
            droppedExamples.push({
              stage: 'allowlist',
              offer: {
                offer_id: o.offer_id,
                offer_name: o.offer_name,
                application_status: o.application_status,
                offer_country: o.offer_country,
              }
            });
          }
        }
        return matchesAllowlist;
      });
      
      stats.afterAllowlist = finalOffers.length;
      console.log(`After allowlist filter: ${stats.afterAllowlist} (skipped ${stats.skipped})`);
    } else {
      stats.afterAllowlist = finalOffers.length;
      console.log(`No allowlist applied. Using all ${stats.afterAllowlist} offers.`);
    }

    if (stats.afterAllowlist === 0) {
      console.log('No offers survived filters.');
      console.log('Dropped examples:', JSON.stringify(droppedExamples, null, 2));
      return new Response(
        JSON.stringify({
          ok: false,
          where: 'ia-offers-ingest',
          reason: 'No offers survived filters',
          stats,
          droppedExamples,
          hint: 'Likely no Approved/Pending offers for MY or allowlist too strict. Toggle IA_INGEST_INCLUDE_PENDING / IA_INGEST_RELAX_COUNTRY / IA_INGEST_FALLBACK_IF_EMPTY.',
        }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Upsert advertisers and discover landings
    for (const offer of finalOffers) {
      const platformPriority = getPlatformPriority(offer.offer_name);

      const commissionJson = buildCommissionJson(offer);

      const { error: advError } = await supabase
        .from('ia_advertisers')
        .upsert({
          offer_id: offer.offer_id,
          name: offer.offer_name ?? 'Unknown',
          logo_url: offer.logo ?? null,
          countries: parseCountries(offer.offer_country),
          categories: parseCategories(offer.categories),
          tracking_type: (offer.tracking_type || '')?.toUpperCase() || 'CPS',
          tracking_link: offer.tracking_link || null,
          commission_json: commissionJson,
          approved: true,
          platform_priority: platformPriority,
          last_seen: new Date().toISOString(),
        }, { onConflict: 'offer_id' });

      if (advError) {
        console.error(`Error upserting advertiser ${offer.offer_id}:`, advError);
        continue;
      }

      stats.upsertedAdvertisers++;

      // Landing discovery with promo scraping
      const candidates: Array<{url: string; kind: string; title: string}> = [];
      const merchantName = offer.offer_name ?? 'Unknown';
      
      // 1. Home landing
      let homeLanding = offer.directory_page;
      if (!homeLanding && offer.tracking_link) {
        try {
          const trackingUrl = new URL(offer.tracking_link);
          homeLanding = `https://${trackingUrl.hostname}/`;
        } catch {
          // ignore
        }
      }
      
      if (homeLanding) {
        candidates.push({
          url: sanitizeUrl(homeLanding),
          kind: 'home',
          title: `${merchantName} Official Store`,
        });
      }

      // 2. Promo pages (probe common patterns)
      if (homeLanding && PROMO_SCRAPER_ENABLED) {
        const promoKeywords = PROMO_KEYWORDS_ENV.split(',').map(k => k.trim());
        const promoPatterns = promoKeywords.map(k => `/${k}`);
        
        for (const pattern of promoPatterns.slice(0, 3)) {
          try {
            const testUrl = new URL(homeLanding);
            testUrl.pathname = pattern;
            const urlStr = testUrl.toString();
            
            if (isBlockedUrl(urlStr)) continue;
            
            const headRes = await fetch(urlStr, {
              method: 'HEAD',
              signal: AbortSignal.timeout(PROMO_TIMEOUT_MS),
            });
            
            if (headRes.ok) {
              candidates.push({
                url: sanitizeUrl(urlStr),
                kind: 'promo',
                title: `${merchantName} - Promotions`,
              });
              
              // Try to scrape promo data (lightweight - just basic HTML parsing)
              if (PROMO_SCRAPER_ENABLED) {
                try {
                  const htmlRes = await fetch(urlStr, {
                    signal: AbortSignal.timeout(PROMO_TIMEOUT_MS),
                  });
                  const html = await htmlRes.text();
                  
                  // Extract coupon codes (simple regex)
                  const codeMatches = html.match(/\b[A-Z0-9]{4,12}\b/g) || [];
                  const validCodes = codeMatches.filter(c => 
                    !['FREE', 'SALE', 'OFF', 'SHOP', 'SAVE'].includes(c) &&
                    c.match(/[A-Z]/) && c.match(/[0-9]/)
                  );
                  
                  // Extract dates
                  const dateMatch = html.match(/\b(\d{1,2})\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\b/i);
                  
                  // Extract first OG image
                  const ogImageMatch = html.match(/<meta[^>]*property="og:image"[^>]*content="([^"]+)"/i);
                  
                  // Save promo data with more fields
                  if (validCodes.length > 0 || ogImageMatch) {
                    const promoCode = validCodes[0] || null;
                    const promoTitle = promoCode 
                      ? `${promoCode} - ${merchantName} Promo` 
                      : `${merchantName} Promotion`;
                    
                    await supabase.from('ia_promos').upsert({
                      offer_id: offer.offer_id,
                      landing_url: urlStr,
                      code: promoCode,
                      title: promoTitle,
                      summary: `Promotional offer at ${merchantName}`,
                      image_url: ogImageMatch?.[1] || null,
                      source: 'MERCHANT_SCRAPE',
                      discovered_at: new Date().toISOString(),
                      score: validCodes.length > 0 ? 0.8 : 0.5,
                      tags: ['promo', 'limited-time'],
                    }, { onConflict: 'offer_id,landing_url', ignoreDuplicates: false });
                    
                    console.log(`Saved promo for ${merchantName}: ${promoCode || 'no code'}`);
                  }
                } catch (err) {
                  console.log(`Promo scrape failed for ${urlStr}:`, err instanceof Error ? err.message : err);
                }
              }
              
              break; // Only keep first promo page found
            }
          } catch {
            // Ignore timeout/errors
          }
        }
      }

      // 3. Category pages
      const cats = parseCategories(offer.categories);
      if (cats.length > 0 && homeLanding) {
        try {
          const catUrl = new URL(homeLanding);
          catUrl.pathname = `/category/${cats[0]?.toLowerCase().replace(/\s+/g, '-')}`;
          const urlStr = catUrl.toString();
          
          if (!isBlockedUrl(urlStr)) {
            candidates.push({
              url: sanitizeUrl(urlStr),
              kind: 'category',
              title: `${merchantName} - ${cats[0]}`,
            });
          }
        } catch {
          // Invalid URL
        }
      }

      // Deduplicate and validate
      const uniqueCandidates = Array.from(
        new Map(candidates.map(c => [c.url, c])).values()
      );

      const validatedLandings: Array<any> = [];
      
      for (const candidate of uniqueCandidates.slice(0, 5)) {
        const validation = await validateUrl(
          candidate.url,
          COUNTRY,
          merchantName
        );

        if (!validation.ok) {
          console.log(`Rejected ${candidate.url}: ${validation.reason}`);
          rejectionReasons[validation.reason || 'unknown'] = (rejectionReasons[validation.reason || 'unknown'] || 0) + 1;
          continue;
        }

        const { score, reason } = calculateScore(
          candidate.kind,
          validation,
          platformPriority,
          (offer.tracking_type || '')?.toUpperCase() === 'CPS',
          candidate.title
        );
        
        // Filter by MIN_SCORE
        if (score < MIN_SCORE) {
          console.log(`Dropped ${candidate.url}: score ${score.toFixed(2)} < ${MIN_SCORE}`);
          continue;
        }

        validatedLandings.push({
          offer_id: offer.offer_id,
          url: candidate.url,
          kind: candidate.kind,
          title: candidate.title,
          score,
          selection_reason: reason,
          last_checked_at: new Date().toISOString(),
          deeplinkable: true,
        });
      }

      // Sort by score, prefer diversity (1 promo + 1 category + 1 home)
      validatedLandings.sort((a, b) => b.score - a.score);
      
      const finalLandings: Array<any> = [];
      const seenKinds = new Set<string>();
      
      for (const landing of validatedLandings) {
        if (finalLandings.length >= 3) break;
        
        if (!seenKinds.has(landing.kind) || finalLandings.length < 2) {
          finalLandings.push(landing);
          seenKinds.add(landing.kind);
        }
      }

      if (finalLandings.length > 0) {
        const { error: landError } = await supabase
          .from('ia_landings')
          .upsert(finalLandings, { 
            onConflict: 'offer_id,url', 
            ignoreDuplicates: false 
          });

        if (!landError) {
          stats.seededLandings += finalLandings.length;
          console.log(`Seeded ${finalLandings.length} landings for ${merchantName} (scores: ${finalLandings.map(l => l.score.toFixed(2)).join(', ')})`);
        }
      }
    }

    console.log('=== Ingestion Summary ===');
    console.log('[INGEST]', JSON.stringify(stats));
    console.log('Rejection reasons:', JSON.stringify(rejectionReasons, null, 2));
    if (droppedExamples.length > 0) {
      console.log('Dropped examples:', JSON.stringify(droppedExamples, null, 2));
    }

    return new Response(
      JSON.stringify({
        ok: true,
        stats,
        rejectionReasons,
        droppedExamples: droppedExamples.slice(0, 3),
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in IA offers ingestion:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    
    return new Response(
      JSON.stringify({ 
        ok: false,
        where: 'ia-offers-ingest.main',
        error: errorMessage,
        details: error instanceof Error ? error.stack : String(error),
        hint: 'Check logs for full error trace',
      }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
