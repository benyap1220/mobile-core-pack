import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

const TTL_DAYS = Number(Deno.env.get("LOGO_CACHE_TTL_DAYS") ?? 7);
const MIN_IMAGE_SIZE = 20480; // 20KB minimum to reject tiny favicons and sub-brand marks
const TARGET_SIZE = 512; // Target 512x512 for high quality

// Hard-coded overrides (matches client-side lib/brandOverrides.ts)
const BRAND_OVERRIDES: Record<string, { url: string; mime?: string }> = {
  lazada: { url: '/brand-logos/lazada-official.png', mime: 'image/png' },
};

// Blocklist for sub-brands and non-brand URLs (case-insensitive)
const SUB_BRAND_BLOCKLIST = [
  'logistics', 'express', 'lazmall', 'rider', 'merchant', 'seller', 'sellercenter',
  'mall', 'partner', 'business', 'careers', 'press', 'blog', 'lex'
];

type Body = { slug: string; domain?: string; force?: boolean };

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { slug, domain, force }: Body = await req.json();
    
    if (!slug) {
      return json({ error: "missing slug" }, 400);
    }

    // PRIORITY 0: Hard-coded static overrides (absolute priority)
    if (BRAND_OVERRIDES[slug]) {
      console.log(`[resolve-logo] Using HARD OVERRIDE for ${slug}`);
      return json({
        brand_slug: slug,
        publicUrl: BRAND_OVERRIDES[slug].url,
        url: BRAND_OVERRIDES[slug].url,
        source: 'override-static',
        mime: BRAND_OVERRIDES[slug].mime
      });
    }

    // 1) Check database override
    const { data: override } = await supabase
      .from("brand_logo_overrides")
      .select("*")
      .eq("brand_slug", slug)
      .maybeSingle();

    if (override) {
      // Return curated logo immediately - NEVER skip this
      const { data: pub } = supabase.storage
        .from("brand-logos")
        .getPublicUrl(override.storage_path);
      
      console.log(`[resolve-logo] Using curated override for ${slug}${force ? ' (force ignored for curated)' : ''}`);
      
      // Also update cache for consistency
      await supabase.from("merchant_logo_cache").upsert({
        merchant_slug: slug,
        public_url: pub.publicUrl,
        source: 'override',
        updated_at: new Date().toISOString(),
      });
      
      return json({ 
        publicUrl: pub.publicUrl, 
        source: 'override',
        storagePath: override.storage_path,
        cache_written: true
      });
    }

    // 2) Cache check (unless force refresh)
    if (force) {
      // Force refresh: delete old cache and storage files (but NOT curated overrides)
      await supabase
        .from("merchant_logo_cache")
        .delete()
        .eq("merchant_slug", slug);
      
      // Delete old storage files (both SVG and PNG variants, excluding _curated)
      const pathsToDelete = [
        `${slug}.svg`,
        `${slug}.png`,
        `${slug}@2x.png`,
        `generated/${slug}.png`,
        `generated/${slug}.svg`
      ];
      
      for (const path of pathsToDelete) {
        await supabase.storage
          .from("brand-logos")
          .remove([path])
          .catch(() => {}); // Ignore errors if file doesn't exist
      }
    } else {
      const { data: cached } = await supabase
        .from("merchant_logo_cache")
        .select("*")
        .eq("merchant_slug", slug)
        .maybeSingle();

      const fresh = cached && cached.updated_at && 
        (Date.now() - Date.parse(cached.updated_at)) < TTL_DAYS * 86400_000;
      
      if (fresh && cached.public_url) {
        return json({ 
          publicUrl: cached.public_url, 
          source: cached.source 
        });
      }
    }

    // 3) Resolve domain
    let resolvedDomain = domain?.trim();
    if (!resolvedDomain) {
      const { data: map } = await supabase
        .from("merchant_domain_map")
        .select("domain")
        .eq("merchant_slug", slug)
        .maybeSingle();
      resolvedDomain = map?.domain || guessDomain(slug);
    }

    // Helper to check if URL/content contains blocklisted sub-brand terms
    function hasBlocklistedTerm(url: string): boolean {
      const urlLower = url.toLowerCase();
      const hasBad = SUB_BRAND_BLOCKLIST.some(term => urlLower.includes(term));
      if (hasBad) {
        console.log(`[resolve-logo] Rejected URL containing blocklisted term: ${url}`);
      }
      return hasBad;
    }

    // 4) Try external sources (prioritize high-res, filter sub-brands)
    const candidates = [
      { url: `https://logo.clearbit.com/${resolvedDomain}`, name: "clearbit", preferSvg: true },
      { url: `https://unavatar.io/${resolvedDomain}?size=${TARGET_SIZE}`, name: "unavatar", preferSvg: false },
      { url: `https://www.google.com/s2/favicons?domain=${resolvedDomain}&sz=${TARGET_SIZE}`, name: "google", preferSvg: false },
    ];

    let picked: { buf: Uint8Array; source: string; contentType: string; isSvg: boolean } | null = null;

    for (const candidate of candidates) {
      try {
        // Skip if URL contains blocklisted terms
        if (hasBlocklistedTerm(candidate.url)) {
          console.log(`[resolve-logo] Rejected ${candidate.name}: blocklisted term in URL`);
          continue;
        }

        const r = await fetch(candidate.url);
        if (!r.ok) continue;

        // Check if final URL (after redirects) contains blocklisted terms
        if (hasBlocklistedTerm(r.url)) {
          console.log(`[resolve-logo] Rejected ${candidate.name}: blocklisted term in final URL`);
          continue;
        }
        
        const contentType = r.headers.get("content-type") || "";
        const buf = new Uint8Array(await r.arrayBuffer());
        
        // Reject small images (likely low-res favicons)
        if (buf.byteLength < MIN_IMAGE_SIZE) {
          console.log(`[resolve-logo] Rejected ${candidate.name}: too small (${buf.byteLength} bytes)`);
          continue;
        }
        
        const isSvg = contentType.includes("svg") || contentType.includes("xml");
        
        picked = { 
          buf, 
          source: candidate.name,
          contentType,
          isSvg
        };
        
        // If we got an SVG from a preferred source, stop here
        if (isSvg && candidate.preferSvg) {
          console.log(`[resolve-logo] Found SVG from ${candidate.name}`);
          break;
        }
        
        // If we got a high-res PNG/WebP, use it
        if (buf.byteLength > MIN_IMAGE_SIZE * 4) {
          console.log(`[resolve-logo] Found high-res from ${candidate.name} (${buf.byteLength} bytes)`);
          break;
        }
      } catch (err) {
        console.error(`[resolve-logo] Error fetching from ${candidate.name}:`, err);
        continue;
      }
    }

    let publicUrl: string;
    let source: string;

    // 5) Upload or generate fallback
    if (picked) {
      const extension = picked.isSvg ? "svg" : "png";
      const path = `${slug}.${extension}`;
      const contentType = picked.isSvg ? "image/svg+xml" : "image/png";
      
      await supabase.storage
        .from("brand-logos")
        .upload(path, picked.buf, {
          contentType,
          upsert: true,
          cacheControl: "public, max-age=604800, stale-while-revalidate=86400",
        });

      const { data: pub } = supabase.storage
        .from("brand-logos")
        .getPublicUrl(path);
      
      publicUrl = pub.publicUrl;
      source = picked.source;
      
      console.log(`[resolve-logo] Uploaded ${extension.toUpperCase()} to ${path} (${picked.buf.byteLength} bytes)`);
    } else {
      // Generate high-quality PNG fallback (512x512)
      const initial = slug.charAt(0).toUpperCase() || "?";
      const svg = generateSVGLogo(initial);
      const path = `generated/${slug}.svg`;
      
      const encoder = new TextEncoder();
      const svgBytes = encoder.encode(svg);
      
      await supabase.storage
        .from("brand-logos")
        .upload(path, svgBytes, {
          contentType: "image/svg+xml",
          upsert: true,
          cacheControl: "public, max-age=604800, stale-while-revalidate=86400",
        });

      const { data: pub } = supabase.storage
        .from("brand-logos")
        .getPublicUrl(path);
      
      publicUrl = pub.publicUrl;
      source = "generated";
      
      console.log(`[resolve-logo] Generated SVG fallback to ${path}`);
    }

    // 6) Upsert cache
    await supabase.from("merchant_logo_cache").upsert({
      merchant_slug: slug,
      public_url: publicUrl,
      source,
      updated_at: new Date().toISOString(),
    });

    return json({ publicUrl, source });
  } catch (e) {
    console.error("[resolve-logo]", e);
    return json({ 
      error: String(e), 
      publicUrl: null, 
      source: "error" 
    }, 500);
  }
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      ...corsHeaders,
      "content-type": "application/json",
      "cache-control": "public, max-age=604800",
    },
  });
}

function guessDomain(slug: string) {
  return slug.replace(/-/g, "") + ".com";
}

// Generate a high-quality SVG logo with gradient and initial
function generateSVGLogo(initial: string): string {
  return `<svg width="512" height="512" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#5B8EFF"/>
      <stop offset="100%" stop-color="#09C6F9"/>
    </linearGradient>
  </defs>
  <rect width="512" height="512" rx="64" fill="url(#grad)"/>
  <text x="256" y="360" font-family="Arial,sans-serif" font-size="240" font-weight="bold" 
        fill="white" text-anchor="middle">${initial}</text>
</svg>`;
}
