import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface APIKeyStatus {
  name: string;
  exists: boolean;
  valid: boolean | null;
  error?: string;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const results: APIKeyStatus[] = [];

    // Check Clipdrop API Key
    const clipdropKey = Deno.env.get("CLIPDROP_API_KEY");
    if (clipdropKey) {
      try {
        const response = await fetch("https://clipdrop.co/api/v1/remove-background", {
          method: "POST",
          headers: {
            "x-api-key": clipdropKey,
          },
          body: new FormData(), // Empty form to test auth
        });
        
        // 400 means auth worked but request was bad (expected)
        // 401/403 means auth failed
        results.push({
          name: "CLIPDROP_API_KEY",
          exists: true,
          valid: response.status !== 401 && response.status !== 403,
          error: response.status === 401 || response.status === 403 ? "Authentication failed" : undefined,
        });
      } catch (error) {
        results.push({
          name: "CLIPDROP_API_KEY",
          exists: true,
          valid: false,
          error: error instanceof Error ? error.message : "Unknown error",
        });
      }
    } else {
      results.push({
        name: "CLIPDROP_API_KEY",
        exists: false,
        valid: null,
      });
    }

    // Check Vectorizer API
    const vectorizerId = Deno.env.get("VECTORIZER_API_ID");
    const vectorizerSecret = Deno.env.get("VECTORIZER_API_SECRET");
    if (vectorizerId && vectorizerSecret) {
      try {
        const response = await fetch("https://vectorizer.ai/api/v1/vectorize", {
          method: "POST",
          headers: {
            Authorization: `Basic ${btoa(`${vectorizerId}:${vectorizerSecret}`)}`,
          },
          body: new FormData(), // Empty form to test auth
        });
        
        results.push({
          name: "VECTORIZER_API",
          exists: true,
          valid: response.status !== 401 && response.status !== 403,
          error: response.status === 401 || response.status === 403 ? "Authentication failed" : undefined,
        });
      } catch (error) {
        results.push({
          name: "VECTORIZER_API",
          exists: true,
          valid: false,
          error: error instanceof Error ? error.message : "Unknown error",
        });
      }
    } else {
      results.push({
        name: "VECTORIZER_API",
        exists: vectorizerId || vectorizerSecret ? true : false,
        valid: null,
        error: !vectorizerId || !vectorizerSecret ? "Missing ID or Secret" : undefined,
      });
    }


    return new Response(
      JSON.stringify({ results }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("Error verifying API keys:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
