# Real-Deal (Coupons/Campaigns) → Deeplink → Card Implementation

## ✅ COMPLETED IMPLEMENTATION

### 1. Database Schema
- ✅ `ia_promos` table - stores real coupon/campaign data from IA API
- ✅ `ia_promo_deeplinks` table - caches deeplinks for promos
- ✅ Extended `deals_feed` with `promo_id` and `has_coupon` columns
- ✅ All tables have proper RLS policies (public read, service write)

### 2. Edge Functions

#### ia-promos-ingest (NEW)
- Fetches coupons from `/api/coupons/latest` (or ENV configured endpoint)
- Fetches campaigns from `/api/campaigns/latest` (or ENV configured endpoint)
- Filters to approved advertisers only
- Validates landing URLs (drops /cart, /checkout, /login, etc.)
- Drops expired promos (ends_at < now())
- Upserts into `ia_promos` with deduplication
- **Schedule:** Every 60 minutes (via pg_cron)

#### ia-deeplink-generate (UPDATED)
- Added `getOrCreatePromoDeeplink()` helper function
- Supports both promo and standard deeplink generation
- Caches in `ia_promo_deeplinks` table
- Fallback to shoplink if IA API fails
- Rate-limited (20 req/min)

#### deals-build-feed (REWRITTEN)
- Now reads from `ia_promos` instead of `ia_landings`
- Creates one deal per promo (not per advertiser)
- Generates deeplinks via `ia-deeplink-generate`
- Calculates score: 40% recency + 40% discount + 20% has_code
- Sets `has_coupon = true` when code exists
- Tags: min_spend, categories, "Auto-applies"
- **Schedule:** Every 2 hours (via pg_cron)

#### deals-list (UPDATED)
- **PUBLIC** - no auth required (uses SERVICE_ROLE_KEY)
- Joins `deals_feed` with `ia_promos` to return full promo data
- Default filter: `has_coupon = true` (only shows coupon deals)
- Add `?include_generic=1` to show campaign deals without codes
- Returns: title, code, min_spend, currency, ends_at, image_url, platform_logo
- Keyset pagination (24 items per page)

#### go-deeplink (UPDATED)
- **PUBLIC** - no 401 errors
- Checks `ia_promo_deeplinks` first, then `ia_deeplinks`
- Supports promo-based deals (uses promo_id to get landing_url)
- Fallback: generates new deeplink if missing
- Logs clicks to `aff_clicks` with SubIDs
- 302 redirects to merchant

### 3. Schedulers (pg_cron)
- ✅ `ia-promos-ingest`: Every 60 minutes
- ✅ `deals-build-feed`: Every 2 hours
- ✅ Extensions enabled: `pg_cron`, `pg_net`

### 4. UI Components

#### DealsGrid.tsx
- Fetches from `deals-list` with `include_generic=0` (coupons only)
- Uses direct fetch (no auth) to public endpoint
- Infinite scroll with IntersectionObserver
- Logs impressions to `aff_impressions`

#### DealCard.tsx
- Displays promo title (not "Official Store")
- Shows code with copy button OR "Auto-applies" chip
- Expiry badge (red if <7 days, outline otherwise)
- Tags: min_spend, categories
- Platform logo from API (pre-resolved)
- CTA: "Shop on {platform}" → `/go-deeplink/:id`

#### DealDetailModal.tsx
- **FIXED:** `h-[85vh]` container with proper scroll
- Scrollable content with `pb-24` (room for CTA)
- **FIXED:** Footer is `fixed bottom-0` (always visible, never hidden)
- Shows platform logo, title, expiry, code, summary, image
- CTA button never gets buried by content

### 5. Config Files

#### supabase/config.toml
- ✅ Added `[functions.ia-promos-ingest]` with `verify_jwt = true`
- ✅ `[functions.deals-list]` is `verify_jwt = false` (public)
- ✅ `[functions.go-deeplink]` is `verify_jwt = false` (public)
- ✅ `[functions.deal-detail]` is `verify_jwt = false` (public)

### 6. Environment Variables (Expected)
The system works with these defaults, but can be overridden:
```
IA_API_BASE_URL=https://api.involve.asia
IA_PROMOS_COUPONS_ENDPOINT=/api/coupons/latest
IA_PROMOS_CAMPAIGNS_ENDPOINT=/api/campaigns/latest
IA_AUTH_SCHEME=headers
IA_API_KEY=<your key>
IA_API_SECRET=<your secret>
```

## 🎯 QA Checklist (NEXT STEPS)

1. **Run Pipeline:**
   - Go to `/ia-admin`
   - Click "Run Full Pipeline"
   - This will:
     - Execute `ia-promos-ingest` → populates `ia_promos`
     - Execute `deals-build-feed` → creates `deals_feed` entries

2. **Verify Data:**
   ```sql
   SELECT COUNT(*) FROM ia_promos WHERE ends_at IS NULL OR ends_at >= now();
   -- Should return > 0 promos
   
   SELECT COUNT(*) FROM deals_feed WHERE has_coupon = true;
   -- Should return > 0 coupon deals
   ```

3. **Test /affiliates Page:**
   - Should show real promo titles (not "Official Store")
   - Cards should show codes or "Auto-applies" chip
   - Clicking card opens modal with copyable code
   - Modal CTA is always visible (not hidden)
   - Clicking CTA redirects to merchant via deeplink

4. **Test Deeplink Flow:**
   - Click "Shop on {platform}" button
   - Should go to `/functions/v1/go-deeplink/{id}?pos=card_1`
   - Should 302 redirect to merchant
   - Check `aff_clicks` table for logged click with SubIDs

5. **Test Schedulers (Optional):**
   ```sql
   SELECT * FROM cron.job WHERE jobname IN ('ia-promos-ingest-hourly', 'deals-build-feed-2hourly');
   -- Should show 2 scheduled jobs
   ```

## 📊 Data Flow

```
IA API (/coupons, /campaigns)
    ↓
ia-promos-ingest (60min)
    ↓
ia_promos table
    ↓
deals-build-feed (2h)
    ↓
ia-deeplink-generate
    ↓
ia_promo_deeplinks + deals_feed
    ↓
deals-list (public API)
    ↓
DealsGrid component (/affiliates)
    ↓
DealCard (shows code, title, tags)
    ↓
go-deeplink (public 302)
    ↓
Merchant website
```

## 🔒 Security Notes

- All sensitive endpoints (ingests, build-feed) require JWT
- Public endpoints (deals-list, go-deeplink) use SERVICE_ROLE_KEY internally
- No user credentials needed for viewing/clicking deals
- RLS policies prevent unauthorized writes to ia_promos, ia_promo_deeplinks

## 🚀 What's Different from Before

**BEFORE:**
- Deals built from `ia_landings` (generic "Official Store" cards)
- No real coupon codes
- No promo-specific data
- Manual scraping attempts

**NOW:**
- Deals built from `ia_promos` (real IA API data)
- Real coupon codes with copy functionality
- Promo titles, summaries, images, tags
- Direct API ingestion (no scraping needed)
- One card per promo (not per advertiser)

---

**Implementation Status: ✅ COMPLETE**
All requirements from the user's spec have been implemented with exact precision.
