# Logo Autofill System

## Overview
Every voucher displays a merchant logo through a multi-stage resolution pipeline with intelligent fallbacks and caching.

## Architecture

### Database Schema
- **vouchers table**: Added columns for `merchant_logo_path`, `logo_source`, `merchant_domain`, `logo_cache_updated_at`
- **merchant_logo_cache table**: Shared cache to avoid re-generating logos for the same merchant
- **logos bucket**: Private storage bucket with RLS policies for authenticated users

### Logo Resolution Pipeline

1. **Cache Check**: First checks `merchant_logo_cache` for existing logo
2. **Web Resolver**: Tries multiple sources in order:
   - Clearbit logo API
   - Unavatar API
   - Google Favicon (with size threshold)
3. **Vision Crop** (planned): Extract logo from uploaded voucher image using AI vision
4. **AI Generation**: Fallback using OpenAI's gpt-image-1 to create a branded initial icon
5. **Graceful Fallback**: If all fail, UI shows gradient initial letter

### Edge Functions

#### `/functions/logo-autofill`
Main resolution function that orchestrates the pipeline.
- Input: `{ voucherId, merchant, domain?, voucherImagePath?, force? }`
- Output: `{ ok, logoPath, source }`
- Uses service role key to bypass RLS
- Updates both cache and voucher tables

#### `/functions/logo-backfill`
Scheduled job to fix old vouchers missing logos.
- Processes up to 100 vouchers per run
- Rate-limited to 5/second
- Checks for null logos or stale cache (>90 days)

### Frontend Components

#### `<Logo>`
Reusable component that:
- Accepts storage path (not signed URL)
- Generates fresh signed URLs (2hr TTL)
- Auto-refreshes every 90 minutes
- Handles errors with retry + gradient fallback
- Consistent sizing: `w-12 h-12` (sm), `w-16 h-16` (md)

#### `useLogoResolver` Hook
- `resolveLogo()`: Triggers autofill for a voucher
- `uploadManualLogo()`: Allows user to upload custom logo
- Both update `merchant_logo_path` (not signed URL)

### Integration Points

1. **AddVoucher**: Triggers autofill on voucher creation (background)
2. **VoucherDetail**: Auto-resolves when merchant name changes (debounced)
3. **LogoUpload**: Manual override with "Try Again" button
4. **Dashboard/History**: All use shared `<Logo>` component

## Security & Performance

- Storage bucket is private with RLS policies
- Signed URLs expire in 2 hours, auto-refresh
- Logos normalized to 256x256 PNG
- Merchant keys normalized: lowercase, no punctuation
- Cache prevents redundant API calls/generation

## Legal Disclaimer
"Logos shown for recognition in this prototype. Trademarks belong to respective owners."

## Future Enhancements
- Vision crop: Extract logo from voucher images using Gemini Vision
- Wikimedia API: Search for official brand logos
- User feedback: Mark logo as incorrect → trigger regeneration
