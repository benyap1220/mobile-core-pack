import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, RefreshCw, Plus, Trash2, Upload } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import BrandAvatar from "@/components/BrandAvatar";

interface MerchantDomain {
  merchant_slug: string;
  domain: string;
  updated_at?: string;
}

interface CuratedOverride {
  brand_slug: string;
  storage_path: string;
  source: string;
  updated_at: string;
}

export default function MerchantManager() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [domains, setDomains] = useState<MerchantDomain[]>([]);
  const [overrides, setOverrides] = useState<CuratedOverride[]>([]);
  const [loading, setLoading] = useState(true);
  const [newMerchant, setNewMerchant] = useState("");
  const [newDomain, setNewDomain] = useState("");
  const [refreshing, setRefreshing] = useState<string | null>(null);
  const [uploadingCurated, setUploadingCurated] = useState<string | null>(null);

  useEffect(() => {
    fetchData();
  }, []);

  async function fetchData() {
    try {
      const domainsRes = await supabase
        .from("merchant_domain_map")
        .select("*")
        .order("merchant_slug");

      if (domainsRes.error) throw domainsRes.error;
      setDomains(domainsRes.data || []);

      // Fetch overrides separately with proper typing
      const overridesRes = await supabase
        .from("brand_logo_overrides")
        .select("brand_slug, storage_path, source, updated_at")
        .order("brand_slug");

      if (overridesRes.error) throw overridesRes.error;
      setOverrides((overridesRes.data || []) as CuratedOverride[]);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  }

  async function addDomain() {
    if (!newMerchant || !newDomain) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Please enter both merchant name and domain",
      });
      return;
    }

    try {
      const { error } = await supabase
        .from("merchant_domain_map")
        .upsert({
          merchant_slug: newMerchant.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, ''),
          domain: newDomain.trim(),
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Merchant domain added",
      });

      setNewMerchant("");
      setNewDomain("");
      fetchData();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message,
      });
    }
  }

  async function refreshLogo(merchant: string) {
    setRefreshing(merchant);
    try {
      const response = await fetch(
        "https://cnayuxiwjgpjrzkphhwz.supabase.co/functions/v1/resolve-logo",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "apikey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNuYXl1eGl3amdwanJ6a3BoaHd6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTk2NzM4MDYsImV4cCI6MjA3NTI0OTgwNn0.ZA_6hIEYMQCDRGvyvmc3x-xTFg_MOhgKiZvmZ9TBWJI",
          },
          body: JSON.stringify({
            slug: merchant,
            force: true,
          }),
        }
      );

      const data = await response.json();

      if (data.publicUrl) {
        toast({
          title: "Logo Refreshed",
          description: `Updated logo for ${merchant}`,
        });
      } else {
        throw new Error("Failed to refresh logo");
      }
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message,
      });
    } finally {
      setRefreshing(null);
    }
  }

  async function deleteDomain(merchant: string) {
    try {
      const { error } = await supabase
        .from("merchant_domain_map")
        .delete()
        .eq("merchant_slug", merchant);

      if (error) throw error;

      toast({
        title: "Deleted",
        description: "Merchant domain removed",
      });

      fetchData();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message,
      });
    }
  }

  async function uploadCuratedLogo(brandSlug: string) {
    setUploadingCurated(brandSlug);
    try {
      const response = await fetch(
        "https://cnayuxiwjgpjrzkphhwz.supabase.co/functions/v1/upload-curated-logo",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "apikey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNuYXl1eGl3amdwanJ6a3BoaHd6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTk2NzM4MDYsImV4cCI6MjA3NTI0OTgwNn0.ZA_6hIEYMQCDRGvyvmc3x-xTFg_MOhgKiZvmZ9TBWJI",
          },
          body: JSON.stringify({ brandSlug }),
        }
      );

      const data = await response.json();

      if (data.publicUrl) {
        toast({
          title: "Curated Logo Uploaded",
          description: `Uploaded Simple Icons logo for ${brandSlug}`,
        });
        fetchData();
        // Also refresh the logo display
        await refreshLogo(brandSlug);
      } else {
        throw new Error(data.error || "Failed to upload curated logo");
      }
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message,
      });
    } finally {
      setUploadingCurated(null);
    }
  }

  function hasCuratedOverride(slug: string): boolean {
    return overrides.some(o => o.brand_slug === slug);
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-sky-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 pb-20">
      <div className="container mx-auto px-4 pt-6 max-w-4xl">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("/settings")}
            className="rounded-full"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">Merchant Logos</h1>
            <p className="text-sm text-muted-foreground">
              Manage merchant domains and refresh logos
            </p>
          </div>
        </div>

        {/* Add New Domain */}
        <div className="glass rounded-2xl p-6 mb-6">
          <h2 className="text-lg font-semibold mb-4">Add/Override Domain</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div>
              <Label htmlFor="merchant">Merchant Name</Label>
              <Input
                id="merchant"
                placeholder="e.g., starbucks"
                value={newMerchant}
                onChange={(e) => setNewMerchant(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="domain">Domain</Label>
              <Input
                id="domain"
                placeholder="e.g., starbucks.com"
                value={newDomain}
                onChange={(e) => setNewDomain(e.target.value)}
              />
            </div>
          </div>
          <Button onClick={addDomain}>
            <Plus className="h-4 w-4 mr-2" />
            Add Domain
          </Button>
        </div>

        {/* Domains List */}
        <div className="glass rounded-2xl p-6">
          <h2 className="text-lg font-semibold mb-4">Registered Domains</h2>
          {loading ? (
            <p className="text-muted-foreground">Loading...</p>
          ) : domains.length === 0 ? (
            <p className="text-muted-foreground">No domains registered yet</p>
          ) : (
            <div className="space-y-3">
              {domains.map((item) => {
                const override = overrides.find(o => o.brand_slug === item.merchant_slug);
                const isCurated = !!override;
                
                return (
                  <div
                    key={item.merchant_slug}
                    className="flex items-center gap-4 p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                  >
                    <BrandAvatar merchant={item.merchant_slug} size="md" />
                    <div className="flex-1 min-w-0">
                      <p className="font-medium capitalize text-base flex items-center gap-2">
                        {item.merchant_slug.replace(/-/g, ' ')}
                        {isCurated && (
                          <span className="text-xs bg-green-500/10 text-green-600 dark:text-green-400 px-2 py-0.5 rounded-full">
                            Curated
                          </span>
                        )}
                      </p>
                      <p className="text-sm text-muted-foreground truncate">
                        {item.domain}
                      </p>
                      {override && (
                        <p className="text-xs text-muted-foreground truncate">
                          Source: {override.source} • {override.storage_path}
                        </p>
                      )}
                      {item.updated_at && (
                        <p className="text-xs text-muted-foreground">
                          Updated {new Date(item.updated_at).toLocaleDateString()}
                        </p>
                      )}
                    </div>
                    <div className="flex gap-2">
                      {!isCurated && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => uploadCuratedLogo(item.merchant_slug)}
                          disabled={uploadingCurated === item.merchant_slug}
                          title="Upload curated Simple Icons logo"
                        >
                          <Upload className={`h-4 w-4 ${uploadingCurated === item.merchant_slug ? 'animate-pulse' : ''}`} />
                        </Button>
                      )}
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => refreshLogo(item.merchant_slug)}
                        disabled={refreshing === item.merchant_slug}
                        title={isCurated ? "Re-fetch curated logo" : "Force refresh from external sources"}
                      >
                        <RefreshCw
                          className={`h-4 w-4 ${
                            refreshing === item.merchant_slug ? "animate-spin" : ""
                          }`}
                        />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => deleteDomain(item.merchant_slug)}
                        title="Delete domain mapping"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
