import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { 
  ArrowLeft, 
  Loader2, 
  ShieldAlert,
  Trash2,
  Image as ImageIcon
} from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import DealCardPreview from "@/components/deals/DealCardPreview";
import HomeVoucherPreviewMock from "@/components/deals/HomeVoucherPreviewMock";

interface ApprovedBorder {
  id: string;
  title: string | null;
  preview_path: string | null;
  image_path: string | null;
  svg_path: string | null;
  webm_path: string | null;
  style_tag: string | null;
  layout_mode: string | null;
  target: string;
  created_at: string;
}

export default function ApprovedBorders() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);
  const [checking, setChecking] = useState(true);
  const [loading, setLoading] = useState(true);
  const [borders, setBorders] = useState<ApprovedBorder[]>([]);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  // Check admin status
  useEffect(() => {
    const checkAdminStatus = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        
        if (!user) {
          navigate("/auth");
          return;
        }

        const { data: roles } = await supabase
          .from("user_roles")
          .select("role")
          .eq("user_id", user.id)
          .eq("role", "admin")
          .maybeSingle();

        setIsAdmin(!!roles);
        if (!roles) {
          toast({
            title: "Access Denied",
            description: "You need admin privileges to access this page",
            variant: "destructive",
          });
        }
      } catch (error) {
        console.error("Error checking admin:", error);
        setIsAdmin(false);
      } finally {
        setChecking(false);
      }
    };

    checkAdminStatus();
  }, [navigate, toast]);

  // Fetch approved borders from border_prototypes
  useEffect(() => {
    if (isAdmin) {
      fetchApprovedBorders();
    }
  }, [isAdmin]);

  const fetchApprovedBorders = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from("border_prototypes")
        .select("*")
        .eq("is_approved", true)
        .order("created_at", { ascending: false });

      if (error) throw error;
      
      setBorders(data || []);
    } catch (error) {
      console.error("Error fetching approved borders:", error);
      toast({
        title: "Error",
        description: "Failed to load approved borders",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteId) return;

    try {
      // Get the prototype details to match with border_styles
      const borderToDelete = borders.find(b => b.id === deleteId);
      if (!borderToDelete) return;

      // Delete from border_styles (production) - match by key attributes
      // This removes it from active distribution
      const { error: styleError } = await supabase
        .from("border_styles")
        .delete()
        .eq("title", borderToDelete.title)
        .eq("style_tag", borderToDelete.style_tag)
        .eq("target", borderToDelete.target);

      if (styleError) {
        console.error("Error deleting from border_styles:", styleError);
        // Continue anyway to delete from prototypes
      }

      // Delete from border_prototypes
      const { error } = await supabase
        .from("border_prototypes")
        .delete()
        .eq("id", deleteId);

      if (error) throw error;

      toast({
        title: "Deleted",
        description: "Border removed from active distribution",
      });

      setBorders(borders.filter(b => b.id !== deleteId));
      setDeleteId(null);
    } catch (error) {
      console.error("Delete error:", error);
      toast({
        title: "Failed to delete",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive",
      });
    }
  };

  const getPreviewUrl = (border: ApprovedBorder) => {
    const baseUrl = `${import.meta.env.VITE_SUPABASE_URL}/storage/v1/object/public`;
    
    if (border.preview_path) {
      return `${baseUrl}/borders_previews/${border.preview_path}`;
    }
    if (border.image_path) {
      return `${baseUrl}/borders/${border.image_path}`;
    }
    return null;
  };

  if (checking) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="glass rounded-2xl p-8 max-w-md w-full text-center space-y-4">
          <ShieldAlert className="h-12 w-12 text-destructive mx-auto" />
          <h1 className="text-2xl font-bold">Access Denied</h1>
          <p className="text-muted-foreground">
            This page requires administrator privileges.
          </p>
          <Button onClick={() => navigate("/")} className="w-full">
            Return to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-20">
      <motion.header
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="sticky top-0 z-50 glass-card border-b border-white/20 px-4 py-4"
      >
        <div className="max-w-7xl mx-auto flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("/admin/borders")}
            className="rounded-full"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-2xl font-bold gradient-text">Approved Borders</h1>
          <Badge variant="outline" className="ml-auto">
            {borders.length} borders
          </Badge>
        </div>
      </motion.header>

      <main className="max-w-7xl mx-auto px-4 py-6">
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : borders.length === 0 ? (
          <div className="text-center py-12 glass-card rounded-2xl p-8">
            <ImageIcon className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h2 className="text-xl font-semibold mb-2">No Approved Borders</h2>
            <p className="text-muted-foreground mb-4">
              Go to Border Manager to upload and approve borders
            </p>
            <Button onClick={() => navigate("/admin/borders")}>
              Go to Border Manager
            </Button>
          </div>
        ) : (
          <div className="grid gap-6">
            {borders.map((border) => {
              return (
                <div key={border.id} className="glass-card rounded-2xl p-6 space-y-4">
                  {/* Live Preview */}
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium text-muted-foreground">
                      How it looks on {border.target === 'home' ? 'home' : 'deals'} page (mobile view)
                    </h3>
                    {border.target === 'home' ? (
                      <div className="w-full max-w-[600px] mx-auto">
                        <HomeVoucherPreviewMock 
                          borderStyleId={border.id}
                          sourceTable="border_prototypes"
                        />
                      </div>
                    ) : (
                      <div className="max-w-[200px] mx-auto">
                        <DealCardPreview 
                          borderStyleId={border.id}
                          sourceTable="border_prototypes"
                        />
                      </div>
                    )}
                  </div>
                  
                  {/* Border Info */}
                  <div className="space-y-2 border-t pt-4">
                    <div>
                      <h3 className="font-semibold text-sm line-clamp-1">
                        {border.title || "Untitled Border"}
                      </h3>
                      <p className="text-xs text-muted-foreground">
                        {new Date(border.created_at).toLocaleDateString()}
                      </p>
                    </div>

                    <div className="flex flex-wrap gap-1">
                      {border.style_tag && (
                        <Badge variant="secondary" className="text-xs">
                          {border.style_tag}
                        </Badge>
                      )}
                      {border.layout_mode && (
                        <Badge variant="outline" className="text-xs">
                          {border.layout_mode}
                        </Badge>
                      )}
                      {border.svg_path && (
                        <Badge variant="outline" className="text-xs">
                          SVG
                        </Badge>
                      )}
                      {border.image_path && (
                        <Badge variant="outline" className="text-xs">
                          Image
                        </Badge>
                      )}
                      {border.webm_path && (
                        <Badge variant="outline" className="text-xs">
                          Video
                        </Badge>
                      )}
                    </div>

                    <Button
                      variant="destructive"
                      size="sm"
                      className="w-full"
                      onClick={() => setDeleteId(border.id)}
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Delete Border
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this border. This action cannot be undone.
              Any deals using this border will no longer display it.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
