import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { Loader2, RefreshCw, Download, Plus, TestTube, Activity, CheckCircle, AlertCircle, Database } from "lucide-react";

interface HealthData {
  ia_advertisers: { total: number; approved: number };
  ia_landings: { total: number; deeplinkable: number; last_checked_at: string | null };
  ia_deeplinks: { total: number; by_type: Record<string, number> };
  deals_feed: { total: number; current_rotation_batch: string | null; latest_created_at: string | null };
  analytics_24h: { clicks: number; impressions: number };
  status: 'healthy' | 'needs_data' | 'error';
  timestamp: string;
}

export default function IAAdmin() {
  const { toast } = useToast();
  const [health, setHealth] = useState<HealthData | null>(null);
  const [loadingHealth, setLoadingHealth] = useState(false);
  const [ingesting, setIngesting] = useState(false);
  const [building, setBuilding] = useState(false);
  const [addingLanding, setAddingLanding] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testingDeeplink, setTestingDeeplink] = useState(false);
  const [deeplinkTest, setDeeplinkTest] = useState<any>(null);
  const [seeding, setSeeding] = useState(false);
  const [backfillingLogos, setBackfillingLogos] = useState(false);
  const [advertisers, setAdvertisers] = useState<any[]>([]);
  const [deals, setDeals] = useState<any[]>([]);
  
  const [offerId, setOfferId] = useState("");
  const [landingUrl, setLandingUrl] = useState("");
  const [landingKind, setLandingKind] = useState<"home" | "promo" | "category" | "product">("home");
  
  const [selectedDealId, setSelectedDealId] = useState("");
  const [couponCode, setCouponCode] = useState("");
  const [promoNotes, setPromoNotes] = useState("");

  useEffect(() => {
    loadAdvertisers();
    loadDeals();
    fetchHealth();
  }, []);

  const fetchHealth = async () => {
    setLoadingHealth(true);
    try {
      const { data, error } = await supabase.functions.invoke('ia-health');
      if (error) throw error;
      setHealth(data);
    } catch (error) {
      console.error('Health check failed:', error);
    } finally {
      setLoadingHealth(false);
    }
  };

  const loadAdvertisers = async () => {
    const { data } = await supabase
      .from('ia_advertisers')
      .select('*')
      .eq('approved', true)
      .order('name');
    if (data) setAdvertisers(data);
  };

  const loadDeals = async () => {
    const { data } = await supabase
      .from('deals_feed')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(100);
    if (data) setDeals(data);
  };

  const handlePingTest = async () => {
    setTesting(true);
    try {
      const { data, error } = await supabase.functions.invoke('ia-ping-deeplink', {
        method: 'POST',
      });

      if (error) throw error;

      if (data.ok) {
        toast({
          title: "Connection Successful",
          description: `Auth scheme: ${data.auth_scheme}. Sample deeplink generated.`,
        });
        console.log('Ping test result:', data);
      } else {
        toast({
          title: "Connection Failed",
          description: `Status: ${data.status}. Check console for details.`,
          variant: "destructive",
        });
        console.error('Ping test error:', data);
      }
    } catch (error) {
      console.error('Error testing connection:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to test connection",
        variant: "destructive",
      });
    } finally {
      setTesting(false);
    }
  };

  const handleDeeplinkTest = async () => {
    setTestingDeeplink(true);
    setDeeplinkTest(null);
    try {
      const { data, error } = await supabase.functions.invoke('ia-test-deeplink', {
        body: {
          offer_id: 3579, // AliExpress default
          test_url: 'https://www.lazada.com.my/',
        },
      });

      if (error) throw error;

      setDeeplinkTest(data);
      
      if (data.ok && data.deeplink_result.success) {
        toast({
          title: "Deeplink Test Complete",
          description: data.interpretation,
        });
      } else {
        toast({
          title: "Deeplink Test Failed",
          description: data.interpretation || data.error,
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Error testing deeplink:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to test deeplink",
        variant: "destructive",
      });
    } finally {
      setTestingDeeplink(false);
    }
  };

  const handleIngestOffers = async () => {
    setIngesting(true);
    try {
      const { data, error } = await supabase.functions.invoke('ia-offers-ingest', {
        method: 'POST',
      });

      if (error) throw error;

      if (!data.ok) {
        const errorMsg = data.where 
          ? `[${data.where}] ${data.error || data.reason || 'Unknown error'}`
          : data.error || data.reason || 'Unknown error';
        
        const detailMsg = data.body 
          ? `Status ${data.status}: ${data.body.substring(0, 200)}${data.body.length > 200 ? '...' : ''}`
          : data.hint || data.details || 'Check logs for details';
        
        // Show stats if available
        let statsMsg = '';
        if (data.stats) {
          const s = data.stats;
          statsMsg = `\n\nStage counts:\nRaw: ${s.raw} → Status: ${s.afterStatus} → Country: ${s.afterCountry} → Allowlist: ${s.afterAllowlist}\nUpserted: ${s.upsertedAdvertisers}, Landings: ${s.seededLandings} (${s.pages} pages)`;
        }
        
        toast({
          title: "Ingest Failed",
          description: `${errorMsg}\n\n${detailMsg}${statsMsg}`,
          variant: "destructive",
        });
        console.error('Full ingest error:', data);
        return;
      }

      // Success - show stats
      const s = data.stats || {};
      const statsLine = `Raw: ${s.raw || 0} → Status: ${s.afterStatus || 0} → Country: ${s.afterCountry || 0} → Allowlist: ${s.afterAllowlist || 0}\nUpserted: ${s.upsertedAdvertisers || 0} advertisers, ${s.seededLandings || 0} landings (${s.pages || 0} pages)`;
      
      toast({
        title: "Success",
        description: statsLine,
      });
      
      // Show warning if allowlist was 0
      if (s.afterAllowlist === 0) {
        setTimeout(() => {
          toast({
            title: "Fallback Used",
            description: "No approved programs matched MY/allowlist. Using fallback so the feed still renders.",
            variant: "default",
          });
        }, 1000);
      }
      
      loadAdvertisers();
      fetchHealth();
    } catch (error) {
      console.error('Error ingesting offers:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to ingest offers",
        variant: "destructive",
      });
    } finally {
      setIngesting(false);
    }
  };

  const handleBuildFeed = async () => {
    setBuilding(true);
    try {
      const { data, error } = await supabase.functions.invoke('deals-build-feed', {
        method: 'POST',
      });

      if (error) throw error;

      const builtMsg = `Built ${data.built || data.deals_created || 0} deals${data.fallback ? ' (using fallback)' : ''}`;
      
      toast({
        title: "Success",
        description: builtMsg,
      });
      
      if (data.fallback) {
        setTimeout(() => {
          toast({
            title: "Fallback Mode",
            description: "No approved advertisers/landings found. Created deals from available data.",
            variant: "default",
          });
        }, 1000);
      }
      
      loadDeals();
      fetchHealth();
    } catch (error) {
      console.error('Error building feed:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to build feed",
        variant: "destructive",
      });
    } finally {
      setBuilding(false);
    }
  };

  const handleSeedDemo = async () => {
    setSeeding(true);
    try {
      const { data, error } = await supabase.functions.invoke('ia-seed-demo-deals');
      if (error) throw error;

      toast({
        title: "Success",
        description: `Created ${data.demo_deals_created} demo deals`,
      });
      loadDeals();
      fetchHealth();
    } catch (error) {
      console.error('Error building feed:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to build feed",
        variant: "destructive",
      });
    } finally {
      setBuilding(false);
    }
  };

  const handleAddLanding = async () => {
    if (!offerId || !landingUrl) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }

    setAddingLanding(true);
    try {
      // First, generate the deeplink
      const { data: deeplinkData, error: deeplinkError } = await supabase.functions.invoke('ia-deeplink-generate', {
        body: {
          offer_id: parseInt(offerId),
          raw_url: landingUrl,
          subs: {
            sub1: 'dealsgrid',
            sub2: 'manual',
            sub3: offerId,
            sub4: landingKind,
          },
        },
      });

      if (deeplinkError) throw deeplinkError;

      // Insert the landing
      const { error: landingError } = await supabase.from('ia_landings').insert({
        offer_id: parseInt(offerId),
        url: landingUrl,
        kind: landingKind,
        title: `Manual ${landingKind}`,
        score: landingKind === 'promo' ? 0.3 : landingKind === 'category' ? 0.15 : landingKind === 'product' ? 0.2 : 0.1,
      });

      if (landingError && !landingError.message.includes('duplicate')) {
        throw landingError;
      }

      // Get advertiser info
      const { data: advertiser } = await supabase
        .from('ia_advertisers')
        .select('*')
        .eq('offer_id', parseInt(offerId))
        .single();

      if (advertiser && deeplinkData.deeplink_id) {
        // Add to deals feed
        await supabase.from('deals_feed').insert({
          offer_id: parseInt(offerId),
          deeplink_id: deeplinkData.deeplink_id,
          title: `${advertiser.name} - ${landingKind}`,
          subtitle: advertiser.categories?.slice(0, 2).join(', ') || 'Special offer',
          tags: advertiser.categories || [],
          image_url: advertiser.logo_url,
          platform: advertiser.name,
          country: 'MY',
          source: 'IA',
          score: landingKind === 'promo' ? 0.3 : 0.15,
        });
      }

      toast({
        title: "Success",
        description: "Landing added and deal created",
      });

      setOfferId("");
      setLandingUrl("");
      setLandingKind("home");
      loadDeals();
    } catch (error) {
      console.error('Error adding landing:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to add landing",
        variant: "destructive",
      });
    } finally {
      setAddingLanding(false);
    }
  };

  const handleAddPromoNote = async () => {
    if (!selectedDealId) {
      toast({
        title: "Error",
        description: "Please select a deal",
        variant: "destructive",
      });
      return;
    }

    try {
      const { error } = await supabase.from('promo_notes').insert({
        deal_id: selectedDealId,
        coupon_code: couponCode || null,
        notes: promoNotes || null,
      });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Promo note added successfully",
      });

      setSelectedDealId("");
      setCouponCode("");
      setPromoNotes("");
    } catch (error) {
      console.error('Error adding promo note:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to add promo note",
        variant: "destructive",
      });
    }
  };

  const handleBackfillLogos = async () => {
    setBackfillingLogos(true);
    try {
      // Get all advertisers without valid Supabase storage URLs
      const { data: advs, error: fetchError } = await supabase
        .from('ia_advertisers')
        .select('offer_id, name, logo_url');
      
      if (fetchError) throw fetchError;

      const needsRefresh = advs?.filter(a => 
        !a.logo_url || !a.logo_url.includes('supabase.co/storage')
      ) || [];

      if (needsRefresh.length === 0) {
        toast({
          title: "All Logos Valid",
          description: "All advertisers have valid storage URLs",
        });
        setBackfillingLogos(false);
        return;
      }

      let success = 0;
      let failed = 0;

      for (const adv of needsRefresh) {
        try {
          const { data, error } = await supabase.functions.invoke('logo-proxy', {
            body: { merchant_name: adv.name, force: true }
          });

          if (error || !data?.logo_url) {
            failed++;
            console.error(`Failed: ${adv.name}`, error || data);
          } else {
            success++;
            console.log(`✓ ${adv.name} → ${data.logo_url}`);
          }
        } catch (err) {
          failed++;
          console.error(`Error for ${adv.name}:`, err);
        }
      }

      toast({
        title: "Logo Refresh Complete",
        description: `✓ ${success} succeeded, ✗ ${failed} failed (of ${needsRefresh.length} total)`,
      });

      loadAdvertisers();
    } catch (error) {
      console.error('Error refreshing logos:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to refresh logos",
        variant: "destructive",
      });
    } finally {
      setBackfillingLogos(false);
    }
  };

  const handleFullPipeline = async () => {
    try {
      toast({
        title: "Starting Full Pipeline",
        description: "Step 1/3: Ingesting offers...",
      });

      // Step 1: Ingest offers
      setIngesting(true);
      const { data: ingestData, error: ingestError } = await supabase.functions.invoke('ia-offers-ingest', {
        method: 'POST',
      });
      setIngesting(false);

      if (ingestError) throw ingestError;
      if (!ingestData.ok) {
        throw new Error(ingestData.error || 'Ingest failed');
      }

      const s = ingestData.stats || {};
      toast({
        title: "Step 1 Complete",
        description: `Ingested ${s.afterAllowlist || 0} offers, ${s.seededLandings || 0} landings`,
      });

      // Step 2: Ingest promos/coupons
      toast({
        title: "Step 2/3",
        description: "Fetching promos and coupons from IA...",
      });
      
      setIngesting(true);
      const { data: promosData, error: promosError } = await supabase.functions.invoke('ia-promos-ingest', {
        method: 'POST',
      });
      setIngesting(false);

      if (promosError) throw promosError;
      
      toast({
        title: "Step 2 Complete",
        description: `Ingested ${promosData?.valid || 0} promos`,
      });

      // Step 3: Build feed
      toast({
        title: "Step 3/3",
        description: "Building deals feed...",
      });

      setBuilding(true);
      const { data: buildData, error: buildError } = await supabase.functions.invoke('deals-build-feed', {
        method: 'POST',
      });
      setBuilding(false);

      if (buildError) throw buildError;

      toast({
        title: "Pipeline Complete! 🎉",
        description: `Created ${buildData.built || buildData.deals_created || 0} deals`,
      });

      // Refresh data
      loadAdvertisers();
      loadDeals();
      fetchHealth();
    } catch (error) {
      setIngesting(false);
      setBuilding(false);
      console.error('Pipeline error:', error);
      toast({
        title: "Pipeline Failed",
        description: error instanceof Error ? error.message : "Check console for details",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">IA Admin</h1>

        <div className="space-y-6">
          {health && (
            <Card className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold">System Health</h2>
                <Button size="sm" variant="outline" onClick={fetchHealth} disabled={loadingHealth}>
                  <RefreshCw className={`h-4 w-4 ${loadingHealth ? 'animate-spin' : ''}`} />
                </Button>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Advertisers</p>
                  <p className="text-2xl font-bold">{health.ia_advertisers.approved}</p>
                  <p className="text-xs text-muted-foreground">of {health.ia_advertisers.total} total</p>
                </div>
                
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Landings</p>
                  <p className="text-2xl font-bold">{health.ia_landings.deeplinkable}</p>
                  <p className="text-xs text-muted-foreground">of {health.ia_landings.total} total</p>
                </div>
                
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Deeplinks</p>
                  <p className="text-2xl font-bold">{health.ia_deeplinks.total}</p>
                  <p className="text-xs text-muted-foreground">cached</p>
                </div>
                
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Deals Feed</p>
                  <p className="text-2xl font-bold">{health.deals_feed.total}</p>
                  <p className="text-xs text-muted-foreground">deals</p>
                </div>
                
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Clicks (24h)</p>
                  <p className="text-2xl font-bold">{health.analytics_24h.clicks}</p>
                </div>
                
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Impressions (24h)</p>
                  <p className="text-2xl font-bold">{health.analytics_24h.impressions}</p>
                </div>
              </div>
              
              <div className="mt-4 pt-4 border-t">
                <div className="flex items-center gap-2">
                  {health.status === 'healthy' && (
                    <>
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="text-sm font-medium text-green-500">System Healthy</span>
                    </>
                  )}
                  {health.status === 'needs_data' && (
                    <>
                      <AlertCircle className="h-4 w-4 text-yellow-500" />
                      <span className="text-sm font-medium text-yellow-500">Needs Data - Run Ingest</span>
                    </>
                  )}
                  {health.status === 'error' && (
                    <>
                      <AlertCircle className="h-4 w-4 text-red-500" />
                      <span className="text-sm font-medium text-red-500">System Error</span>
                    </>
                  )}
                </div>
              </div>
            </Card>
          )}

          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">Test Connection</h2>
            <p className="text-sm text-muted-foreground mb-4">
              Verify IA API credentials and authentication scheme
            </p>
            <div className="flex gap-2">
              <Button onClick={handlePingTest} disabled={testing}>
                {testing ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Testing...
                  </>
                ) : (
                  <>
                    <TestTube className="mr-2 h-4 w-4" />
                    Test IA Connection
                  </>
                )}
              </Button>
              <Button onClick={handleDeeplinkTest} disabled={testingDeeplink} variant="outline">
                {testingDeeplink ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Testing...
                  </>
                ) : (
                  <>
                    <Activity className="mr-2 h-4 w-4" />
                    Test Deeplink
                  </>
                )}
              </Button>
            </div>

            {deeplinkTest && (
              <div className="mt-4 p-4 bg-muted rounded-lg space-y-3">
                <div className="flex items-start gap-2">
                  {deeplinkTest.deeplink_result.success ? (
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                  ) : (
                    <AlertCircle className="h-5 w-5 text-red-500 mt-0.5" />
                  )}
                  <div className="flex-1">
                    <p className="font-medium text-sm">{deeplinkTest.interpretation}</p>
                  </div>
                </div>
                
                <Separator />
                
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <p className="text-muted-foreground">Test Offer</p>
                    <p className="font-medium">{deeplinkTest.test_params.advertiser_name}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Deeplink Type</p>
                    <Badge variant={deeplinkTest.deeplink_result.deeplink_type === 'standard' ? 'default' : 'secondary'}>
                      {deeplinkTest.deeplink_result.deeplink_type}
                    </Badge>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Tracking Link</p>
                    <p className="font-medium">{deeplinkTest.test_params.has_tracking_link ? '✅ Available' : '❌ None'}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Cached</p>
                    <p className="font-medium">{deeplinkTest.deeplink_result.cached ? 'Yes' : 'No'}</p>
                  </div>
                </div>
                
                {deeplinkTest.deeplink_result.fallback_reason && (
                  <div className="pt-2">
                    <p className="text-xs text-muted-foreground">Fallback Reason</p>
                    <Badge variant="outline" className="mt-1">{deeplinkTest.deeplink_result.fallback_reason}</Badge>
                  </div>
                )}
                
                {deeplinkTest.deeplink_result.deeplink_url && (
                  <div className="pt-2">
                    <p className="text-xs text-muted-foreground">Generated URL</p>
                    <code className="text-xs bg-background p-2 rounded block mt-1 break-all">
                      {deeplinkTest.deeplink_result.deeplink_url.substring(0, 100)}...
                    </code>
                  </div>
                )}
              </div>
            )}
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                Full Pipeline
              </CardTitle>
              <CardDescription>
                Run complete ingestion and build process (recommended)
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button 
                onClick={handleFullPipeline} 
                disabled={ingesting || building}
                className="w-full"
                size="lg"
              >
                {(ingesting || building) ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    {ingesting ? 'Ingesting...' : 'Building...'}
                  </>
                ) : (
                  <>
                    <Activity className="mr-2 h-4 w-4" />
                    Run Full Pipeline
                  </>
                )}
              </Button>
              <Separator />
              <div className="space-y-2">
                <p className="text-sm font-medium">Manual Steps:</p>
                <Button 
                  onClick={handleIngestOffers} 
                  disabled={ingesting}
                  variant="outline"
                  className="w-full"
                  size="sm"
                >
                  {ingesting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Ingesting...
                    </>
                  ) : (
                    <>
                      <Download className="mr-2 h-4 w-4" />
                      1. Ingest Offers
                    </>
                  )}
                </Button>
                <Button 
                  onClick={handleBuildFeed} 
                  disabled={building}
                  variant="outline"
                  className="w-full"
                  size="sm"
                >
                  {building ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Building...
                    </>
                  ) : (
                    <>
                      <Database className="mr-2 h-4 w-4" />
                      2. Build Feed
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">Backfill Logos</h2>
            <p className="text-sm text-muted-foreground mb-4">
              Auto-resolve missing advertiser logos using Clearbit, Unavatar, Google Favicons, or AI generation
            </p>
            <Button onClick={handleBackfillLogos} disabled={backfillingLogos}>
              {backfillingLogos ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Backfilling Logos...
                </>
              ) : (
                <>
                  <Database className="mr-2 h-4 w-4" />
                  Backfill Advertiser Logos
                </>
              )}
            </Button>
          </Card>

          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">Build Deals Feed</h2>
            <p className="text-sm text-muted-foreground mb-4">
              Generate deeplinks and materialize the deals feed from approved advertisers
            </p>
            <Button onClick={handleBuildFeed} disabled={building}>
              {building ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Building...
                </>
              ) : (
                <>
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Rebuild Feed Now
                </>
              )}
            </Button>
          </Card>

          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">Manual Add Landing</h2>
            <div className="space-y-4">
              <div>
                <Label htmlFor="offer-id">Offer ID</Label>
                <Input
                  id="offer-id"
                  type="number"
                  placeholder="12345"
                  value={offerId}
                  onChange={(e) => setOfferId(e.target.value)}
                />
              </div>

              <div>
                <Label htmlFor="landing-url">Landing URL</Label>
                <Input
                  id="landing-url"
                  type="url"
                  placeholder="https://example.com/promo"
                  value={landingUrl}
                  onChange={(e) => setLandingUrl(e.target.value)}
                />
              </div>

              <div>
                <Label htmlFor="landing-kind">Landing Type</Label>
                <Select value={landingKind} onValueChange={(v: any) => setLandingKind(v)}>
                  <SelectTrigger id="landing-kind">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="home">Home</SelectItem>
                    <SelectItem value="promo">Promo</SelectItem>
                    <SelectItem value="category">Category</SelectItem>
                    <SelectItem value="product">Product</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button onClick={handleAddLanding} disabled={addingLanding}>
                {addingLanding ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Adding...
                  </>
                ) : (
                  <>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Landing & Create Deal
                  </>
                )}
              </Button>
            </div>
          </Card>

          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">Seed Demo Deals</h2>
            <p className="text-sm text-muted-foreground mb-4">
              Create 5 demo deals for testing the UI (uses placeholder deeplinks)
            </p>
            <Button onClick={handleSeedDemo} disabled={seeding} variant="outline">
              {seeding ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Seeding...
                </>
              ) : (
                <>
                  <Database className="mr-2 h-4 w-4" />
                  Create 5 Demo Rows
                </>
              )}
            </Button>
          </Card>

          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">Add Promo Note</h2>
            <div className="space-y-4">
              <div>
                <Label htmlFor="deal-select">Select Deal</Label>
                <Select value={selectedDealId} onValueChange={setSelectedDealId}>
                  <SelectTrigger id="deal-select">
                    <SelectValue placeholder="Choose a deal..." />
                  </SelectTrigger>
                  <SelectContent>
                    {deals.map((deal) => (
                      <SelectItem key={deal.id} value={deal.id}>
                        {deal.title} ({deal.platform})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="coupon-code">Coupon Code (optional)</Label>
                <Input
                  id="coupon-code"
                  placeholder="SAVE20"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                />
              </div>

              <div>
                <Label htmlFor="promo-notes">Notes (optional)</Label>
                <Textarea
                  id="promo-notes"
                  placeholder="Exclusive offer - Free shipping on orders over RM100"
                  value={promoNotes}
                  onChange={(e) => setPromoNotes(e.target.value)}
                  rows={3}
                />
              </div>

              <Button onClick={handleAddPromoNote}>
                <Plus className="mr-2 h-4 w-4" />
                Add Promo Note
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
