import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { ArrowLeft } from "lucide-react";
import { AnimatePresence } from "framer-motion";
import { formatDealSummary, getConditionChips } from "@/lib/deals";
import { toast } from "@/hooks/use-toast";
import { useCurrencyPrefs } from "@/hooks/useCurrencyPrefs";
import BrandAvatar from "@/components/BrandAvatar";
import SwipeToActionRow from "@/components/SwipeToActionRow";

interface UsedVoucher {
  voucher_id: string;
  merchant: string;
  merchant_logo_path?: string | null;
  merchant_domain?: string | null;
  location?: string | null;
  deal_type: string;
  value: number | null;
  currency: string;
  conditions?: string | null;
  tags?: string[] | null;
  updated_at: string;
  display_title?: string | null;
  actual_amount_saved?: number | null;
}

export default function History() {
  const navigate = useNavigate();
  const [vouchers, setVouchers] = useState<UsedVoucher[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchUsedVouchers();
  }, []);

  const fetchUsedVouchers = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        navigate("/auth");
        return;
      }

      const { data, error } = await supabase
        .from("vouchers")
        .select("voucher_id, merchant, merchant_logo_path, merchant_domain, location, deal_type, value, currency, conditions, tags, updated_at, display_title, actual_amount_saved")
        .eq("user_id", user.id)
        .eq("status", "used")
        .order("updated_at", { ascending: false });

      if (error) throw error;
      setVouchers(data || []);
    } catch (error) {
      console.error("Error fetching used vouchers:", error);
      toast({
        title: "Error",
        description: "Failed to load history",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (voucherId: string) => {
    const voucherToDelete = vouchers.find((v) => v.voucher_id === voucherId);
    
    // Optimistic update
    setVouchers((prev) => prev.filter((v) => v.voucher_id !== voucherId));

    try {
      const { error } = await supabase
        .from("vouchers")
        .delete()
        .eq("voucher_id", voucherId);

      if (error) throw error;

      toast({
        title: "Deleted",
        description: "Voucher removed from history",
        action: (
          <button
            onClick={() => handleUndo(voucherToDelete!)}
            className="text-sm underline"
          >
            Undo
          </button>
        ),
      });
    } catch (error) {
      console.error("Error deleting voucher:", error);
      // Revert on error
      if (voucherToDelete) {
        setVouchers((prev) => [voucherToDelete, ...prev]);
      }
      toast({
        title: "Error",
        description: "Failed to delete voucher",
        variant: "destructive",
      });
    }
  };

  const handleUndo = async (voucher: UsedVoucher) => {
    setVouchers((prev) => [voucher, ...prev]);
    toast({
      title: "Restored",
      description: "Voucher restored to history",
    });
  };

  return (
    <div className="min-h-screen bg-white pb-24">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-white/80 backdrop-blur-lg border-b border-border/40 px-4 py-4">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate("/")}
            className="p-2 hover:bg-muted rounded-full transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div>
            <h1 className="text-xl font-bold">History</h1>
            <p className="text-sm text-muted-foreground">Used vouchers</p>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-3">
        {loading ? (
          <div className="text-center py-12 text-muted-foreground">
            Loading...
          </div>
        ) : vouchers.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            No used vouchers yet.
          </div>
        ) : (
          <AnimatePresence mode="popLayout">
            {vouchers.map((voucher) => (
              <HistoryCard
                key={voucher.voucher_id}
                voucher={voucher}
                onDelete={handleDelete}
              />
            ))}
          </AnimatePresence>
        )}
      </div>
    </div>
  );
}

interface HistoryCardProps {
  voucher: UsedVoucher;
  onDelete: (id: string) => void;
}

function HistoryCard({ voucher, onDelete }: HistoryCardProps) {
  const { prefs } = useCurrencyPrefs();

  // Use display_title if available, else compute from deal_type/value
  let dealHeadline = voucher.display_title || formatDealSummary(voucher.deal_type, voucher.value, voucher.currency, prefs);
  
  // Show actual amount saved if available (for any deal type)
  if (voucher.actual_amount_saved) {
    dealHeadline += ` (Saved ${voucher.currency} ${voucher.actual_amount_saved})`;
  } else if (voucher.deal_type === 'percentage' || (voucher.deal_type === 'other' && !voucher.value)) {
    // Only show "not recorded" for types that typically need manual input
    dealHeadline += ' (Amount not recorded)';
  }
  
  const conditionChips = getConditionChips(voucher.conditions);
  const usedDate = new Date(voucher.updated_at).toLocaleDateString("en-MY", {
    month: "short",
    day: "numeric",
  });

  return (
    <SwipeToActionRow onRemove={() => onDelete(voucher.voucher_id)}>
      <div className="glass border-gradient rounded-2xl p-3 relative bg-white">
        <div className="flex gap-3">
          {/* Logo */}
          <BrandAvatar 
            merchant={voucher.merchant}
            domain={voucher.merchant_domain}
          />

          {/* Content */}
          <div className="flex-1 min-w-0">
            <h3 className="font-bold text-sm truncate">{voucher.merchant}</h3>
            <p className="font-bold text-base gradient-text">{dealHeadline}</p>
            <p className="text-xs text-muted-foreground">Used {usedDate}</p>
            
            {voucher.location && (
              <p className="text-xs text-muted-foreground truncate mt-1">
                {voucher.location}
              </p>
            )}

            {conditionChips.length > 0 && (
              <div className="flex gap-1 mt-2 flex-wrap">
                {conditionChips.map((chip, idx) => (
                  <span
                    key={idx}
                    className="text-xs px-2 py-0.5 rounded-full bg-muted/50 text-muted-foreground"
                  >
                    {chip}
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </SwipeToActionRow>
  );
}
