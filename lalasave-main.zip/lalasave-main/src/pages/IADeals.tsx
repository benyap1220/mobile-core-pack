import { useState, useEffect, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import VoucherBorder from "@/components/VoucherBorder";
import { Skeleton } from "@/components/ui/skeleton";
import { ExternalLink } from "lucide-react";
import DealDetailModal from "@/components/DealDetailModal";

interface Deal {
  id: string;
  offer_id: number;
  deeplink_id: string;
  title: string;
  subtitle?: string;
  badge?: string;
  tags: string[];
  image_url?: string;
  platform?: string;
  score: number;
  border_id?: string;
}

interface NextCursor {
  score: number;
  date: string;
  id: string;
}

export default function IADeals() {
  const { toast } = useToast();
  const [deals, setDeals] = useState<Deal[]>([]);
  const [loading, setLoading] = useState(true);
  const [hasMore, setHasMore] = useState(true);
  const [nextCursor, setNextCursor] = useState<NextCursor | null>(null);
  const loadMoreRef = useRef<HTMLDivElement>(null);
  const observedDeals = useRef<Set<string>>(new Set());
  const [selectedPosition, setSelectedPosition] = useState(0);
  const [dealDetails, setDealDetails] = useState<any>(null);

  const fetchDeals = async (cursor?: NextCursor) => {
    setLoading(true);
    
    const params = new URLSearchParams({ limit: '24' });
    if (cursor) {
      params.append('cursor_score', String(cursor.score));
      params.append('cursor_date', cursor.date);
      params.append('cursor_id', cursor.id);
    }

    const { data, error } = await supabase.functions.invoke('deals-list', {
      body: {},
      method: 'GET',
    });

    if (error) {
      console.error('Error fetching deals:', error);
      setLoading(false);
      return;
    }

    const { items, next_cursor } = data;
    
    if (cursor) {
      setDeals(prev => [...prev, ...(items || [])]);
    } else {
      setDeals(items || []);
    }

    setNextCursor(next_cursor);
    setHasMore(!!next_cursor);
    setLoading(false);
  };

  useEffect(() => {
    fetchDeals();
  }, []);

  // Infinite scroll
  useEffect(() => {
    if (!loadMoreRef.current || !hasMore || loading) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !loading) {
          fetchDeals(nextCursor || undefined);
        }
      },
      { rootMargin: '800px' }
    );

    observer.observe(loadMoreRef.current);
    return () => observer.disconnect();
  }, [loadMoreRef.current, hasMore, loading, nextCursor]);

  // Impression tracking
  useEffect(() => {
    if (deals.length === 0) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(async (entry) => {
          if (entry.isIntersecting) {
            const dealId = entry.target.getAttribute('data-deal-id');
            if (dealId && !observedDeals.current.has(dealId)) {
              observedDeals.current.add(dealId);
              
              await supabase.from('aff_impressions').insert({ deal_id: dealId });
              observer.unobserve(entry.target);
            }
          }
        });
      },
      { threshold: 0.5 }
    );

    const cards = document.querySelectorAll('[data-deal-id]');
    cards.forEach(card => observer.observe(card));

    return () => observer.disconnect();
  }, [deals]);

  const handleClick = async (dealId: string, index: number) => {
    setSelectedPosition(index + 1);
    
    // Fetch deal details (public endpoint, no auth)
    try {
      const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/deal-details?id=${dealId}`;
      const response = await fetch(url);
      if (response.ok) {
        const data = await response.json();
        setDealDetails(data);
      } else {
        console.error('Failed to fetch deal details:', response.status);
        toast({
          title: "Error loading deal",
          description: "Please try again",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Failed to fetch deal details:', error);
      toast({
        title: "Error loading deal",
        description: "Please try again",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-2 sm:px-3 py-4">
        <div className="mb-6">
          <h1 className="text-3xl font-bold mb-2">Exclusive Deals</h1>
          <p className="text-muted-foreground">Curated offers from top merchants</p>
        </div>

        <div className="grid gap-2 sm:gap-3 grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
          {deals.map((deal, index) => (
            <Card
              key={deal.id}
              data-deal-id={deal.id}
              className="relative overflow-hidden rounded-2xl shadow-md cursor-pointer hover:shadow-lg transition-shadow"
              onClick={() => handleClick(deal.id, index)}
            >
              {deal.border_id && (
                <VoucherBorder
                  borderStyleId={deal.border_id}
                  target="deals"
                />
              )}

              <div className="p-3 space-y-2 relative z-10">
                {deal.image_url && (
                  <div className="flex justify-center mb-2">
                    <img
                      src={deal.image_url}
                      alt={deal.platform || deal.title}
                      className="h-12 w-12 object-contain rounded-lg"
                    />
                  </div>
                )}

                {deal.badge && (
                  <Badge variant="secondary" className="mb-1">
                    {deal.badge}
                  </Badge>
                )}

                <h3 className="font-semibold text-sm line-clamp-2">{deal.title}</h3>

                {deal.subtitle && (
                  <p className="text-xs text-muted-foreground line-clamp-1">
                    {deal.subtitle}
                  </p>
                )}

                {deal.tags && deal.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1">
                    {deal.tags.slice(0, 2).map((tag, i) => (
                      <span
                        key={i}
                        className="text-xs bg-muted px-2 py-0.5 rounded-full"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                )}

                <Button className="w-full" size="sm">
                  <ExternalLink className="w-3 h-3 mr-1" />
                  View Deal
                </Button>
              </div>
            </Card>
          ))}

          {loading &&
            Array.from({ length: 6 }).map((_, i) => (
              <Card key={`skeleton-${i}`} className="p-3 space-y-2">
                <Skeleton className="h-12 w-12 mx-auto rounded-lg" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-3 w-3/4" />
                <Skeleton className="h-8 w-full rounded-md" />
              </Card>
            ))}
        </div>

        <div ref={loadMoreRef} className="h-4 mt-4" />

        {!loading && deals.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            <p>No deals available yet</p>
          </div>
        )}
      </div>

      <DealDetailModal
        open={!!dealDetails}
        onOpenChange={(open) => !open && setDealDetails(null)}
        dealDetails={dealDetails}
        position={selectedPosition}
      />
    </div>
  );
}
