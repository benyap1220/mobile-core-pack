import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Bell, Mail, MessageSquare, Globe, DollarSign, Settings2, User, LogOut } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

import { CURRENCY_OPTIONS, LOCALE_OPTIONS } from "@/lib/currency";

const Settings = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [settings, setSettings] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [customCurrency, setCustomCurrency] = useState({ code: '', symbol: '' });

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      let { data, error } = await supabase
        .from("user_settings")
        .select("*")
        .eq("user_id", user.id)
        .maybeSingle();

      // If no settings exist, create default ones
      if (!data && !error) {
        const { data: newSettings, error: insertError } = await supabase
          .from("user_settings")
          .insert({ user_id: user.id })
          .select()
          .single();
        
        if (insertError) throw insertError;
        data = newSettings;
      }

      if (error) throw error;
      setSettings(data);
    } catch (error: any) {
      console.error("Settings error:", error);
    } finally {
      setLoading(false);
    }
  };

  const updateSetting = async (key: string, value: any) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { error } = await supabase
        .from("user_settings")
        .update({ [key]: value })
        .eq("user_id", user.id);

      if (error) throw error;

      setSettings({ ...settings, [key]: value });
      toast({
        title: "Settings updated",
        description: "Your preferences have been saved",
      });
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message,
      });
    }
  };

  const handleCurrencyChange = async (currencyCode: string) => {
    if (currencyCode === 'custom') {
      // User will input custom values
      return;
    }

    const currency = CURRENCY_OPTIONS.find(c => c.code === currencyCode);
    if (!currency) return;

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { error } = await supabase
        .from("user_settings")
        .update({
          preferred_currency: currency.code,
          currency_symbol: currency.symbol,
          locale: currency.locale,
        })
        .eq("user_id", user.id);

      if (error) throw error;

      setSettings({
        ...settings,
        preferred_currency: currency.code,
        currency_symbol: currency.symbol,
        locale: currency.locale,
      });

      toast({
        title: "Currency updated",
        description: `Now using ${currency.name}`,
      });
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message,
      });
    }
  };

  const handleCustomCurrencySave = async () => {
    if (!customCurrency.code || !customCurrency.symbol) {
      toast({
        variant: "destructive",
        title: "Invalid input",
        description: "Please enter both currency code and symbol",
      });
      return;
    }

    await updateSetting('preferred_currency', customCurrency.code);
    await updateSetting('currency_symbol', customCurrency.symbol);
    setCustomCurrency({ code: '', symbol: '' });
  };

  const handleSignOut = async () => {
    try {
      await supabase.auth.signOut();
      navigate("/auth");
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message,
      });
    }
  };

  if (loading || !settings) {
  return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Loading...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white pb-20">
      <motion.header
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="sticky top-0 z-50 glass-card border-b border-white/20 px-4 py-4"
      >
        <div className="max-w-7xl mx-auto flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(-1)}
            className="rounded-full"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-2xl font-bold gradient-text">Settings</h1>
        </div>
      </motion.header>

      <main className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        {/* Privacy Note */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card rounded-2xl p-4 bg-muted/30 border border-border/50"
        >
          <p className="text-xs text-muted-foreground">
            <strong>Privacy Note:</strong> Logos are shown for recognition in this prototype. Trademarks belong to their respective owners.
          </p>
        </motion.div>

        {/* Notifications */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
          className="glass-card rounded-2xl p-6 space-y-6"
        >
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Bell className="h-5 w-5 text-primary" />
            Notifications
          </h2>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-base">Push Notifications</Label>
                <p className="text-sm text-muted-foreground">
                  Receive browser notifications for expiring vouchers
                </p>
              </div>
              <Switch
                checked={settings.push_enabled}
                onCheckedChange={(checked) => updateSetting("push_enabled", checked)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-base flex items-center gap-2">
                  <Mail className="h-4 w-4" />
                  Email Digest
                </Label>
                <p className="text-sm text-muted-foreground">
                  Weekly summary of expiring deals
                </p>
              </div>
              <Switch
                checked={settings.email_enabled}
                onCheckedChange={(checked) => updateSetting("email_enabled", checked)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-base flex items-center gap-2">
                  <MessageSquare className="h-4 w-4" />
                  WhatsApp Reminders
                </Label>
                <p className="text-sm text-muted-foreground">
                  Coming soon - get reminders via WhatsApp
                </p>
              </div>
              <Switch
                checked={settings.whatsapp_enabled}
                onCheckedChange={(checked) => updateSetting("whatsapp_enabled", checked)}
                disabled
              />
            </div>
          </div>
        </motion.div>

        {/* Currency Settings */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="glass-card rounded-2xl p-6 space-y-6"
        >
          <h2 className="text-xl font-bold flex items-center gap-2">
            <DollarSign className="h-5 w-5 text-primary" />
            Currency Mode
          </h2>

          <div className="space-y-4">
            <div>
              <Label className="text-base mb-2">Preferred Currency</Label>
              <Select
                value={settings.preferred_currency}
                onValueChange={handleCurrencyChange}
              >
                <SelectTrigger className="bg-white/50">
                  <SelectValue placeholder="Select currency" />
                </SelectTrigger>
                <SelectContent className="bg-white z-50">
                  {CURRENCY_OPTIONS.map((curr) => (
                    <SelectItem key={curr.code} value={curr.code}>
                      {curr.code} - {curr.name} ({curr.symbol})
                    </SelectItem>
                  ))}
                  <SelectItem value="custom">Other (Custom)...</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-sm text-muted-foreground mt-1">
                Currently using: {settings.currency_symbol} ({settings.preferred_currency})
              </p>
            </div>

            {/* Custom Currency Input */}
            <div className="border-t pt-4 space-y-3">
              <Label className="text-sm font-semibold">Custom Currency (Optional)</Label>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">Currency Code</Label>
                  <Input
                    placeholder="e.g., EUR"
                    value={customCurrency.code}
                    onChange={(e) => setCustomCurrency({ ...customCurrency, code: e.target.value.toUpperCase() })}
                    className="bg-white/50"
                    maxLength={3}
                  />
                </div>
                <div>
                  <Label className="text-xs">Symbol</Label>
                  <Input
                    placeholder="e.g., €"
                    value={customCurrency.symbol}
                    onChange={(e) => setCustomCurrency({ ...customCurrency, symbol: e.target.value })}
                    className="bg-white/50"
                    maxLength={3}
                  />
                </div>
              </div>
              <Button
                onClick={handleCustomCurrencySave}
                disabled={!customCurrency.code || !customCurrency.symbol}
                variant="outline"
                size="sm"
                className="w-full"
              >
                Save Custom Currency
              </Button>
            </div>

            <div>
              <Label className="text-base mb-2">Symbol Position</Label>
              <Select
                value={settings.symbol_position}
                onValueChange={(value) => updateSetting('symbol_position', value)}
              >
                <SelectTrigger className="bg-white/50">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-white z-50">
                  <SelectItem value="prefix">Prefix ($ 100)</SelectItem>
                  <SelectItem value="suffix">Suffix (100 $)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-base mb-2">Locale (Number Format)</Label>
              <Select
                value={settings.locale}
                onValueChange={(value) => updateSetting('locale', value)}
              >
                <SelectTrigger className="bg-white/50">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-white z-50">
                  {LOCALE_OPTIONS.map((loc) => (
                    <SelectItem key={loc.value} value={loc.value}>
                      {loc.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </motion.div>

        {/* Preferences */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="glass-card rounded-2xl p-6 space-y-6"
        >
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Globe className="h-5 w-5 text-primary" />
            Privacy
          </h2>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-base">Use Third-Party Logo Lookups</Label>
                <p className="text-sm text-muted-foreground">
                  Allow logo lookups from Clearbit and favicon services
                </p>
              </div>
              <Switch
                checked={settings.logo_lookup_enabled}
                onCheckedChange={(checked) => updateSetting("logo_lookup_enabled", checked)}
              />
            </div>
            <div className="flex items-center justify-between opacity-50">
              <div className="space-y-0.5">
                <Label className="text-base">Currency Conversion</Label>
                <p className="text-sm text-muted-foreground">
                  Automatically convert amounts (Coming Soon)
                </p>
              </div>
              <Switch disabled checked={false} />
            </div>
          </div>
          
          <p className="text-xs text-muted-foreground border-t pt-4">
            <strong>Disclaimer:</strong> Logos are shown for recognition in this prototype. Trademarks belong to their respective owners.
          </p>
        </motion.div>

        {/* Admin Tools */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="glass-card rounded-2xl p-6 space-y-4"
        >
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Settings2 className="h-5 w-5 text-primary" />
            Admin Tools
          </h2>
          
          <div className="space-y-2">
            <Button
              variant="outline"
              className="w-full justify-start"
              onClick={() => navigate("/admin/merchants")}
            >
              <Globe className="h-4 w-4 mr-2" />
              Manage Merchant Logos
            </Button>
          </div>
        </motion.div>

        {/* Account */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="glass-card rounded-2xl p-6"
        >
          <h2 className="text-xl font-bold flex items-center gap-2 mb-4">
            <User className="h-5 w-5 text-primary" />
            Account
          </h2>
          <Button
            variant="outline"
            className="w-full justify-start text-destructive hover:text-destructive"
            onClick={handleSignOut}
          >
            <LogOut className="h-4 w-4 mr-2" />
            Sign Out
          </Button>
        </motion.div>

        {/* Email Sync */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="glass-card rounded-2xl p-6 space-y-4"
        >
          <h2 className="text-xl font-bold">Email Sync</h2>
          <p className="text-sm text-muted-foreground">
            Connect your Gmail account to automatically import vouchers from promotional emails
          </p>
          <Button
            variant="outline"
            disabled
            className="w-full"
          >
            Connect Gmail (Coming Soon)
          </Button>
        </motion.div>

        {/* Export Data */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="glass-card rounded-2xl p-6 space-y-4"
        >
          <h2 className="text-xl font-bold">Export Data</h2>
          <p className="text-sm text-muted-foreground">
            Download all your vouchers as a CSV file
          </p>
          <Button variant="outline" disabled className="w-full">
            Export CSV (Coming Soon)
          </Button>
        </motion.div>
      </main>
    </div>
  );
};

export default Settings;
