import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { RefreshCw, CheckCircle, XCircle } from "lucide-react";
import { canonicalBrandSlug } from "@/lib/slugifyMerchant";
import { getBrandOverride } from "@/lib/brandOverrides";

export default function AdminDebugLogos() {
  const [debugResult, setDebugResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const testBrands = [
    'Lazada',
    'Lazada Logistics', 
    'LEX',
    'Grab',
    'Shopee',
  ];

  async function testLogo(brandName: string) {
    setLoading(true);
    const slug = canonicalBrandSlug(brandName);
    const override = getBrandOverride(slug);
    
    try {
      const res = await fetch(
        "https://cnayuxiwjgpjrzkphhwz.supabase.co/functions/v1/resolve-logo",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "apikey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNuYXl1eGl3amdwanJ6a3BoaHd6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTk2NzM4MDYsImV4cCI6MjA3NTI0OTgwNn0.ZA_6hIEYMQCDRGvyvmc3x-xTFg_MOhgKiZvmZ9TBWJI"
          },
          body: JSON.stringify({ slug, debug: true }),
        }
      );
      
      const data = await res.json();
      
      setDebugResult({
        input: brandName,
        slug,
        hasHardOverride: !!override,
        overrideUrl: override?.url,
        apiResponse: data,
        passed: data.source === 'override-static' && data.url?.includes('lazada-official')
      });
    } catch (err) {
      setDebugResult({
        input: brandName,
        slug,
        error: String(err)
      });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <h1 className="text-3xl font-bold mb-6">Logo System Debug</h1>
      
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Test Brand Resolution</CardTitle>
          <CardDescription>
            Click any brand to test the logo resolution pipeline
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {testBrands.map(brand => (
            <Button
              key={brand}
              variant="outline"
              className="w-full justify-start"
              onClick={() => testLogo(brand)}
              disabled={loading}
            >
              {loading ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : null}
              Test: {brand}
            </Button>
          ))}
        </CardContent>
      </Card>

      {debugResult && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {debugResult.passed ? (
                <CheckCircle className="h-5 w-5 text-green-500" />
              ) : (
                <XCircle className="h-5 w-5 text-red-500" />
              )}
              Debug Result
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 font-mono text-sm">
              <div>
                <strong>Input:</strong> {debugResult.input}
              </div>
              <div>
                <strong>Canonical Slug:</strong> {debugResult.slug}
              </div>
              <div>
                <strong>Hard Override:</strong> {debugResult.hasHardOverride ? 'YES ✓' : 'NO'}
              </div>
              {debugResult.overrideUrl && (
                <div>
                  <strong>Override URL:</strong> {debugResult.overrideUrl}
                </div>
              )}
              {debugResult.apiResponse && (
                <>
                  <div>
                    <strong>API Source:</strong> {debugResult.apiResponse.source}
                  </div>
                  <div>
                    <strong>API URL:</strong> 
                    <div className="break-all text-xs mt-1">
                      {debugResult.apiResponse.url || debugResult.apiResponse.publicUrl}
                    </div>
                  </div>
                </>
              )}
              {debugResult.error && (
                <div className="text-red-500">
                  <strong>Error:</strong> {debugResult.error}
                </div>
              )}
              
              {debugResult.apiResponse?.url && (
                <div className="mt-4 pt-4 border-t">
                  <strong>Logo Preview:</strong>
                  <img 
                    src={debugResult.apiResponse.url} 
                    alt="Logo preview"
                    className="mt-2 w-24 h-24 object-contain border rounded p-2"
                  />
                </div>
              )}
            </div>
            
            <div className="mt-4 p-3 bg-muted rounded text-xs">
              <strong>Acceptance Criteria:</strong>
              <ul className="list-disc list-inside mt-2 space-y-1">
                <li className={debugResult.apiResponse?.source === 'override-static' ? 'text-green-600' : 'text-red-600'}>
                  Source must be "override-static" {debugResult.apiResponse?.source === 'override-static' ? '✓' : '✗'}
                </li>
                <li className={debugResult.apiResponse?.url?.includes('lazada-official') ? 'text-green-600' : 'text-red-600'}>
                  URL must contain "lazada-official" {debugResult.apiResponse?.url?.includes('lazada-official') ? '✓' : '✗'}
                </li>
                <li className={!debugResult.apiResponse?.url?.toLowerCase().includes('logistics') ? 'text-green-600' : 'text-red-600'}>
                  Must NOT contain "logistics" {!debugResult.apiResponse?.url?.toLowerCase().includes('logistics') ? '✓' : '✗'}
                </li>
              </ul>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
