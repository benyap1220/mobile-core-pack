import { useEffect, useState, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { supabase } from "@/integrations/supabase/client";
import { voucherUpdateSchema, customTagSchema } from "@/lib/validation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ArrowLeft, Save, Trash2, CheckCircle, X, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import GradientButton from "@/components/GradientButton";
import BrandAvatar from "@/components/BrandAvatar";
import { capitalizeTag, formatConditionsText } from "@/lib/deals";
import { useCurrencyPrefs } from "@/hooks/useCurrencyPrefs";
import { useLogoResolver } from "@/hooks/useLogoResolver";
import { toLogoSource } from "@/lib/logoTypes";
import { MarkUsedDialog } from "@/components/MarkUsedDialog";

const VoucherDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [voucher, setVoucher] = useState<any>(null);
  const [assets, setAssets] = useState<any[]>([]);
  const [customTagInput, setCustomTagInput] = useState("");
  const { prefs } = useCurrencyPrefs();
  const { resolveLogo } = useLogoResolver();
  const logoResolveTimerRef = useRef<NodeJS.Timeout | null>(null);
  const previousMerchantRef = useRef<string>("");
  const [markUsedDialogOpen, setMarkUsedDialogOpen] = useState(false);

  useEffect(() => {
    if (id) {
      fetchVoucher();
      fetchAssets();
    }
  }, [id]);

  // Auto-resolve logo when merchant name changes
  useEffect(() => {
    if (!voucher?.merchant || !voucher?.voucher_id) return;
    
    // Skip if merchant hasn't actually changed
    if (previousMerchantRef.current === voucher.merchant) return;
    
    // Skip if logo already exists and merchant just loaded
    if (!previousMerchantRef.current && voucher.merchant_logo_path) {
      previousMerchantRef.current = voucher.merchant;
      return;
    }
    
    // Clear existing timer
    if (logoResolveTimerRef.current) {
      clearTimeout(logoResolveTimerRef.current);
    }
    
    // Set new timer for debounced logo resolution
    logoResolveTimerRef.current = setTimeout(async () => {
      previousMerchantRef.current = voucher.merchant;
      
      // Get first asset path if available
      const voucherImagePath = assets.length > 0 ? assets[0].file_path : undefined;
      
      const result = await resolveLogo(
        voucher.voucher_id, 
        voucher.merchant, 
        voucher.merchant_domain,
        voucherImagePath
      );
      
      if (result?.logoPath) {
        setVoucher((prev: any) => ({ 
          ...prev, 
          merchant_logo_path: result.logoPath,
          logo_source: result.source 
        }));
      }
    }, 1000); // 1 second debounce
    
    return () => {
      if (logoResolveTimerRef.current) {
        clearTimeout(logoResolveTimerRef.current);
      }
    };
  }, [voucher?.merchant, voucher?.voucher_id, assets]);

  const fetchVoucher = async () => {
    try {
      const { data, error } = await supabase
        .from("vouchers")
        .select("*")
        .eq("voucher_id", id)
        .single();

      if (error) throw error;
      
      // Set default currency to user's preferred currency if not set
      if (data && !data.currency) {
        data.currency = prefs.code;
      }
      
      setVoucher(data);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchAssets = async () => {
    try {
      const { data, error } = await supabase
        .from("voucher_assets")
        .select("*")
        .eq("voucher_id", id);

      if (error) throw error;

      // Get signed URLs for private assets
      const assetsWithUrls = await Promise.all(
        (data || []).map(async (asset) => {
          const { data: signedUrl } = await supabase.storage
            .from("voucher-images")
            .createSignedUrl(asset.file_path, 3600);
          return { ...asset, signedUrl: signedUrl?.signedUrl || asset.file_url };
        })
      );

      setAssets(assetsWithUrls);
    } catch (error: any) {
      console.error("Error fetching assets:", error);
    }
  };

  const SUGGESTED_TAGS = [
    "Gift Certificate",
    "Beverage", 
    "Food",
    "Merchandise",
    "Entertainment",
    "Travel",
    "Shopping",
    "Dining"
  ];

  const addCustomTag = () => {
    const trimmed = customTagInput.trim();
    if (!trimmed) return;
    
    // Validate tag
    const validation = customTagSchema.safeParse(trimmed);
    if (!validation.success) {
      toast({
        variant: "destructive",
        title: "Invalid tag",
        description: validation.error.errors[0].message,
      });
      return;
    }
    
    const normalized = trimmed.toLowerCase();
    const currentTags = voucher.tags || [];
    const currentNormalized = currentTags.map((t: string) => t.toLowerCase());
    
    if (currentNormalized.includes(normalized)) {
      toast({
        variant: "destructive",
        title: "Duplicate tag",
        description: "This tag already exists",
      });
      return;
    }
    
    // Store with proper capitalization
    const capitalized = capitalizeTag(trimmed);
    
    setVoucher({
      ...voucher,
      tags: [...currentTags, capitalized]
    });
    setCustomTagInput("");
  };

  const removeTag = (tagToRemove: string) => {
    setVoucher({
      ...voucher,
      tags: (voucher.tags || []).filter((t: string) => t !== tagToRemove)
    });
  };

  const handleSave = async () => {
    if (!voucher) return;

    setSaving(true);
    try {
      // Validate voucher data
      const updateData = {
        merchant: voucher.merchant,
        merchant_domain: voucher.merchant_domain,
        merchant_logo_path: voucher.merchant_logo_path || null,
        logo_source: toLogoSource(voucher.logo_source),
        deal_type: voucher.deal_type,
        value: voucher.value,
        currency: voucher.currency,
        category: voucher.category,
        expiry_date: voucher.expiry_date,
        valid_from: voucher.valid_from,
        conditions: voucher.conditions,
        personal_notes: voucher.personal_notes,
        tags: voucher.tags || [],
      };

      const validation = voucherUpdateSchema.safeParse(updateData);
      if (!validation.success) {
        toast({
          variant: "destructive",
          title: "Validation Error",
          description: validation.error.errors[0].message,
        });
        setSaving(false);
        return;
      }

      const { error } = await supabase
        .from("vouchers")
        .update(validation.data)
        .eq("voucher_id", id);

      if (error) throw error;

      toast({
        title: "Saved",
        description: "Voucher updated successfully",
      });
      
      // Auto-navigate back to Dashboard
      navigate("/");
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message,
      });
    } finally {
      setSaving(false);
    }
  };

  const handleMarkUsed = () => {
    setMarkUsedDialogOpen(true);
  };

  const handleMarkUsedConfirm = () => {
    setMarkUsedDialogOpen(false);
    toast({
      title: "Marked as used",
      description: "Voucher status updated",
    });
    navigate("/");
  };

  const handleDelete = async () => {
    if (!confirm("Are you sure you want to delete this voucher?")) return;

    try {
      const { error } = await supabase
        .from("vouchers")
        .delete()
        .eq("voucher_id", id);

      if (error) throw error;

      toast({
        title: "Deleted",
        description: "Voucher removed successfully",
      });

      navigate("/");
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message,
      });
    }
  };

  if (loading || !voucher) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Loading...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-20">
      <motion.header
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="sticky top-0 z-50 glass-card border-b border-white/20 px-4 py-4"
      >
        <div className="max-w-7xl mx-auto flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(-1)}
            className="rounded-full"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-2xl font-bold gradient-text">Voucher Details</h1>
        </div>
      </motion.header>

      <main className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Images */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-4"
          >
            {assets.map((asset, index) => (
              <div key={asset.asset_id} className="glass-card rounded-2xl overflow-hidden">
                <img
                  src={asset.signedUrl}
                  alt={`Voucher ${index + 1}`}
                  className="w-full object-contain bg-black/5"
                />
              </div>
            ))}
            {assets.length === 0 && (
              <div className="glass-card rounded-2xl p-12 text-center">
                <p className="text-muted-foreground">No images available</p>
              </div>
            )}
          </motion.div>

          {/* Form */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="glass-card rounded-2xl p-6 space-y-4"
          >
            {/* Display current tags */}
            {voucher.tags && voucher.tags.length > 0 && (
              <div className="flex flex-wrap gap-2 pb-4 border-b border-border/40">
                {voucher.tags.map((tag: string, i: number) => (
                  <Badge key={i} variant="secondary">
                    {capitalizeTag(tag)}
                  </Badge>
                ))}
              </div>
            )}

            <div className="grid grid-cols-[auto_1fr] gap-4 items-center">
              <BrandAvatar 
                merchant={voucher.merchant} 
                domain={voucher.merchant_domain}
                size="md" 
              />
              <div className="space-y-2">
                <Label>Merchant</Label>
                <Input
                  value={voucher.merchant}
                  onChange={(e) => setVoucher({ ...voucher, merchant: e.target.value })}
                  className="bg-white/50"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Deal Type</Label>
                <Select
                  value={voucher.deal_type || "amount"}
                  onValueChange={(value) => setVoucher({ ...voucher, deal_type: value })}
                >
                  <SelectTrigger className="bg-white/50">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="percentage">Percentage</SelectItem>
                    <SelectItem value="amount">Fixed Amount</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Value</Label>
                <Input
                  type="number"
                  value={voucher.value || ""}
                  onChange={(e) => setVoucher({ ...voucher, value: parseFloat(e.target.value) })}
                  className="bg-white/50"
                  placeholder={voucher.deal_type === "percentage" ? "e.g., 10 for 10%" : "e.g., 5"}
                />
                <p className="text-xs text-muted-foreground">
                  {voucher.deal_type === "percentage" ? "Enter percentage (e.g., 10 for 10%)" : "Enter fixed amount"}
                </p>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Currency</Label>
              <Input
                value={voucher.currency}
                onChange={(e) => setVoucher({ ...voucher, currency: e.target.value })}
                className="bg-white/50"
                placeholder={prefs.code}
              />
              <p className="text-xs text-muted-foreground">
                Default: {prefs.symbol} ({prefs.code})
              </p>
            </div>

            <div className="space-y-2">
              <Label>Tags</Label>
              
              {/* Suggested tags (now clickable) */}
              <div className="mb-2">
                <p className="text-xs text-muted-foreground mb-2">Suggested:</p>
                <div className="flex flex-wrap gap-2">
                  {SUGGESTED_TAGS.map((tag) => {
                    const currentTags = voucher.tags || [];
                    const isSelected = currentTags
                      .map((t: string) => t.toLowerCase())
                      .includes(tag.toLowerCase());
                    return (
                      <Badge
                        key={tag}
                        variant={isSelected ? "default" : "outline"}
                        className={`cursor-pointer transition-all ${
                          isSelected 
                            ? "bg-primary/10 text-primary border-primary/30" 
                            : "hover:border-primary/50 opacity-60 hover:opacity-100"
                        }`}
                        onClick={() => {
                          if (isSelected) {
                            // Allow deselection - remove the tag
                            setVoucher({
                              ...voucher,
                              tags: currentTags.filter((t: string) => t.toLowerCase() !== tag.toLowerCase())
                            });
                          } else {
                            // Add the tag
                            setVoucher({
                              ...voucher,
                              tags: [...currentTags, tag]
                            });
                          }
                        }}
                      >
                        {tag}
                      </Badge>
                    );
                  })}
                </div>
              </div>
              
              <div className="flex gap-2">
                <Input
                  value={customTagInput}
                  onChange={(e) => setCustomTagInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addCustomTag())}
                  placeholder="Add custom tag…"
                  className="bg-white/50"
                />
                <Button
                  type="button"
                  size="icon"
                  variant="outline"
                  onClick={addCustomTag}
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Valid From</Label>
                <Input
                  type="date"
                  value={voucher.valid_from || ""}
                  onChange={(e) => setVoucher({ ...voucher, valid_from: e.target.value })}
                  className="bg-white/50"
                />
              </div>

              <div className="space-y-2">
                <Label>Expiry Date</Label>
                <Input
                  type="date"
                  value={voucher.expiry_date || ""}
                  onChange={(e) => setVoucher({ ...voucher, expiry_date: e.target.value })}
                  className="bg-white/50"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Conditions</Label>
              <Textarea
                value={voucher.conditions || ""}
                onChange={(e) => setVoucher({ ...voucher, conditions: e.target.value })}
                className="bg-white/50 min-h-[100px]"
                placeholder="This certificate is valid for any beverage, food, or merchandise."
              />
            </div>

            <div className="space-y-2">
              <Label>Personal Notes</Label>
              <Textarea
                value={voucher.personal_notes || ""}
                onChange={(e) => {
                  let value = e.target.value;
                  // Split by lines and ensure each non-empty line starts with bullet
                  const lines = value.split('\n');
                  const formattedLines = lines.map((line, index) => {
                    const trimmed = line.trim();
                    // Don't add bullet if line is empty or already has bullet
                    if (!trimmed) return '';
                    if (trimmed.startsWith('•')) return line;
                    return '• ' + trimmed;
                  });
                  setVoucher({ ...voucher, personal_notes: formattedLines.join('\n') });
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    const currentValue = voucher.personal_notes || '';
                    // Add new line with bullet
                    setVoucher({ 
                      ...voucher, 
                      personal_notes: currentValue + '\n• ' 
                    });
                  }
                }}
                className="bg-white/50 min-h-[100px]"
                placeholder="• Add your personal notes here..."
              />
            </div>

            <div className="grid grid-cols-2 gap-3 pt-4">
              <GradientButton
                onClick={handleSave}
                disabled={saving}
              >
                <Save className="mr-2 h-4 w-4 inline" />
                Save
              </GradientButton>
              <Button
                onClick={handleMarkUsed}
                variant="outline"
              >
                <CheckCircle className="mr-2 h-4 w-4" />
                Mark Used
              </Button>
            </div>

            <Button
              onClick={handleDelete}
              variant="destructive"
              className="w-full"
            >
              <Trash2 className="mr-2 h-4 w-4" />
              Delete Voucher
            </Button>
          </motion.div>
        </div>
      </main>

      {/* Mark Used Dialog */}
      <MarkUsedDialog
        voucher={voucher}
        isOpen={markUsedDialogOpen}
        onClose={() => setMarkUsedDialogOpen(false)}
        onSuccess={handleMarkUsedConfirm}
      />
    </div>
  );
};

export default VoucherDetail;
