import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, CheckCircle2 } from "lucide-react";
import BrandAvatar from "@/components/BrandAvatar";

export default function SeedLogos() {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [completed, setCompleted] = useState(false);
  const [resultUrl, setResultUrl] = useState<string | null>(null);

  // Auto-seed Lazada on mount if not already done
  useEffect(() => {
    const hasSeeded = sessionStorage.getItem('lazada_seeded');
    if (!hasSeeded && !loading && !completed) {
      seedLazada();
    }
  }, []);

  async function seedLazada() {
    setLoading(true);
    try {
      const response = await fetch(
        "https://cnayuxiwjgpjrzkphhwz.supabase.co/functions/v1/seed-lazada-logo",
        {
          method: "POST",
          headers: {
            "apikey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNuYXl1eGl3amdwanJ6a3BoaHd6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTk2NzM4MDYsImV4cCI6MjA3NTI0OTgwNn0.ZA_6hIEYMQCDRGvyvmc3x-xTFg_MOhgKiZvmZ9TBWJI",
          },
        }
      );

      const data = await response.json();

      if (data.success) {
        setResultUrl(data.publicUrl);
        setCompleted(true);
        sessionStorage.setItem('lazada_seeded', 'true');
        
        toast({
          title: "Success!",
          description: "Lazada logo uploaded from Simple Icons",
        });
      } else {
        throw new Error(data.error || "Failed to seed logo");
      }
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-sky-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 p-6">
      <div className="max-w-2xl mx-auto">
        <div className="flex items-center gap-4 mb-6">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("/affiliates")}
            className="rounded-full"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-2xl font-bold">Curated Logo Setup</h1>
        </div>

        <div className="glass rounded-2xl p-6 space-y-4">
          <div className="flex items-start gap-3">
            {completed ? (
              <CheckCircle2 className="h-5 w-5 text-green-600 mt-0.5" />
            ) : (
              <div className="h-5 w-5 border-2 border-primary rounded-full border-t-transparent animate-spin mt-0.5" />
            )}
            <div className="flex-1">
              <h2 className="font-semibold mb-2">Lazada Logo</h2>
              <p className="text-sm text-muted-foreground mb-3">
                {loading ? "Fetching official logo from Simple Icons..." : 
                 completed ? "Successfully uploaded curated Lazada logo" :
                 "Waiting to seed..."}
              </p>
              
              {completed && resultUrl && (
                <div className="mt-4 p-3 bg-muted/50 rounded-lg">
                  <p className="text-xs text-muted-foreground mb-2">Curated Logo:</p>
                  <BrandAvatar merchant="Lazada" size="lg" />
                  <p className="text-xs text-muted-foreground mt-2 truncate">{resultUrl}</p>
                </div>
              )}
            </div>
          </div>

          {!loading && !completed && (
            <Button onClick={seedLazada} className="w-full">
              Retry Seed
            </Button>
          )}

          {completed && (
            <Button onClick={() => navigate("/affiliates")} className="w-full">
              View Affiliates Page
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
