import { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Camera, Upload, Monitor, Video, ArrowLeft, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import GradientButton from "@/components/GradientButton";


const AddVoucher = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (file: File) => {
    setSelectedFile(file);
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
  };

  const handleExtraction = async () => {
    if (!selectedFile) {
      toast({
        variant: "destructive",
        title: "No file selected",
        description: "Please select an image first",
      });
      return;
    }

    setIsProcessing(true);

    try {
      // Get current user
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      // Create voucher record
      const { data: voucher, error: voucherError } = await supabase
        .from("vouchers")
        .insert({
          user_id: user.id,
          merchant: "Processing...",
          source: selectedFile.type.includes("video") ? "video" : "upload",
        })
        .select()
        .single();

      if (voucherError) throw voucherError;

      // Upload file to storage
      const filePath = `${user.id}/${voucher.voucher_id}/${selectedFile.name}`;
      const { error: uploadError } = await supabase.storage
        .from("voucher-images")
        .upload(filePath, selectedFile);

      if (uploadError) throw uploadError;

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from("voucher-images")
        .getPublicUrl(filePath);

      // Save asset reference
      await supabase.from("voucher_assets").insert({
        voucher_id: voucher.voucher_id,
        file_url: publicUrl,
        file_path: filePath,
        file_type: selectedFile.type,
      });

      // Call OCR extraction function
      const { data: extractData, error: extractError } = await supabase.functions.invoke(
        "extract-voucher",
        {
          body: { voucherId: voucher.voucher_id },
        }
      );

      if (extractError) {
        console.error("Extraction error:", extractError);
        toast({
          title: "Extraction started",
          description: "Processing your voucher in the background",
        });
      }

      // Trigger logo autofill in background (don't wait)
      supabase.functions.invoke("logo-autofill", {
        body: {
          voucherId: voucher.voucher_id,
          merchant: "Processing...",
          voucherImagePath: filePath,
        },
      }).catch(err => console.log("Logo autofill queued:", err));

      toast({
        title: "Success!",
        description: "Voucher added successfully",
      });

      navigate(`/voucher/${voucher.voucher_id}`);
    } catch (error: any) {
      console.error("Error:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message,
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen pb-20">
      {/* Header */}
      <motion.header
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="sticky top-0 z-50 glass-card border-b border-white/20 px-4 py-4"
      >
        <div className="max-w-7xl mx-auto flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(-1)}
            className="rounded-full"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-2xl font-bold gradient-text">Add Voucher</h1>
        </div>
      </motion.header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-6">
        <Tabs defaultValue="upload" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 glass-card p-1">
            <TabsTrigger value="upload">
              <Upload className="w-4 h-4 mr-2" />
              Upload
            </TabsTrigger>
            <TabsTrigger value="camera">
              <Camera className="w-4 h-4 mr-2" />
              Camera
            </TabsTrigger>
            <TabsTrigger value="screen">
              <Monitor className="w-4 h-4 mr-2" />
              Screen
            </TabsTrigger>
            <TabsTrigger value="video">
              <Video className="w-4 h-4 mr-2" />
              Video
            </TabsTrigger>
          </TabsList>

          {/* Upload Tab */}
          <TabsContent value="upload">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="glass-card rounded-2xl p-8"
            >
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*,.pdf"
                onChange={(e) => e.target.files?.[0] && handleFileSelect(e.target.files[0])}
                className="hidden"
              />
              
              {!previewUrl ? (
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-primary/30 rounded-xl p-12 text-center cursor-pointer hover:border-primary/60 transition-colors"
                >
                  <Upload className="w-16 h-16 mx-auto mb-4 text-primary" />
                  <p className="text-lg font-semibold mb-2">Upload Voucher Image</p>
                  <p className="text-sm text-muted-foreground">
                    Click to select an image or PDF
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  <img
                    src={previewUrl}
                    alt="Preview"
                    className="w-full rounded-xl max-h-96 object-contain bg-black/5"
                  />
                  <div className="flex gap-3">
                    <GradientButton
                      onClick={handleExtraction}
                      disabled={isProcessing}
                      className="flex-1"
                    >
                      {isProcessing ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin inline" />
                          Processing...
                        </>
                      ) : (
                        "Extract Voucher Data"
                      )}
                    </GradientButton>
                    <Button
                      variant="outline"
                      onClick={() => {
                        setSelectedFile(null);
                        setPreviewUrl(null);
                      }}
                    >
                      Clear
                    </Button>
                  </div>
                </div>
              )}
            </motion.div>
          </TabsContent>

          {/* Camera Tab */}
          <TabsContent value="camera">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="glass-card rounded-2xl p-8"
            >
              <input
                ref={cameraInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                onChange={(e) => e.target.files?.[0] && handleFileSelect(e.target.files[0])}
                className="hidden"
              />
              
              {!previewUrl ? (
                <div
                  onClick={() => cameraInputRef.current?.click()}
                  className="border-2 border-dashed border-primary/30 rounded-xl p-12 text-center cursor-pointer hover:border-primary/60 transition-colors"
                >
                  <Camera className="w-16 h-16 mx-auto mb-4 text-primary" />
                  <p className="text-lg font-semibold mb-2">Capture with Camera</p>
                  <p className="text-sm text-muted-foreground">
                    Take a photo of your voucher
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  <img
                    src={previewUrl}
                    alt="Preview"
                    className="w-full rounded-xl max-h-96 object-contain bg-black/5"
                  />
                  <div className="flex gap-3">
                    <GradientButton
                      onClick={handleExtraction}
                      disabled={isProcessing}
                      className="flex-1"
                    >
                      {isProcessing ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin inline" />
                          Processing...
                        </>
                      ) : (
                        "Extract Voucher Data"
                      )}
                    </GradientButton>
                    <Button
                      variant="outline"
                      onClick={() => {
                        setSelectedFile(null);
                        setPreviewUrl(null);
                      }}
                    >
                      Retake
                    </Button>
                  </div>
                </div>
              )}
            </motion.div>
          </TabsContent>

          {/* Screen/Video tabs - simplified for MVP */}
          <TabsContent value="screen">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="glass-card rounded-2xl p-8 text-center"
            >
              <Monitor className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
              <p className="text-lg font-semibold mb-2">Screenshot Upload</p>
              <p className="text-sm text-muted-foreground mb-4">
                Use the Upload tab to select a screenshot
              </p>
            </motion.div>
          </TabsContent>

          <TabsContent value="video">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="glass-card rounded-2xl p-8 text-center"
            >
              <Video className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
              <p className="text-lg font-semibold mb-2">Video Frame Extraction</p>
              <p className="text-sm text-muted-foreground mb-4">
                Coming soon - extract frames from voucher videos
              </p>
            </motion.div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default AddVoucher;
