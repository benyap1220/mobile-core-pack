import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ChevronLeft, ChevronRight, Filter } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import VoucherListItem from "@/components/VoucherListItem";
import OfferSheet from "@/components/OfferSheet";
import FiltersSheet, { FilterState } from "@/components/FiltersSheet";
import { MarkUsedDialog } from "@/components/MarkUsedDialog";

const CalendarView = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [vouchers, setVouchers] = useState<any[]>([]);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [isFiltersOpen, setIsFiltersOpen] = useState(false);
  const [filters, setFilters] = useState<FilterState>({
    status: [],
    categories: [],
    merchant: "",
    daysLeft: [0, 30],
  });
  const [markUsedDialogOpen, setMarkUsedDialogOpen] = useState(false);
  const [voucherToMark, setVoucherToMark] = useState<any>(null);
  const [selectedVoucher, setSelectedVoucher] = useState<any>(null);
  const [isOfferSheetOpen, setIsOfferSheetOpen] = useState(false);

  useEffect(() => {
    fetchVouchers();
  }, []);

  const fetchVouchers = async () => {
    try {
      const { data, error } = await supabase
        .from("vouchers")
        .select(`
          voucher_id,
          merchant,
          merchant_logo_path,
          merchant_domain,
          location,
          deal_type,
          value,
          currency,
          expiry_date,
          conditions,
          personal_notes,
          tags,
          status,
          category,
          display_title,
          source_offer_id,
          affiliate_offers:source_offer_id(deep_link)
        `)
        .not("expiry_date", "is", null)
        .eq("status", "active");

      if (error) throw error;
      
      // Compute online_url from available sources
      const vouchersWithUrl = (data || []).map((v: any) => ({
        ...v,
        online_url: v.affiliate_offers?.deep_link || null,
      }));
      
      setVouchers(vouchersWithUrl);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message,
      });
    }
  };

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    return { daysInMonth, startingDayOfWeek, year, month };
  };

  const getExpiryStatus = (expiryDate: string | null) => {
    if (!expiryDate) return { days: null };
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const expiry = new Date(expiryDate);
    expiry.setHours(0, 0, 0, 0);
    const diffTime = expiry.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return { days: diffDays };
  };

  const applyFilters = (vouchers: any[]) => {
    return vouchers.filter((v) => {
      // Status filter
      if (filters.status.length > 0) {
        const status = getExpiryStatus(v.expiry_date);
        const isExpiring = status.days !== null && status.days >= 0 && status.days <= 7;
        const isExpired = status.days !== null && status.days < 0;
        
        const matchesStatus = filters.status.some((s) => {
          if (s === "active") return v.status === "active" && !isExpiring && !isExpired;
          if (s === "expiring") return isExpiring && v.status === "active";
          if (s === "expired") return isExpired || v.status === "expired";
          if (s === "used") return v.status === "used";
          return false;
        });
        
        if (!matchesStatus) return false;
      }

      // Category filter
      if (filters.categories.length > 0 && !filters.categories.includes(v.category)) {
        return false;
      }

      // Merchant filter
      if (filters.merchant && !v.merchant.toLowerCase().includes(filters.merchant.toLowerCase())) {
        return false;
      }

      // Days left filter
      const status = getExpiryStatus(v.expiry_date);
      if (status.days !== null) {
        if (status.days < filters.daysLeft[0] || status.days > filters.daysLeft[1]) {
          return false;
        }
      }

      return true;
    });
  };

  const getVouchersForDate = (date: Date) => {
    const dateStr = date.toISOString().split("T")[0];
    const dateVouchers = vouchers.filter((v) => v.expiry_date === dateStr);
    return applyFilters(dateVouchers);
  };

  const { daysInMonth, startingDayOfWeek, year, month } = getDaysInMonth(currentDate);

  const days = [];
  for (let i = 0; i < startingDayOfWeek; i++) {
    days.push(null);
  }
  for (let day = 1; day <= daysInMonth; day++) {
    days.push(day);
  }

  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  const selectedVouchers = selectedDate ? getVouchersForDate(selectedDate) : [];

  const activeFiltersCount = 
    filters.status.length +
    filters.categories.length +
    (filters.merchant ? 1 : 0) +
    (filters.daysLeft[0] !== 0 || filters.daysLeft[1] !== 30 ? 1 : 0);

  const handleMarkUsed = (voucherId: string) => {
    const voucher = vouchers.find((v) => v.voucher_id === voucherId);
    if (!voucher) return;
    
    setVoucherToMark(voucher);
    setMarkUsedDialogOpen(true);
  };

  const handleMarkUsedConfirm = () => {
    setMarkUsedDialogOpen(false);
    toast({
      title: "Success",
      description: "Voucher marked as used",
    });
    fetchVouchers();
  };

  return (
    <div className="min-h-screen bg-white pb-20">
      <motion.header
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="sticky top-0 z-50 glass border-b border-white/20 px-4 py-4"
      >
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate(-1)}
              className="rounded-full"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-2xl font-bold gradient-text">Calendar</h1>
          </div>
          <Button
            variant="outline"
            onClick={() => setIsFiltersOpen(true)}
            className="gap-2"
          >
            <Filter className="h-4 w-4" />
            Filters
            {activeFiltersCount > 0 && (
              <span className="ml-1 text-xs bg-primary text-primary-foreground rounded-full px-2 py-0.5">
                {activeFiltersCount}
              </span>
            )}
          </Button>
        </div>
      </motion.header>

      <main className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        {/* Month Navigation */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass border-gradient rounded-3xl p-6 relative overflow-hidden"
        >
          {/* Blue radial overlay */}
          <div className="absolute inset-0 pointer-events-none opacity-20">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[200px] blue-gradient rounded-full blur-3xl" />
          </div>

          <div className="relative flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold gradient-text">
              {monthNames[month]} {year}
            </h2>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="icon"
                onClick={() => setCurrentDate(new Date(year, month - 1, 1))}
                className="rounded-full"
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                onClick={() => setCurrentDate(new Date(year, month + 1, 1))}
                className="rounded-full"
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Calendar Grid */}
          <div className="grid grid-cols-7 gap-2">
            {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
              <div key={day} className="text-center font-semibold text-sm text-muted-foreground py-2">
                {day}
              </div>
            ))}

            {days.map((day, index) => {
              if (day === null) {
                return <div key={`empty-${index}`} />;
              }

              const date = new Date(year, month, day);
              const vouchersOnDay = getVouchersForDate(date);
              const isSelected = selectedDate?.toDateString() === date.toDateString();
              const isToday = new Date().toDateString() === date.toDateString();

              return (
                <motion.button
                  key={day}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ 
                    delay: index * 0.01,
                    type: "spring",
                    damping: 20,
                    stiffness: 300
                  }}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setSelectedDate(date)}
                  className={`
                    aspect-square rounded-xl p-2 text-sm relative
                    ${isSelected ? "blue-gradient text-white shadow-lg" : "bg-white/50 hover:bg-white/80"}
                    ${isToday && !isSelected ? "border-2 border-gradient" : ""}
                    transition-all
                  `}
                >
                  <div className="font-semibold">{day}</div>
                  {vouchersOnDay.length > 0 && (
                    <div className={`absolute bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full ${isSelected ? "bg-white" : "bg-primary"}`} />
                  )}
                </motion.button>
              );
            })}
          </div>
        </motion.div>

        {/* Selected Date Vouchers */}
        {selectedDate && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            <h3 className="text-lg font-semibold">
              Expiring on {selectedDate.toLocaleDateString("en-US", {
                month: "long",
                day: "numeric",
                year: "numeric",
              })}
            </h3>
            
            {selectedVouchers.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">
                No vouchers expiring on this date
              </p>
            ) : (
              selectedVouchers.map((voucher, index) => (
                <motion.div
                  key={voucher.voucher_id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.04 }}
                >
                  <VoucherListItem
                    voucher={voucher}
                    onClick={() => {
                      setSelectedVoucher(voucher);
                      setIsOfferSheetOpen(true);
                    }}
                    onMarkUsed={() => handleMarkUsed(voucher.voucher_id)}
                  />
                </motion.div>
              ))
            )}
          </motion.div>
        )}
      </main>

      {/* Filters Sheet */}
      <FiltersSheet
        isOpen={isFiltersOpen}
        onClose={() => setIsFiltersOpen(false)}
        onApply={setFilters}
        currentFilters={filters}
      />

      {/* Offer Sheet */}
      <OfferSheet
        voucher={selectedVoucher}
        isOpen={isOfferSheetOpen}
        onClose={() => setIsOfferSheetOpen(false)}
        onMarkUsed={(voucherId) => {
          setIsOfferSheetOpen(false);
          handleMarkUsed(voucherId);
        }}
      />

      {/* Mark Used Dialog */}
      <MarkUsedDialog
        voucher={voucherToMark}
        isOpen={markUsedDialogOpen}
        onClose={() => setMarkUsedDialogOpen(false)}
        onSuccess={handleMarkUsedConfirm}
      />
    </div>
  );
};

export default CalendarView;
