import { useEffect, useState, useMemo } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { supabase } from "@/integrations/supabase/client";
import { Session } from "@supabase/supabase-js";
import { Button } from "@/components/ui/button";
import { Plus, LogOut, Calendar, Settings, Search, Filter, RefreshCw, Bookmark } from "lucide-react";
import VoucherListItem from "@/components/VoucherListItem";
import SwipeToActionRow from "@/components/SwipeToActionRow";
import { useToast } from "@/hooks/use-toast";
import Avatar from "@/components/Avatar";
import GradientButton from "@/components/GradientButton";
import HeroWallet from "@/components/HeroWallet";
import ExpiringSoon from "@/components/ExpiringSoon";
import OfferSheet from "@/components/OfferSheet";
import { MarkUsedDialog } from "@/components/MarkUsedDialog";

import FiltersSheet, { FilterState } from "@/components/FiltersSheet";
import { Input } from "@/components/ui/input";
import { useCurrencyPrefs } from "@/hooks/useCurrencyPrefs";
import { computeTotalSaved } from "@/lib/savings";
import { TimeframePreset, getDateRangeForPreset, DateRange } from "@/lib/dateRanges";

// Fisher-Yates shuffle
function shuffle<T>(arr: T[]): T[] {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

interface Voucher {
  voucher_id: string;
  merchant: string;
  merchant_logo_path?: string | null;
  merchant_domain?: string | null;
  location?: string | null;
  deal_type: string;
  value: number | null;
  currency: string;
  category: string;
  expiry_date: string | null;
  conditions: string;
  tags: string[];
  status: string;
  apply_mode?: string;
  online_url?: string | null;
}

const Dashboard = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [searchParams, setSearchParams] = useSearchParams();
  const [session, setSession] = useState<Session | null>(null);
  const [vouchers, setVouchers] = useState<Voucher[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedVoucher, setSelectedVoucher] = useState<Voucher | null>(null);
  const [isSheetOpen, setIsSheetOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [isFiltersOpen, setIsFiltersOpen] = useState(false);
  const [filters, setFilters] = useState<FilterState>({
    status: [],
    categories: [],
    merchant: "",
    daysLeft: [0, 30],
  });
  const [totalSavings, setTotalSavings] = useState(0);
  const [hasMixedCurrencies, setHasMixedCurrencies] = useState(false);
  const { prefs } = useCurrencyPrefs();
  const [homeBorders, setHomeBorders] = useState<string[]>([]);

  // Read timeframe from URL
  const timeframe = (searchParams.get('tf') as TimeframePreset) || 'all';
  const customFrom = searchParams.get('from');
  const customTo = searchParams.get('to');
  const customRange: DateRange | undefined =
    timeframe === 'custom' && customFrom && customTo
      ? { from: new Date(customFrom), to: new Date(customTo) }
      : undefined;

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (!session) {
        navigate("/auth");
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (!session) {
        navigate("/auth");
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  // Load home borders once on mount
  useEffect(() => {
    (async () => {
      const { data, error } = await supabase
        .from('border_styles')
        .select('id')
        .eq('target', 'home');
      
      if (error) {
        console.error('Error fetching home borders:', error);
      }
      
      const ids = (data || []).map(b => b.id);
      console.log(`Loaded ${ids.length} approved home borders`);
      setHomeBorders(shuffle(ids));
    })();
  }, []);

  useEffect(() => {
    if (session) {
      fetchVouchers();
    }
  }, [session]);

  useEffect(() => {
    if (!session?.user || !prefs.code) return;

    fetchTotalSavings();

    // Subscribe to realtime updates on vouchers for used status changes
    const channel = supabase
      .channel("vouchers-total-saved")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "vouchers",
          filter: `user_id=eq.${session.user.id}`,
        },
        () => {
          // Refetch total saved when vouchers change
          fetchTotalSavings();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [session, prefs.code]);

  const fetchTotalSavings = async () => {
    if (!session?.user) return;

    // Total Saved always shows ALL used vouchers (matches History), not filtered by timeframe
    const { total, hasMixedCurrencies } = await computeTotalSaved({
      userId: session.user.id,
      preferredCurrency: prefs.code,
    });

    setTotalSavings(total);
    setHasMixedCurrencies(hasMixedCurrencies);
  };

  const fetchVouchers = async () => {
    try {
      const { data, error } = await supabase
        .from("vouchers")
        .select(`
          voucher_id,
          merchant,
          merchant_logo_path,
          merchant_domain,
          location,
          deal_type,
          value,
          currency,
          expiry_date,
          conditions,
          personal_notes,
          tags,
          status,
          category,
          display_title,
          source_offer_id,
          affiliate_offers:source_offer_id(deep_link)
        `)
        .eq("status", "active")
        .order("expiry_date", { ascending: true });

      if (error) throw error;
      
      // Compute online_url from available sources
      const vouchersWithUrl = (data || []).map((v: any) => ({
        ...v,
        online_url: v.affiliate_offers?.deep_link || v.affiliate_url || v.deep_link || v.link || v.url || null,
        affiliate_offers: undefined, // Remove nested object
      }));
      
      setVouchers(vouchersWithUrl);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate("/auth");
  };

  const getExpiryStatus = (expiryDate: string | null) => {
    if (!expiryDate) return { color: "bg-muted", text: "No expiry", days: null };
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const expiry = new Date(expiryDate);
    expiry.setHours(0, 0, 0, 0);
    const diffTime = expiry.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays < 0) return { color: "bg-destructive", text: "Expired", days: diffDays };
    if (diffDays <= 3) return { color: "bg-destructive", text: `${diffDays}d left`, days: diffDays };
    if (diffDays <= 7) return { color: "bg-warning", text: `${diffDays}d left`, days: diffDays };
    return { color: "bg-success", text: `${diffDays}d left`, days: diffDays };
  };

  const handleVoucherClick = (voucherId: string) => {
    const voucher = vouchers.find((v) => v.voucher_id === voucherId);
    if (voucher) {
      setSelectedVoucher(voucher);
      setIsSheetOpen(true);
    }
  };

  const [markUsedDialogOpen, setMarkUsedDialogOpen] = useState(false);
  const [voucherToMark, setVoucherToMark] = useState<Voucher | null>(null);

  const handleMarkUsed = (voucherId: string) => {
    const voucher = vouchers.find((v) => v.voucher_id === voucherId);
    if (!voucher) return;
    
    setVoucherToMark(voucher);
    setMarkUsedDialogOpen(true);
  };

  const handleMarkUsedConfirm = () => {
    if (!voucherToMark) return;
    
    // Optimistic update - immediately remove from list
    setVouchers((prev) => prev.filter((v) => v.voucher_id !== voucherToMark.voucher_id));
    setMarkUsedDialogOpen(false);
    
    toast({
      description: "Moved to History",
    });
    
    // Refresh total savings
    fetchTotalSavings();
  };

  // Calculate stats for HeroWallet
  const expiringThisWeek = vouchers.filter((v) => {
    const status = getExpiryStatus(v.expiry_date);
    return status.days !== null && status.days >= 0 && status.days <= 7;
  }).length;
  const autoApplyCount = vouchers.filter((v) => {
    const status = getExpiryStatus(v.expiry_date);
  return (
      v.apply_mode === "auto" &&
      status.days !== null &&
      status.days >= 0 &&
      status.days <= 7
    );
  }).length;

  const handleTimeframeChange = (preset: TimeframePreset, customRange?: DateRange) => {
    const params = new URLSearchParams(searchParams);
    params.set('tf', preset);
    
    if (preset === 'custom' && customRange?.from && customRange?.to) {
      params.set('from', customRange.from.toISOString().split('T')[0]);
      params.set('to', customRange.to.toISOString().split('T')[0]);
    } else {
      params.delete('from');
      params.delete('to');
    }
    
    setSearchParams(params);
    // Note: Total Saved always shows ALL used vouchers, not filtered by timeframe
  };

  const handleRemoveVoucher = async (voucherId: string) => {
    const voucherToRemove = vouchers.find((v) => v.voucher_id === voucherId);
    if (!voucherToRemove) return;
    
    // Store for undo (5 second window)
    let undoTimeout: NodeJS.Timeout;
    
    // Optimistic update
    setVouchers((prev) => prev.filter((v) => v.voucher_id !== voucherId));

    const performDelete = async () => {
      try {
        const { error } = await supabase
          .from("vouchers")
          .delete()
          .eq("voucher_id", voucherId);

        if (error) throw error;
      } catch (error: any) {
        // Revert on error
        setVouchers((prev) => [voucherToRemove, ...prev]);
        toast({
          variant: "destructive",
          description: "Failed to remove voucher",
        });
      }
    };

    // Schedule delete after 5 seconds
    undoTimeout = setTimeout(performDelete, 5000);

    toast({
      description: "Removed • Undo",
      action: (
        <button
          onClick={() => {
            clearTimeout(undoTimeout);
            setVouchers((prev) => [voucherToRemove, ...prev]);
            toast({
              description: "Restored to dashboard",
            });
          }}
          className="text-sm underline"
        >
          Undo
        </button>
      ),
    });
  };

  // Get expiring soon vouchers (≤14 days)
  const expiringSoonVouchers = vouchers
    .filter((v) => {
      const status = getExpiryStatus(v.expiry_date);
      return v.status === "active" && status.days !== null && status.days >= 0 && status.days <= 14;
    })
    .sort((a, b) => {
      const aDate = a.expiry_date ? new Date(a.expiry_date).getTime() : Infinity;
      const bDate = b.expiry_date ? new Date(b.expiry_date).getTime() : Infinity;
      return aDate - bDate;
    });

  // Filter vouchers based on search and filters (exclude used vouchers)
  const filteredVouchers = vouchers.filter((v) => {
    // Exclude used vouchers from main list
    if (v.status === "used") return false;
    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      const matchesMerchant = v.merchant.toLowerCase().includes(query);
      const matchesTags = v.tags?.some((tag) => tag.toLowerCase().includes(query));
      const matchesDealType = v.deal_type.toLowerCase().includes(query);
      if (!matchesMerchant && !matchesTags && !matchesDealType) return false;
    }

    // Status filter
    if (filters.status.length > 0) {
      const status = getExpiryStatus(v.expiry_date);
      const isExpiring = status.days !== null && status.days >= 0 && status.days <= 7;
      const isExpired = status.days !== null && status.days < 0;
      
      const matchesStatus = filters.status.some((s) => {
        if (s === "active") return v.status === "active" && !isExpiring && !isExpired;
        if (s === "expiring") return isExpiring && v.status === "active";
        if (s === "expired") return isExpired || v.status === "expired";
        if (s === "used") return v.status === "used";
        return false;
      });
      
      if (!matchesStatus) return false;
    }

    // Category filter
    if (filters.categories.length > 0 && !filters.categories.includes(v.category)) {
      return false;
    }

    // Merchant filter
    if (filters.merchant && !v.merchant.toLowerCase().includes(filters.merchant.toLowerCase())) {
      return false;
    }

    // Days left filter
    const status = getExpiryStatus(v.expiry_date);
    if (status.days !== null) {
      if (status.days < filters.daysLeft[0] || status.days > filters.daysLeft[1]) {
        return false;
      }
    }

    return true;
  });

  const activeFiltersCount = 
    filters.status.length +
    filters.categories.length +
    (filters.merchant ? 1 : 0) +
    (filters.daysLeft[0] !== 0 || filters.daysLeft[1] !== 30 ? 1 : 0);

  // Deterministic border assignment with daily seed
  const seededPick = useMemo(() => {
    const day = new Date();
    const seed = `${day.getUTCFullYear()}-${day.getUTCMonth() + 1}-${day.getUTCDate()}`;
    
    const hash = (str: string): number => {
      let h = 2166136261;
      for (let i = 0; i < str.length; i++) {
        h ^= str.charCodeAt(i);
        h += (h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24);
      }
      return h >>> 0;
    };

    return (voucherId: string, prevBorderId?: string): string | undefined => {
      if (homeBorders.length === 0) return undefined;
      const idx = hash(voucherId + seed) % homeBorders.length;
      const borderId = homeBorders[idx];
      
      // Avoid same as previous neighbor
      if (prevBorderId && borderId === prevBorderId && homeBorders.length > 1) {
        return homeBorders[(idx + 1) % homeBorders.length];
      }
      
      return borderId;
    };
  }, [homeBorders]);

  if (!session) return null;

  return (
    <div className="min-h-screen pb-20">
      {/* Header */}
      <motion.header
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="sticky top-0 z-50 glass-card border-b border-white/20 px-4 py-4"
      >
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold gradient-text">Your Deals</h1>
            <p className="text-sm text-muted-foreground">
              {vouchers.filter(v => {
                const status = getExpiryStatus(v.expiry_date);
                return status.days !== null && status.days >= 0 && status.days <= 7;
              }).length} expiring this week
            </p>
          </div>
          <div className="flex gap-2 items-center">
            <Button
              variant="ghost"
              size="icon"
              onClick={handleSignOut}
              className="rounded-full"
            >
              <LogOut className="h-5 w-5" />
            </Button>
            <Avatar size={40} />
          </div>
        </div>
      </motion.header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-6 space-y-6 pb-24 lg:pb-6">
        {/* Search + Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="space-y-3"
        >
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              placeholder="Search vouchers, merchants, or deals…"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex items-center gap-2 justify-between">
            <Button
              variant="outline"
              onClick={() => setIsFiltersOpen(true)}
              className="gap-2"
            >
              <Filter className="h-4 w-4" />
              Filters
              {activeFiltersCount > 0 && (
                <span className="ml-1 text-xs bg-primary text-primary-foreground rounded-full px-2 py-0.5">
                  {activeFiltersCount}
                </span>
              )}
            </Button>
            <div className="flex items-center gap-3">
              <span className="text-sm text-muted-foreground">
                {filteredVouchers.length} of {vouchers.filter(v => v.status !== "used").length} vouchers
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate("/history")}
                className="text-primary hover:underline"
              >
                History
              </Button>
            </div>
          </div>
        </motion.div>

        {/* Hero Wallet */}
        <HeroWallet
          totalSavings={totalSavings}
          expiringThisWeek={expiringThisWeek}
          autoApplyCount={autoApplyCount}
          timeframe={timeframe}
          customRange={customRange}
          hasMixedCurrencies={hasMixedCurrencies}
          onTimeframeChange={handleTimeframeChange}
        />

        {/* Saved Vouchers Section */}
        <div className="space-y-4">
          <motion.div
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-2"
          >
            <Bookmark className="h-5 w-5 text-primary" />
            <h2 className="text-lg font-semibold">Saved</h2>
          </motion.div>
          
          <AnimatePresence mode="popLayout">
            {vouchers.length === 0 && !loading ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-12 space-y-4"
              >
                <Avatar size={72} />
                <div className="inline-block glass rounded-full px-4 py-2 mb-4">
                  <p className="text-sm">Let's add your first deal!</p>
                </div>
                <p className="text-muted-foreground mb-4">No vouchers yet</p>
                <GradientButton onClick={() => navigate("/add")}>
                  <Plus className="mr-2 h-4 w-4 inline" />
                  Add Your First Deal
                </GradientButton>
              </motion.div>
            ) : filteredVouchers.length === 0 ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-12 space-y-4"
              >
                <p className="text-muted-foreground">No vouchers match your filters</p>
              </motion.div>
            ) : (
              (() => {
                let prevBorderId: string | undefined;
                return filteredVouchers.map((voucher, index) => {
                  const borderId = seededPick(voucher.voucher_id, prevBorderId);
                  prevBorderId = borderId;
                  return (
                    <SwipeToActionRow
                      key={voucher.voucher_id}
                      onRemove={() => handleRemoveVoucher(voucher.voucher_id)}
                    >
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 8, height: 0, transition: { duration: 0.18 } }}
                        transition={{ delay: index * 0.04 }}
                      >
                        <VoucherListItem
                          voucher={voucher}
                          onClick={() => handleVoucherClick(voucher.voucher_id)}
                          onMarkUsed={() => handleMarkUsed(voucher.voucher_id)}
                          borderStyleId={borderId}
                        />
                      </motion.div>
                    </SwipeToActionRow>
                  );
                });
              })()
            )}
          </AnimatePresence>
        </div>
      </main>

      {/* Offer Sheet */}
      <OfferSheet
        voucher={selectedVoucher}
        isOpen={isSheetOpen}
        onClose={() => setIsSheetOpen(false)}
        onMarkUsed={handleMarkUsed}
      />

      {/* Filters Sheet */}
      <FiltersSheet
        isOpen={isFiltersOpen}
        onClose={() => setIsFiltersOpen(false)}
        onApply={setFilters}
        currentFilters={filters}
      />

      {/* Mark Used Dialog */}
      <MarkUsedDialog
        voucher={voucherToMark}
        isOpen={markUsedDialogOpen}
        onClose={() => setMarkUsedDialogOpen(false)}
        onSuccess={handleMarkUsedConfirm}
      />
    </div>
  );
};

export default Dashboard;
