import { useState } from "react";
import { motion } from "framer-motion";
import { Tags } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import DealsGrid from "@/components/deals/DealsGrid";

export default function Affiliates() {
  const [selectedPlatform, setSelectedPlatform] = useState<string>("all");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  const platforms = ["all", "shopee", "lazada", "grab", "foodpanda", "temu", "amazon", "taobao"];
  const categories = ["all", "marketplace", "ehailing", "food", "electronics"];

  return (
    <div className="min-h-screen pb-20">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 z-40 glass border-b border-white/20 px-4 py-4"
      >
        <div className="flex items-center gap-2 mb-1">
          <Tags className="h-6 w-6 text-primary" />
          <h1 className="text-2xl font-bold">Deals & Vouchers</h1>
        </div>
        <p className="text-sm text-muted-foreground mb-2">
          Curated vouchers from trusted platforms
        </p>
        <Badge variant="outline" className="text-xs">
          We may earn affiliate commissions
        </Badge>
      </motion.div>

      {/* Filters */}
      <div className="px-4 py-4 space-y-3">
        {/* Platform filter */}
        <div>
          <p className="text-xs text-muted-foreground mb-2">Platform</p>
          <div className="flex flex-wrap gap-2">
            {platforms.map((platform) => (
              <motion.button
                key={platform}
                whileTap={{ scale: 0.95 }}
                onClick={() => setSelectedPlatform(platform)}
                className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
                  selectedPlatform === platform
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground hover:bg-muted/80"
                }`}
              >
                {platform.charAt(0).toUpperCase() + platform.slice(1)}
              </motion.button>
            ))}
          </div>
        </div>

        {/* Category filter */}
        <div>
          <p className="text-xs text-muted-foreground mb-2">Category</p>
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <motion.button
                key={category}
                whileTap={{ scale: 0.95 }}
                onClick={() => setSelectedCategory(category)}
                className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
                  selectedCategory === category
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground hover:bg-muted/80"
                }`}
              >
                {category.charAt(0).toUpperCase() + category.slice(1)}
              </motion.button>
            ))}
          </div>
        </div>
      </div>

      {/* Deals Grid */}
      <div className="px-4">
        <DealsGrid 
          selectedPlatform={selectedPlatform}
          selectedCategory={selectedCategory}
        />
      </div>

      {/* Trust message */}
      <div className="px-4 py-6 text-center text-xs text-muted-foreground">
        <p>
          Offers come from official partners and public campaigns. We'll show the source and expiry when available.
        </p>
      </div>
    </div>
  );
}
