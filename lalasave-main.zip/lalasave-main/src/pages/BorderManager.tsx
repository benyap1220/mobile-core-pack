import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Upload, 
  ShieldAlert, 
  Loader2, 
  ArrowLeft 
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import GradientButton from "@/components/GradientButton";
import DealCardPreview from "@/components/deals/DealCardPreview";
import HomeVoucherPreviewMock from "@/components/deals/HomeVoucherPreviewMock";

interface SafeArea {
  top: number;
  right: number;
  bottom: number;
  left: number;
}

interface BorderPrototype {
  id: string;
  title: string | null;
  preview_path: string | null;
  image_path: string | null;
  style_tag: string | null;
  target: string;
  is_approved: boolean;
  created_at: string;
}

export default function BorderManager() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);
  const [checking, setChecking] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [prototypes, setPrototypes] = useState<BorderPrototype[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTarget, setActiveTarget] = useState<'deals' | 'home'>('deals');
  
  // Upload state
  const [styleTag, setStyleTag] = useState("organic");
  const [layoutMode, setLayoutMode] = useState<"full-frame">("full-frame");

  // Check admin status
  useEffect(() => {
    const checkAdminStatus = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        
        if (!user) {
          navigate("/auth");
          return;
        }

        const { data: roles } = await supabase
          .from("user_roles")
          .select("role")
          .eq("user_id", user.id)
          .eq("role", "admin")
          .maybeSingle();

        setIsAdmin(!!roles);
        if (!roles) {
          toast({
            title: "Access Denied",
            description: "You need admin privileges to access Border Manager",
            variant: "destructive",
          });
        }
      } catch (error) {
        console.error("Error checking admin:", error);
        setIsAdmin(false);
      } finally {
        setChecking(false);
      }
    };

    checkAdminStatus();
  }, [navigate, toast]);

  // Fetch prototypes
  useEffect(() => {
    if (isAdmin) {
      fetchPrototypes();
    }
  }, [isAdmin]);

  const fetchPrototypes = async () => {
    try {
      const { data, error } = await supabase
        .from("border_prototypes")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;
      
      setPrototypes(data || []);
    } catch (error) {
      console.error("Error fetching prototypes:", error);
      toast({
        title: "Error",
        description: "Failed to load border prototypes",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (files: FileList | null, target: 'deals' | 'home') => {
    if (!files || files.length === 0) return;

    setUploading(true);
    try {
      const file = files[0];
      console.log("Starting file upload:", file.name, file.type, file.size);
      
      // Upload to temporary storage
      const fileExt = file.name.split(".").pop();
      const fileName = `${crypto.randomUUID()}.${fileExt}`;
      const filePath = `temp/${fileName}`;

      console.log("Uploading to storage:", filePath);
      const { error: uploadError } = await supabase.storage
        .from("borders")
        .upload(filePath, file);

      if (uploadError) {
        console.error("Storage upload error:", uploadError);
        throw uploadError;
      }

      console.log("File uploaded to storage successfully");

      // Get fresh session token
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) {
        throw new Error("No active session. Please log in again.");
      }

      const requestBody = {
        filePath,
        options: {
          styleTag,
          layoutMode,
          target,
        },
      };

      console.log("Calling ingest-border function with:", requestBody);

      // Call edge function with explicit auth
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ingest-border`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${session.access_token}`,
            "apikey": import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
          },
          body: JSON.stringify(requestBody),
        }
      );

      console.log("Edge function response status:", response.status);

      if (!response.ok) {
        const errorData = await response.json();
        console.error("Edge function error response:", errorData);
        throw new Error(errorData.error || `Edge function failed with status ${response.status}`);
      }

      const data = await response.json();
      console.log("Edge function success response:", data);

      toast({
        title: "Success",
        description: `Border uploaded for ${target}`,
      });

      // Refresh prototypes
      await fetchPrototypes();
    } catch (error) {
      console.error("Upload error:", error);
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      toast({
        title: "Upload Failed",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  };

  const handleApprove = async (prototypeId: string) => {
    try {
      const { error } = await supabase.functions.invoke("approve-border", {
        body: { prototype_id: prototypeId },
      });

      if (error) throw error;

      toast({
        title: "Approved",
        description: "Border style is now live",
      });

      await fetchPrototypes();
    } catch (error) {
      console.error("Approve error:", error);
      toast({
        title: "Failed to approve",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive",
      });
    }
  };

  if (checking) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="glass rounded-2xl p-8 max-w-md w-full text-center space-y-4">
          <ShieldAlert className="h-12 w-12 text-destructive mx-auto" />
          <h1 className="text-2xl font-bold">Access Denied</h1>
          <p className="text-muted-foreground">
            Border Manager requires administrator privileges.
          </p>
          <Button onClick={() => navigate("/")} className="w-full">
            Return to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  const dealsPrototypes = prototypes.filter(p => p.target === 'deals');
  const homePrototypes = prototypes.filter(p => p.target === 'home');

  return (
    <div className="min-h-screen pb-20">
      <motion.header
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="sticky top-0 z-50 glass-card border-b border-white/20 px-4 py-4"
      >
        <div className="max-w-7xl mx-auto flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("/affiliate-admin")}
            className="rounded-full"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-2xl font-bold gradient-text">Border Manager</h1>
        </div>
      </motion.header>

      <main className="max-w-7xl mx-auto px-4 py-6">
        <Tabs defaultValue="deals" className="w-full" onValueChange={(v) => setActiveTarget(v as 'deals' | 'home')}>
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="deals">Deals Borders</TabsTrigger>
            <TabsTrigger value="home">Home Borders</TabsTrigger>
          </TabsList>

          {/* Deals Tab */}
          <TabsContent value="deals" className="space-y-6">
            <div className="glass-card rounded-2xl p-6 space-y-4">
              <h2 className="text-lg font-semibold">Upload Deals Border</h2>
              
              <div className="space-y-2">
                <Label>Style Tag</Label>
                <Select value={styleTag} onValueChange={setStyleTag}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="wave">Wave</SelectItem>
                    <SelectItem value="neon">Neon</SelectItem>
                    <SelectItem value="ink">Ink</SelectItem>
                    <SelectItem value="geo">Geometric</SelectItem>
                    <SelectItem value="organic">Organic</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="deals-upload">Upload PNG/JPG</Label>
                <Input
                  id="deals-upload"
                  type="file"
                  accept="image/png,image/jpeg"
                  onChange={(e) => handleFileUpload(e.target.files, 'deals')}
                  disabled={uploading}
                />
              </div>

              {uploading && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>Uploading...</span>
                </div>
              )}
            </div>

            {/* Deals Prototypes Queue */}
            <div className="space-y-4">
              <h2 className="text-xl font-semibold">Deals Prototypes ({dealsPrototypes.length})</h2>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {dealsPrototypes.map((proto) => (
                  <div key={proto.id} className="glass-card rounded-xl p-4 space-y-3">
                    <DealCardPreview 
                      borderStyleId={proto.id}
                      sourceTable="border_prototypes"
                    />
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">{proto.title || 'Untitled'}</span>
                        <Badge variant={proto.is_approved ? "default" : "secondary"}>
                          {proto.is_approved ? "Approved" : "Pending"}
                        </Badge>
                      </div>
                      {!proto.is_approved && (
                        <GradientButton
                          onClick={() => handleApprove(proto.id)}
                          className="w-full h-8 text-sm"
                        >
                          Approve
                        </GradientButton>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>

          {/* Home Tab */}
          <TabsContent value="home" className="space-y-6">
            <div className="glass-card rounded-2xl p-6 space-y-4">
              <h2 className="text-lg font-semibold">Upload Home Border</h2>
              
              <div className="space-y-2">
                <Label>Style Tag</Label>
                <Select value={styleTag} onValueChange={setStyleTag}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="wave">Wave</SelectItem>
                    <SelectItem value="neon">Neon</SelectItem>
                    <SelectItem value="ink">Ink</SelectItem>
                    <SelectItem value="geo">Geometric</SelectItem>
                    <SelectItem value="organic">Organic</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="home-upload">Upload PNG/JPG</Label>
                <Input
                  id="home-upload"
                  type="file"
                  accept="image/png,image/jpeg"
                  onChange={(e) => handleFileUpload(e.target.files, 'home')}
                  disabled={uploading}
                />
              </div>

              {uploading && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>Uploading...</span>
                </div>
              )}
            </div>

            {/* Home Prototypes Queue */}
            <div className="space-y-4">
              <h2 className="text-xl font-semibold">Home Prototypes ({homePrototypes.length})</h2>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {homePrototypes.map((proto) => (
                <div key={proto.id} className="glass-card rounded-xl p-4 space-y-3">
                    <div className="w-full max-w-[600px] mx-auto">
                      <HomeVoucherPreviewMock 
                        borderStyleId={proto.id}
                        sourceTable="border_prototypes"
                      />
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">{proto.title || 'Untitled'}</span>
                        <Badge variant={proto.is_approved ? "default" : "secondary"}>
                          {proto.is_approved ? "Approved" : "Pending"}
                        </Badge>
                      </div>
                      {!proto.is_approved && (
                        <GradientButton
                          onClick={() => handleApprove(proto.id)}
                          className="w-full h-8 text-sm"
                        >
                          Approve
                        </GradientButton>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
