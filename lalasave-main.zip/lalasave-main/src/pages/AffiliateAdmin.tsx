import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Loader2, RefreshCw, ShieldAlert } from "lucide-react";
import GradientButton from "@/components/GradientButton";

export default function AffiliateAdmin() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [backfilling, setBackfilling] = useState(false);
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);
  const [checking, setChecking] = useState(true);

  // Check if user is admin
  useEffect(() => {
    const checkAdminStatus = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        
        if (!user) {
          navigate("/auth");
          return;
        }

        // Check if user has admin role
        const { data: roles } = await supabase
          .from("user_roles")
          .select("role")
          .eq("user_id", user.id)
          .eq("role", "admin")
          .maybeSingle();

        if (!roles) {
          setIsAdmin(false);
          toast({
            title: "Access Denied",
            description: "You don't have admin privileges",
            variant: "destructive",
          });
        } else {
          setIsAdmin(true);
        }
      } catch (error) {
        console.error("Error checking admin status:", error);
        setIsAdmin(false);
      } finally {
        setChecking(false);
      }
    };

    checkAdminStatus();
  }, [navigate, toast]);

  const handleBackfillLogos = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("affiliate-logo-backfill");

      if (error) throw error;

      toast({
        title: "Logo backfill complete",
        description: `Processed ${data.processed} offers`,
      });

      // Refresh the page after 2 seconds to show new logos
      setTimeout(() => window.location.reload(), 2000);
    } catch (error) {
      console.error("Backfill error:", error);
      toast({
        title: "Backfill failed",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleVoucherBackfill = async () => {
    setBackfilling(true);
    try {
      const { data, error } = await supabase.functions.invoke('voucher-display-title-backfill');
      
      if (error) throw error;
      
      toast({
        title: "Voucher backfill complete",
        description: `Updated ${data?.updated || 0} vouchers, skipped ${data?.skipped || 0}`,
      });
    } catch (error) {
      console.error("Error during backfill:", error);
      toast({
        title: "Error",
        description: "Failed to backfill voucher titles",
        variant: "destructive",
      });
    } finally {
      setBackfilling(false);
    }
  };

  // Show loading state
  if (checking) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  // Show access denied
  if (isAdmin === false) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="glass rounded-2xl p-8 max-w-md w-full text-center space-y-4">
          <ShieldAlert className="h-12 w-12 text-destructive mx-auto" />
          <h1 className="text-2xl font-bold">Access Denied</h1>
          <p className="text-muted-foreground">
            You need administrator privileges to access this page.
          </p>
          <Button onClick={() => navigate("/")} className="w-full">
            Return to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="glass rounded-2xl p-8 max-w-md w-full space-y-6">
        <div>
          <h1 className="text-2xl font-bold mb-2">Affiliate Admin</h1>
          <p className="text-sm text-muted-foreground">
            Manage logos, vouchers, and border styles
          </p>
        </div>

        <div className="space-y-4">
          <div>
            <h2 className="font-semibold mb-2">Logo Backfill</h2>
            <p className="text-sm text-muted-foreground mb-3">
              Fetch official logos for affiliate platforms using Clearbit, Unavatar, and Google Favicon APIs.
            </p>
            <Button
              onClick={handleBackfillLogos}
              disabled={loading}
              className="w-full"
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Fetching logos...
                </>
              ) : (
                <>
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Fetch Official Logos
                </>
              )}
            </Button>
          </div>

          <div>
            <h2 className="font-semibold mb-2">Voucher Title Backfill</h2>
            <p className="text-sm text-muted-foreground mb-3">
              Update existing saved vouchers to show proper offer titles instead of generic tags.
            </p>
            <GradientButton
              onClick={handleVoucherBackfill}
              disabled={backfilling}
              className="w-full"
            >
              {backfilling ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                "Backfill Voucher Titles"
              )}
            </GradientButton>
          </div>

          <div>
            <h2 className="font-semibold mb-2">Border Manager</h2>
            <p className="text-sm text-muted-foreground mb-3">
              Upload and manage artistic borders for voucher cards.
            </p>
            <Button
              onClick={() => navigate("/admin/borders")}
              variant="outline"
              className="w-full"
            >
              Open Border Manager
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
