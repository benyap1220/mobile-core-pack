import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Auth from "./pages/Auth";
import Dashboard from "./pages/Dashboard";
import AddVoucher from "./pages/AddVoucher";
import VoucherDetail from "./pages/VoucherDetail";
import CalendarView from "./pages/CalendarView";
import Settings from "./pages/Settings";
import History from "./pages/History";
import Affiliates from "./pages/Affiliates";
import AffiliateAdmin from "./pages/AffiliateAdmin";
import IADeals from "./pages/IADeals";
import IAAdmin from "./pages/IAAdmin";
import BorderManager from "./pages/BorderManager";
import ApprovedBorders from "./pages/ApprovedBorders";
import MerchantManager from "./pages/MerchantManager";
import SeedLogos from "./pages/SeedLogos";
import AdminDebugLogos from "./pages/AdminDebugLogos";
import NotFound from "./pages/NotFound";
import BottomTabs from "./components/BottomTabs";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <div className="min-h-screen">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/auth" element={<Auth />} />
            <Route path="/add" element={<AddVoucher />} />
            <Route path="/voucher/:id" element={<VoucherDetail />} />
            <Route path="/calendar" element={<CalendarView />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="/history" element={<History />} />
            <Route path="/affiliates" element={<Affiliates />} />
            <Route path="/affiliate-admin" element={<AffiliateAdmin />} />
            <Route path="/ia-deals" element={<IADeals />} />
            <Route path="/ia-admin" element={<IAAdmin />} />
            <Route path="/admin/borders" element={<BorderManager />} />
            <Route path="/admin/borders/approved" element={<ApprovedBorders />} />
            <Route path="/admin/merchants" element={<MerchantManager />} />
            <Route path="/admin/seed-logos" element={<SeedLogos />} />
            <Route path="/admin/debug-logos" element={<AdminDebugLogos />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
          <BottomTabs />
        </div>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
