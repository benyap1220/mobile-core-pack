export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      aff_clicks: {
        Row: {
          aff_sub: string | null
          aff_sub2: string | null
          aff_sub3: string | null
          aff_sub4: string | null
          created_at: string | null
          deeplink_id: string | null
          id: string
          offer_id: number | null
        }
        Insert: {
          aff_sub?: string | null
          aff_sub2?: string | null
          aff_sub3?: string | null
          aff_sub4?: string | null
          created_at?: string | null
          deeplink_id?: string | null
          id?: string
          offer_id?: number | null
        }
        Update: {
          aff_sub?: string | null
          aff_sub2?: string | null
          aff_sub3?: string | null
          aff_sub4?: string | null
          created_at?: string | null
          deeplink_id?: string | null
          id?: string
          offer_id?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "aff_clicks_deeplink_id_fkey"
            columns: ["deeplink_id"]
            isOneToOne: false
            referencedRelation: "ia_deeplinks"
            referencedColumns: ["id"]
          },
        ]
      }
      aff_impressions: {
        Row: {
          created_at: string | null
          deal_id: string | null
          id: string
        }
        Insert: {
          created_at?: string | null
          deal_id?: string | null
          id?: string
        }
        Update: {
          created_at?: string | null
          deal_id?: string | null
          id?: string
        }
        Relationships: [
          {
            foreignKeyName: "aff_impressions_deal_id_fkey"
            columns: ["deal_id"]
            isOneToOne: false
            referencedRelation: "deals_feed"
            referencedColumns: ["id"]
          },
        ]
      }
      affiliate_clicks: {
        Row: {
          clicked_at: string | null
          id: number
          offer_id: string | null
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          clicked_at?: string | null
          id?: number
          offer_id?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          clicked_at?: string | null
          id?: number
          offer_id?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "affiliate_clicks_offer_id_fkey"
            columns: ["offer_id"]
            isOneToOne: false
            referencedRelation: "affiliate_offers"
            referencedColumns: ["id"]
          },
        ]
      }
      affiliate_offers: {
        Row: {
          border_style_id: string | null
          category: string | null
          coupon_code: string | null
          created_at: string | null
          deep_link: string
          expiry_date: string | null
          id: string
          image_url: string | null
          is_active: boolean | null
          logo_path: string | null
          merchant: string
          offer_summary: string | null
          offer_title: string
          platform: string
          region: string | null
          terms: string | null
          tracking_source: string | null
        }
        Insert: {
          border_style_id?: string | null
          category?: string | null
          coupon_code?: string | null
          created_at?: string | null
          deep_link: string
          expiry_date?: string | null
          id?: string
          image_url?: string | null
          is_active?: boolean | null
          logo_path?: string | null
          merchant: string
          offer_summary?: string | null
          offer_title: string
          platform: string
          region?: string | null
          terms?: string | null
          tracking_source?: string | null
        }
        Update: {
          border_style_id?: string | null
          category?: string | null
          coupon_code?: string | null
          created_at?: string | null
          deep_link?: string
          expiry_date?: string | null
          id?: string
          image_url?: string | null
          is_active?: boolean | null
          logo_path?: string | null
          merchant?: string
          offer_summary?: string | null
          offer_title?: string
          platform?: string
          region?: string | null
          terms?: string | null
          tracking_source?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "affiliate_offers_border_style_id_fkey"
            columns: ["border_style_id"]
            isOneToOne: false
            referencedRelation: "border_styles"
            referencedColumns: ["id"]
          },
        ]
      }
      audit_log: {
        Row: {
          action: string
          created_at: string
          details: Json | null
          id: number
          user_id: string
          voucher_id: string | null
        }
        Insert: {
          action: string
          created_at?: string
          details?: Json | null
          id?: number
          user_id: string
          voucher_id?: string | null
        }
        Update: {
          action?: string
          created_at?: string
          details?: Json | null
          id?: number
          user_id?: string
          voucher_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "audit_log_voucher_id_fkey"
            columns: ["voucher_id"]
            isOneToOne: false
            referencedRelation: "vouchers"
            referencedColumns: ["voucher_id"]
          },
        ]
      }
      border_prototypes: {
        Row: {
          base_frame_path: string | null
          composition_params: Json | null
          created_at: string | null
          extracted_motifs: Json | null
          frame_meta: Json | null
          id: string
          image_path: string | null
          is_approved: boolean | null
          layout_mode: string | null
          lottie_path: string | null
          notes: string | null
          preview_path: string | null
          quality_score: number | null
          replace_base_frame: boolean | null
          safe_area: Json | null
          scale_mode: string | null
          source_path: string
          style_reference_path: string | null
          style_tag: string | null
          style_transfer_mode: boolean | null
          submitted_by: string | null
          suggested_rotation: number | null
          svg_path: string | null
          target: string | null
          title: string | null
          view_box: Json | null
          webm_path: string | null
        }
        Insert: {
          base_frame_path?: string | null
          composition_params?: Json | null
          created_at?: string | null
          extracted_motifs?: Json | null
          frame_meta?: Json | null
          id?: string
          image_path?: string | null
          is_approved?: boolean | null
          layout_mode?: string | null
          lottie_path?: string | null
          notes?: string | null
          preview_path?: string | null
          quality_score?: number | null
          replace_base_frame?: boolean | null
          safe_area?: Json | null
          scale_mode?: string | null
          source_path: string
          style_reference_path?: string | null
          style_tag?: string | null
          style_transfer_mode?: boolean | null
          submitted_by?: string | null
          suggested_rotation?: number | null
          svg_path?: string | null
          target?: string | null
          title?: string | null
          view_box?: Json | null
          webm_path?: string | null
        }
        Update: {
          base_frame_path?: string | null
          composition_params?: Json | null
          created_at?: string | null
          extracted_motifs?: Json | null
          frame_meta?: Json | null
          id?: string
          image_path?: string | null
          is_approved?: boolean | null
          layout_mode?: string | null
          lottie_path?: string | null
          notes?: string | null
          preview_path?: string | null
          quality_score?: number | null
          replace_base_frame?: boolean | null
          safe_area?: Json | null
          scale_mode?: string | null
          source_path?: string
          style_reference_path?: string | null
          style_tag?: string | null
          style_transfer_mode?: boolean | null
          submitted_by?: string | null
          suggested_rotation?: number | null
          svg_path?: string | null
          target?: string | null
          title?: string | null
          view_box?: Json | null
          webm_path?: string | null
        }
        Relationships: []
      }
      border_styles: {
        Row: {
          approved_by: string | null
          composition_params: Json | null
          created_at: string | null
          frame_meta: Json | null
          id: string
          image_path: string | null
          layout_mode: string | null
          lottie_path: string | null
          preview_path: string | null
          replace_base_frame: boolean | null
          safe_area: Json | null
          scale_mode: string | null
          style_tag: string | null
          style_transfer_mode: boolean | null
          suggested_rotation: number | null
          svg_path: string | null
          target: string
          title: string | null
          view_box: Json | null
          webm_path: string | null
        }
        Insert: {
          approved_by?: string | null
          composition_params?: Json | null
          created_at?: string | null
          frame_meta?: Json | null
          id?: string
          image_path?: string | null
          layout_mode?: string | null
          lottie_path?: string | null
          preview_path?: string | null
          replace_base_frame?: boolean | null
          safe_area?: Json | null
          scale_mode?: string | null
          style_tag?: string | null
          style_transfer_mode?: boolean | null
          suggested_rotation?: number | null
          svg_path?: string | null
          target?: string
          title?: string | null
          view_box?: Json | null
          webm_path?: string | null
        }
        Update: {
          approved_by?: string | null
          composition_params?: Json | null
          created_at?: string | null
          frame_meta?: Json | null
          id?: string
          image_path?: string | null
          layout_mode?: string | null
          lottie_path?: string | null
          preview_path?: string | null
          replace_base_frame?: boolean | null
          safe_area?: Json | null
          scale_mode?: string | null
          style_tag?: string | null
          style_transfer_mode?: boolean | null
          suggested_rotation?: number | null
          svg_path?: string | null
          target?: string
          title?: string | null
          view_box?: Json | null
          webm_path?: string | null
        }
        Relationships: []
      }
      brand_logo_overrides: {
        Row: {
          brand_slug: string
          source: string | null
          storage_path: string
          updated_at: string | null
        }
        Insert: {
          brand_slug: string
          source?: string | null
          storage_path: string
          updated_at?: string | null
        }
        Update: {
          brand_slug?: string
          source?: string | null
          storage_path?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      deals_feed: {
        Row: {
          badge: string | null
          country: string | null
          created_at: string
          deal_key: string | null
          deeplink_id: string
          deeplink_type: string | null
          expires_at: string | null
          has_coupon: boolean | null
          id: string
          image_url: string | null
          landing_id: string | null
          offer_id: number
          platform: string | null
          primary_coupon_id: string | null
          primary_promo_id: number | null
          promo_fingerprint: string | null
          promo_id: string | null
          quality_score: number | null
          rotation_batch: string | null
          score: number
          source: string
          subtitle: string | null
          tags: string[] | null
          title: string
          uniqueness_key: string | null
        }
        Insert: {
          badge?: string | null
          country?: string | null
          created_at?: string
          deal_key?: string | null
          deeplink_id: string
          deeplink_type?: string | null
          expires_at?: string | null
          has_coupon?: boolean | null
          id?: string
          image_url?: string | null
          landing_id?: string | null
          offer_id: number
          platform?: string | null
          primary_coupon_id?: string | null
          primary_promo_id?: number | null
          promo_fingerprint?: string | null
          promo_id?: string | null
          quality_score?: number | null
          rotation_batch?: string | null
          score?: number
          source?: string
          subtitle?: string | null
          tags?: string[] | null
          title: string
          uniqueness_key?: string | null
        }
        Update: {
          badge?: string | null
          country?: string | null
          created_at?: string
          deal_key?: string | null
          deeplink_id?: string
          deeplink_type?: string | null
          expires_at?: string | null
          has_coupon?: boolean | null
          id?: string
          image_url?: string | null
          landing_id?: string | null
          offer_id?: number
          platform?: string | null
          primary_coupon_id?: string | null
          primary_promo_id?: number | null
          promo_fingerprint?: string | null
          promo_id?: string | null
          quality_score?: number | null
          rotation_batch?: string | null
          score?: number
          source?: string
          subtitle?: string | null
          tags?: string[] | null
          title?: string
          uniqueness_key?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "deals_feed_deeplink_id_fkey"
            columns: ["deeplink_id"]
            isOneToOne: false
            referencedRelation: "ia_deeplinks"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deals_feed_primary_promo_id_fkey"
            columns: ["primary_promo_id"]
            isOneToOne: false
            referencedRelation: "ia_promos"
            referencedColumns: ["id"]
          },
        ]
      }
      ia_advertisers: {
        Row: {
          approved: boolean
          categories: string[] | null
          commission_json: Json | null
          countries: string[] | null
          id: string
          last_seen: string
          logo_source: string | null
          logo_updated_at: string | null
          logo_url: string | null
          name: string
          offer_id: number
          platform_priority: number | null
          tracking_link: string | null
          tracking_type: string | null
        }
        Insert: {
          approved?: boolean
          categories?: string[] | null
          commission_json?: Json | null
          countries?: string[] | null
          id?: string
          last_seen?: string
          logo_source?: string | null
          logo_updated_at?: string | null
          logo_url?: string | null
          name: string
          offer_id: number
          platform_priority?: number | null
          tracking_link?: string | null
          tracking_type?: string | null
        }
        Update: {
          approved?: boolean
          categories?: string[] | null
          commission_json?: Json | null
          countries?: string[] | null
          id?: string
          last_seen?: string
          logo_source?: string | null
          logo_updated_at?: string | null
          logo_url?: string | null
          name?: string
          offer_id?: number
          platform_priority?: number | null
          tracking_link?: string | null
          tracking_type?: string | null
        }
        Relationships: []
      }
      ia_deeplinks: {
        Row: {
          aff_sub: string | null
          aff_sub2: string | null
          aff_sub3: string | null
          aff_sub4: string | null
          created_at: string
          deeplink_type: string | null
          deeplink_url: string
          expires_at: string | null
          id: string
          landing_id: string | null
          offer_id: number
          raw_url: string
        }
        Insert: {
          aff_sub?: string | null
          aff_sub2?: string | null
          aff_sub3?: string | null
          aff_sub4?: string | null
          created_at?: string
          deeplink_type?: string | null
          deeplink_url: string
          expires_at?: string | null
          id?: string
          landing_id?: string | null
          offer_id: number
          raw_url: string
        }
        Update: {
          aff_sub?: string | null
          aff_sub2?: string | null
          aff_sub3?: string | null
          aff_sub4?: string | null
          created_at?: string
          deeplink_type?: string | null
          deeplink_url?: string
          expires_at?: string | null
          id?: string
          landing_id?: string | null
          offer_id?: number
          raw_url?: string
        }
        Relationships: [
          {
            foreignKeyName: "ia_deeplinks_landing_id_fkey"
            columns: ["landing_id"]
            isOneToOne: false
            referencedRelation: "ia_landings"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ia_deeplinks_offer_id_fkey"
            columns: ["offer_id"]
            isOneToOne: false
            referencedRelation: "ia_advertisers"
            referencedColumns: ["offer_id"]
          },
        ]
      }
      ia_landings: {
        Row: {
          deeplinkable: boolean | null
          description: string | null
          discovered_at: string
          id: string
          image_url: string | null
          kind: string
          last_checked_at: string | null
          offer_id: number
          score: number | null
          selection_reason: Json | null
          title: string | null
          url: string
        }
        Insert: {
          deeplinkable?: boolean | null
          description?: string | null
          discovered_at?: string
          id?: string
          image_url?: string | null
          kind: string
          last_checked_at?: string | null
          offer_id: number
          score?: number | null
          selection_reason?: Json | null
          title?: string | null
          url: string
        }
        Update: {
          deeplinkable?: boolean | null
          description?: string | null
          discovered_at?: string
          id?: string
          image_url?: string | null
          kind?: string
          last_checked_at?: string | null
          offer_id?: number
          score?: number | null
          selection_reason?: Json | null
          title?: string | null
          url?: string
        }
        Relationships: [
          {
            foreignKeyName: "ia_landings_offer_id_fkey"
            columns: ["offer_id"]
            isOneToOne: false
            referencedRelation: "ia_advertisers"
            referencedColumns: ["offer_id"]
          },
        ]
      }
      ia_promo_deeplinks: {
        Row: {
          aff_sub: string | null
          aff_sub2: string | null
          aff_sub3: string | null
          aff_sub4: string | null
          created_at: string | null
          deeplink_type: string | null
          deeplink_url: string
          id: string
          promo_id: number
        }
        Insert: {
          aff_sub?: string | null
          aff_sub2?: string | null
          aff_sub3?: string | null
          aff_sub4?: string | null
          created_at?: string | null
          deeplink_type?: string | null
          deeplink_url: string
          id?: string
          promo_id: number
        }
        Update: {
          aff_sub?: string | null
          aff_sub2?: string | null
          aff_sub3?: string | null
          aff_sub4?: string | null
          created_at?: string | null
          deeplink_type?: string | null
          deeplink_url?: string
          id?: string
          promo_id?: number
        }
        Relationships: [
          {
            foreignKeyName: "ia_promo_deeplinks_promo_id_fkey"
            columns: ["promo_id"]
            isOneToOne: false
            referencedRelation: "ia_promos"
            referencedColumns: ["id"]
          },
        ]
      }
      ia_promos: {
        Row: {
          code: string | null
          created_at: string | null
          discovered_at: string | null
          ends_at: string | null
          headline: string | null
          id: number
          image_url: string | null
          landing_id: string | null
          landing_url: string
          note: string | null
          offer_id: number
          score: number | null
          source: string | null
          starts_at: string | null
          summary: string | null
          tags: string[] | null
          title: string | null
          valid_from: string | null
          valid_until: string | null
        }
        Insert: {
          code?: string | null
          created_at?: string | null
          discovered_at?: string | null
          ends_at?: string | null
          headline?: string | null
          id: number
          image_url?: string | null
          landing_id?: string | null
          landing_url: string
          note?: string | null
          offer_id: number
          score?: number | null
          source?: string | null
          starts_at?: string | null
          summary?: string | null
          tags?: string[] | null
          title?: string | null
          valid_from?: string | null
          valid_until?: string | null
        }
        Update: {
          code?: string | null
          created_at?: string | null
          discovered_at?: string | null
          ends_at?: string | null
          headline?: string | null
          id?: number
          image_url?: string | null
          landing_id?: string | null
          landing_url?: string
          note?: string | null
          offer_id?: number
          score?: number | null
          source?: string | null
          starts_at?: string | null
          summary?: string | null
          tags?: string[] | null
          title?: string | null
          valid_from?: string | null
          valid_until?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "ia_promos_landing_id_fkey"
            columns: ["landing_id"]
            isOneToOne: false
            referencedRelation: "ia_landings"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ia_promos_offer_id_fkey"
            columns: ["offer_id"]
            isOneToOne: false
            referencedRelation: "ia_advertisers"
            referencedColumns: ["offer_id"]
          },
        ]
      }
      merchant_domain_map: {
        Row: {
          domain: string
          merchant_slug: string
          updated_at: string
        }
        Insert: {
          domain: string
          merchant_slug: string
          updated_at?: string
        }
        Update: {
          domain?: string
          merchant_slug?: string
          updated_at?: string
        }
        Relationships: []
      }
      merchant_logo_cache: {
        Row: {
          merchant_slug: string
          public_url: string
          source: string
          updated_at: string
        }
        Insert: {
          merchant_slug: string
          public_url: string
          source: string
          updated_at?: string
        }
        Update: {
          merchant_slug?: string
          public_url?: string
          source?: string
          updated_at?: string
        }
        Relationships: []
      }
      promo_notes: {
        Row: {
          coupon_code: string | null
          created_at: string
          created_by: string | null
          deal_id: string
          id: string
          notes: string | null
          valid_from: string | null
          valid_until: string | null
        }
        Insert: {
          coupon_code?: string | null
          created_at?: string
          created_by?: string | null
          deal_id: string
          id?: string
          notes?: string | null
          valid_from?: string | null
          valid_until?: string | null
        }
        Update: {
          coupon_code?: string | null
          created_at?: string
          created_by?: string | null
          deal_id?: string
          id?: string
          notes?: string | null
          valid_from?: string | null
          valid_until?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "promo_notes_deal_id_fkey"
            columns: ["deal_id"]
            isOneToOne: false
            referencedRelation: "deals_feed"
            referencedColumns: ["id"]
          },
        ]
      }
      promos: {
        Row: {
          advertiser_offer_id: number
          benefit: string | null
          code: string | null
          created_at: string | null
          currency: string | null
          dedup_key: string | null
          ends_at: string | null
          id: string
          image_url: string | null
          landing_id: string | null
          min_spend: number | null
          norm_benefit: string | null
          norm_code: string | null
          norm_restrictions: string | null
          raw_url: string | null
          restrictions: string | null
          source: string
          starts_at: string | null
          title: string | null
        }
        Insert: {
          advertiser_offer_id: number
          benefit?: string | null
          code?: string | null
          created_at?: string | null
          currency?: string | null
          dedup_key?: string | null
          ends_at?: string | null
          id?: string
          image_url?: string | null
          landing_id?: string | null
          min_spend?: number | null
          norm_benefit?: string | null
          norm_code?: string | null
          norm_restrictions?: string | null
          raw_url?: string | null
          restrictions?: string | null
          source: string
          starts_at?: string | null
          title?: string | null
        }
        Update: {
          advertiser_offer_id?: number
          benefit?: string | null
          code?: string | null
          created_at?: string | null
          currency?: string | null
          dedup_key?: string | null
          ends_at?: string | null
          id?: string
          image_url?: string | null
          landing_id?: string | null
          min_spend?: number | null
          norm_benefit?: string | null
          norm_code?: string | null
          norm_restrictions?: string | null
          raw_url?: string | null
          restrictions?: string | null
          source?: string
          starts_at?: string | null
          title?: string | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string | null
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      user_settings: {
        Row: {
          created_at: string
          currency: string | null
          email_enabled: boolean | null
          gmail_connected: boolean | null
          gmail_refresh_token: string | null
          locale: string | null
          logo_lookup_enabled: boolean | null
          push_enabled: boolean | null
          updated_at: string
          user_id: string
          whatsapp_enabled: boolean | null
        }
        Insert: {
          created_at?: string
          currency?: string | null
          email_enabled?: boolean | null
          gmail_connected?: boolean | null
          gmail_refresh_token?: string | null
          locale?: string | null
          logo_lookup_enabled?: boolean | null
          push_enabled?: boolean | null
          updated_at?: string
          user_id: string
          whatsapp_enabled?: boolean | null
        }
        Update: {
          created_at?: string
          currency?: string | null
          email_enabled?: boolean | null
          gmail_connected?: boolean | null
          gmail_refresh_token?: string | null
          locale?: string | null
          logo_lookup_enabled?: boolean | null
          push_enabled?: boolean | null
          updated_at?: string
          user_id?: string
          whatsapp_enabled?: boolean | null
        }
        Relationships: []
      }
      voucher_assets: {
        Row: {
          asset_id: string
          created_at: string
          file_path: string
          file_type: string | null
          file_url: string
          voucher_id: string
        }
        Insert: {
          asset_id?: string
          created_at?: string
          file_path: string
          file_type?: string | null
          file_url: string
          voucher_id: string
        }
        Update: {
          asset_id?: string
          created_at?: string
          file_path?: string
          file_type?: string | null
          file_url?: string
          voucher_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "voucher_assets_voucher_id_fkey"
            columns: ["voucher_id"]
            isOneToOne: false
            referencedRelation: "vouchers"
            referencedColumns: ["voucher_id"]
          },
        ]
      }
      vouchers: {
        Row: {
          actual_amount_saved: number | null
          apply_mode: string | null
          border_style_id: string | null
          category: Database["public"]["Enums"]["category_type"] | null
          conditions: string | null
          created_at: string
          currency: string | null
          deal_type: Database["public"]["Enums"]["deal_type"] | null
          display_title: string | null
          expiry_date: string | null
          location: string | null
          logo_cache_updated_at: string | null
          logo_source: Database["public"]["Enums"]["logo_source_enum"]
          merchant: string
          merchant_domain: string | null
          merchant_logo_path: string | null
          personal_notes: string | null
          raw_text: string | null
          source: Database["public"]["Enums"]["source_type"] | null
          source_offer_id: string | null
          status: Database["public"]["Enums"]["status_type"] | null
          tags: string[] | null
          updated_at: string
          user_id: string
          valid_from: string | null
          value: number | null
          voucher_id: string
        }
        Insert: {
          actual_amount_saved?: number | null
          apply_mode?: string | null
          border_style_id?: string | null
          category?: Database["public"]["Enums"]["category_type"] | null
          conditions?: string | null
          created_at?: string
          currency?: string | null
          deal_type?: Database["public"]["Enums"]["deal_type"] | null
          display_title?: string | null
          expiry_date?: string | null
          location?: string | null
          logo_cache_updated_at?: string | null
          logo_source?: Database["public"]["Enums"]["logo_source_enum"]
          merchant: string
          merchant_domain?: string | null
          merchant_logo_path?: string | null
          personal_notes?: string | null
          raw_text?: string | null
          source?: Database["public"]["Enums"]["source_type"] | null
          source_offer_id?: string | null
          status?: Database["public"]["Enums"]["status_type"] | null
          tags?: string[] | null
          updated_at?: string
          user_id: string
          valid_from?: string | null
          value?: number | null
          voucher_id?: string
        }
        Update: {
          actual_amount_saved?: number | null
          apply_mode?: string | null
          border_style_id?: string | null
          category?: Database["public"]["Enums"]["category_type"] | null
          conditions?: string | null
          created_at?: string
          currency?: string | null
          deal_type?: Database["public"]["Enums"]["deal_type"] | null
          display_title?: string | null
          expiry_date?: string | null
          location?: string | null
          logo_cache_updated_at?: string | null
          logo_source?: Database["public"]["Enums"]["logo_source_enum"]
          merchant?: string
          merchant_domain?: string | null
          merchant_logo_path?: string | null
          personal_notes?: string | null
          raw_text?: string | null
          source?: Database["public"]["Enums"]["source_type"] | null
          source_offer_id?: string | null
          status?: Database["public"]["Enums"]["status_type"] | null
          tags?: string[] | null
          updated_at?: string
          user_id?: string
          valid_from?: string | null
          value?: number | null
          voucher_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "vouchers_border_style_id_fkey"
            columns: ["border_style_id"]
            isOneToOne: false
            referencedRelation: "border_styles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vouchers_source_offer_id_fkey"
            columns: ["source_offer_id"]
            isOneToOne: false
            referencedRelation: "affiliate_offers"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      compute_total_saved: {
        Args: { p_preferred_currency?: string; p_user_id: string }
        Returns: {
          has_mixed_currencies: boolean
          total: number
        }[]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "moderator" | "user"
      category_type: "food" | "fitness" | "travel" | "other"
      deal_type: "percentage" | "amount" | "bogo" | "other"
      logo_source_enum:
        | "uploaded"
        | "resolver"
        | "vision_crop"
        | "generated"
        | "none"
      source_type: "upload" | "screencap" | "video" | "email" | "manual"
      status_type: "active" | "used" | "expired"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "moderator", "user"],
      category_type: ["food", "fitness", "travel", "other"],
      deal_type: ["percentage", "amount", "bogo", "other"],
      logo_source_enum: [
        "uploaded",
        "resolver",
        "vision_crop",
        "generated",
        "none",
      ],
      source_type: ["upload", "screencap", "video", "email", "manual"],
      status_type: ["active", "used", "expired"],
    },
  },
} as const
