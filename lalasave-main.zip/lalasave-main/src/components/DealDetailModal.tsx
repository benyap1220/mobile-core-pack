import { motion, AnimatePresence } from "framer-motion";
import { X, Copy, ExternalLink } from "lucide-react";
import GradientButton from "./GradientButton";
import BrandAvatar from "./BrandAvatar";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { format, isPast, differenceInDays } from "date-fns";
import { getPlatformLogo, getPlatformName } from "@/lib/platformLogos";

interface DealDetails {
  deal_id: string;
  platform: string;
  platform_logo: string | null;
  title: string;
  subtitle: string;
  summary: string;
  tags: string[];
  conditions: string[];
  coupon_code: string;
  expires_at: string | null;
  image_url: string | null;
  deeplink_redirect: string | null;
  all_coupons?: Array<{
    id: string;
    code: string | null;
    benefit: string | null;
    title: string | null;
  }>;
}

interface DealDetailModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  dealDetails: DealDetails | null;
  position: number;
}

export default function DealDetailModal({ open, onOpenChange, dealDetails, position }: DealDetailModalProps) {
  const { toast } = useToast();

  if (!dealDetails) return null;

  const platformLogo = dealDetails.platform_logo || getPlatformLogo(dealDetails.platform);
  // Use platform directly from API (already cleaned)
  const platformName = dealDetails.platform;

  const getExpiryText = () => {
    if (!dealDetails.expires_at) return "No expiry";
    
    const expiry = new Date(dealDetails.expires_at);
    const daysLeft = differenceInDays(expiry, new Date());
    const isExpired = isPast(expiry);

    if (isExpired) return "Expired";
    if (daysLeft <= 7) return `Expires ${format(expiry, "d MMM")}`;
    return `Valid until ${format(expiry, "d MMM, yyyy")}`;
  };

  const handleCopyCoupon = (code: string) => {
    navigator.clipboard.writeText(code);
    toast({
      title: "Copied!",
      description: `Code ${code} copied to clipboard`,
    });
  };

  const handleUseOnline = () => {
    if (dealDetails.deeplink_redirect) {
      const deeplink_id = dealDetails.deeplink_redirect.split('/').pop();
      const redirectUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/go-deeplink/${deeplink_id}?pos=modal_${position}`;
      window.open(redirectUrl, '_blank');
    }
  };

  const conditionBullets = dealDetails.conditions?.filter((t: string) => t && t.trim()) || [];
  const allCoupons = dealDetails.all_coupons || [];

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => onOpenChange(false)}
            className="fixed inset-0 bg-black/40 z-40 backdrop-blur-sm"
          />

          {/* Sheet */}
          <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 30, stiffness: 300 }}
            className="fixed bottom-0 left-0 right-0 md:left-1/2 md:-translate-x-1/2 md:bottom-auto md:top-1/2 md:-translate-y-1/2 md:max-w-lg md:rounded-3xl z-40 glass border-gradient shadow-2xl flex flex-col h-[85vh]"
          >
            {/* Scrollable content with bottom padding for sticky CTA */}
            <div className="overflow-y-auto flex-1 pb-24">
              <div className="p-6">
                {/* Close Button */}
                <button
                  onClick={() => onOpenChange(false)}
                  className="absolute top-4 right-4 p-2 rounded-full hover:bg-muted/20 transition-colors"
                >
                  <X className="h-5 w-5" />
                </button>

                {/* Platform Logo & Name */}
                <div className="flex items-center gap-4 mb-6">
                  {platformLogo ? (
                    <img src={platformLogo} alt={platformName} className="h-12 w-12 rounded-lg object-contain" />
                  ) : (
                    <BrandAvatar merchant={platformName} size="md" />
                  )}
                  <div className="flex-1 min-w-0">
                    <h2 className="text-xl font-bold truncate">{platformName}</h2>
                    {dealDetails.subtitle && (
                      <p className="text-sm text-muted-foreground">{dealDetails.subtitle}</p>
                    )}
                  </div>
                </div>

                {/* Deal Benefit - Large Headline */}
                <div className="mb-4">
                  <h2 className="text-4xl font-bold gradient-text">
                    {dealDetails.title}
                  </h2>
                </div>

                {/* Expiry */}
                {dealDetails.expires_at && (
                  <div className="flex items-center gap-2 mb-6">
                    <Badge variant="outline" className="text-sm">
                      {getExpiryText()}
                    </Badge>
                  </div>
                )}

                {/* Coupon Code */}
                {dealDetails.coupon_code && (
                  <div className="glass rounded-2xl p-6 mb-6 text-center">
                    <div className="inline-block px-6 py-3 bg-white rounded-lg border-2 border-dashed border-muted mb-2">
                      <p className="text-2xl font-mono font-bold">{dealDetails.coupon_code}</p>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Show this code at checkout
                    </p>
                  </div>
                )}

                {/* Summary */}
                {dealDetails.summary && (
                  <p className="text-sm text-muted-foreground mb-6">{dealDetails.summary}</p>
                )}

                {/* Conditions */}
                {conditionBullets.length > 0 && (
                  <section className="mb-6">
                    <h3 className="text-sm font-semibold mb-2">Conditions</h3>
                    <ul className="space-y-1 list-disc list-inside text-sm text-muted-foreground">
                      {conditionBullets.map((line: string, i: number) => (
                        <li key={i}>{line}</li>
                      ))}
                    </ul>
                  </section>
                )}

                {/* Image */}
                {dealDetails.image_url && (
                  <img
                    src={dealDetails.image_url}
                    alt={dealDetails.title}
                    className="w-full rounded-lg mb-6 max-h-40 object-cover"
                  />
                )}

                {/* All Coupons Section */}
                {allCoupons.length > 0 && (
                  <div className="mb-6">
                    <p className="text-sm font-medium mb-2">All coupons ({allCoupons.length})</p>
                    <div className="space-y-2">
                      {allCoupons.map((coupon: any, idx: number) => (
                        <button
                          key={idx}
                          onClick={() => coupon.code && handleCopyCoupon(coupon.code)}
                          className="w-full text-left p-3 glass rounded-lg hover:bg-muted/10 transition-colors"
                        >
                          <p className="text-sm font-semibold">{coupon.benefit || coupon.title}</p>
                          {coupon.code && (
                            <p className="text-xs font-mono text-muted-foreground mt-1">{coupon.code}</p>
                          )}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Fixed footer with CTA - always visible */}
            <div className="fixed bottom-0 left-0 right-0 z-20 bg-background border-t p-6">
              <GradientButton
                onClick={handleUseOnline}
                className="w-full flex items-center justify-center gap-2"
              >
                Shop on {platformName}
                <ExternalLink className="w-4 h-4" />
              </GradientButton>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
