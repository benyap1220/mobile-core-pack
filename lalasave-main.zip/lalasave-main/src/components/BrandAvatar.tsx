import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { canonicalBrandSlug, slugifyMerchant } from "@/lib/slugifyMerchant";
import { getBrandOverride } from "@/lib/brandOverrides";

interface BrandAvatarProps {
  merchant: string;
  domain?: string;
  size?: "sm" | "md" | "lg";
  className?: string;
}

const sizeClasses = {
  sm: "w-12 h-12 text-sm",
  md: "w-16 h-16 text-lg",
  lg: "w-20 h-20 text-xl",
};

export default function BrandAvatar({ 
  merchant, 
  domain, 
  size = "sm",
  className = ""
}: BrandAvatarProps) {
  const [logoUrl, setLogoUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [retryCount, setRetryCount] = useState(0);
  
  const initial = (merchant || "?").trim().charAt(0).toUpperCase();
  const slug = canonicalBrandSlug(merchant || "");
  
  // PRIORITY 1: Check hard-coded overrides (no network call needed)
  const override = getBrandOverride(slug);

  useEffect(() => {
    let cancelled = false;

    async function fetchLogo() {
      if (!merchant || !slug) {
        setLoading(false);
        return;
      }

      // If we have a hard override, use it immediately (no async needed)
      if (override) {
        setLogoUrl(override.url);
        setLoading(false);
        return;
      }

      setLoading(true);

      try {
        // 1) Check database override
        const { data: dbOverride } = await supabase
          .from("brand_logo_overrides")
          .select("storage_path")
          .eq("brand_slug", slug)
          .maybeSingle();

        if (!cancelled && dbOverride?.storage_path) {
          const { data: pub } = supabase.storage
            .from("brand-logos")
            .getPublicUrl(dbOverride.storage_path);
          
          setLogoUrl(pub.publicUrl);
          setLoading(false);
          return;
        }

        // 2) Check cache
        const { data: cached } = await supabase
          .from("merchant_logo_cache")
          .select("public_url")
          .eq("merchant_slug", slug)
          .maybeSingle();

        if (!cancelled && cached?.public_url) {
          setLogoUrl(cached.public_url);
          setLoading(false);
          return;
        }

        // 3) Call resolve-logo edge function
        const res = await fetch(
          "https://cnayuxiwjgpjrzkphhwz.supabase.co/functions/v1/resolve-logo",
          {
            method: "POST",
            headers: { 
              "Content-Type": "application/json",
              "apikey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNuYXl1eGl3amdwanJ6a3BoaHd6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTk2NzM4MDYsImV4cCI6MjA3NTI0OTgwNn0.ZA_6hIEYMQCDRGvyvmc3x-xTFg_MOhgKiZvmZ9TBWJI"
            },
            body: JSON.stringify({ 
              slug,
              domain,
              force: retryCount > 0
            }),
          }
        );
        
        const data = await res.json();
        
        if (!cancelled && data?.publicUrl) {
          setLogoUrl(data.publicUrl);
        }
        if (!cancelled) {
          setLoading(false);
        }
      } catch (err) {
        console.error('[BrandAvatar] Error:', err);
        if (!cancelled) {
          setLoading(false);
        }
      }
    }

    const timer = setTimeout(fetchLogo, 120);
    
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [merchant, domain, slug, retryCount, override]);

  const handleImageError = () => {
    if (retryCount === 0) {
      // Retry once with force
      setRetryCount(1);
    } else {
      // Fallback to gradient initial
      setLogoUrl(null);
    }
  };

  // Get pixel size for srcSet
  const pixelSize = size === "sm" ? 48 : size === "md" ? 64 : 80;
  
  return logoUrl ? (
    <img
      src={logoUrl}
      srcSet={`${logoUrl} 1x, ${logoUrl} 2x`}
      alt={`${merchant} logo`}
      width={pixelSize}
      height={pixelSize}
      className={`${sizeClasses[size]} ${className} rounded-xl object-contain p-1 bg-white/80 ring-2 ring-white shadow-sm flex-none`}
      loading="lazy"
      decoding="async"
      onError={handleImageError}
    />
  ) : (
    <div
      className={`${sizeClasses[size]} ${className} rounded-xl grid place-items-center text-white font-semibold shadow-sm flex-none`}
      style={{
        background: "linear-gradient(135deg, #5B8EFF, #09C6F9)",
      }}
      aria-label={`${merchant} initial`}
      role="img"
    >
      {loading ? "…" : initial}
    </div>
  );
}
