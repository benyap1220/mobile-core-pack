import { motion, useMotionValue, useTransform } from "framer-motion";
import { Trash2 } from "lucide-react";
import { ReactNode } from "react";

interface SwipeToActionRowProps {
  children: ReactNode;
  onRemove: () => void;
  rightThreshold?: number;
}

export default function SwipeToActionRow({
  children,
  onRemove,
  rightThreshold = 120,
}: SwipeToActionRowProps) {
  const x = useMotionValue(0);
  const background = useTransform(
    x,
    [0, rightThreshold],
    ["rgba(239, 68, 68, 0)", "rgba(239, 68, 68, 0.9)"]
  );
  const iconScale = useTransform(x, [0, rightThreshold], [0.8, 1]);
  const iconOpacity = useTransform(x, [0, rightThreshold], [0, 1]);

  const handleDragEnd = () => {
    const draggedX = x.get();
    if (draggedX > rightThreshold) {
      onRemove();
    } else {
      x.set(0);
    }
  };

  return (
    <div className="relative overflow-hidden rounded-2xl">
      {/* Red background layer */}
      <motion.div
        style={{ background }}
        className="absolute inset-0 flex items-center justify-end px-6"
      >
        <motion.div style={{ scale: iconScale, opacity: iconOpacity }}>
          <Trash2 className="h-6 w-6 text-white" />
        </motion.div>
      </motion.div>

      {/* Draggable card */}
      <motion.div
        drag="x"
        dragConstraints={{ left: 0, right: 200 }}
        dragElastic={0.2}
        style={{ x }}
        onDragEnd={handleDragEnd}
        exit={{ opacity: 0, x: 300, transition: { duration: 0.18 } }}
        layout
        className="relative bg-white"
      >
        {children}
      </motion.div>
    </div>
  );
}
