import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

interface LogoProps {
  storagePath?: string | null;
  merchant: string;
  size?: "sm" | "md" | "lg";
}

const sizeClasses = {
  sm: "w-12 h-12 text-sm",
  md: "w-16 h-16 text-lg",
  lg: "w-20 h-20 text-xl",
};

export default function Logo({ storagePath, merchant, size = "sm" }: LogoProps) {
  const [signedUrl, setSignedUrl] = useState<string | null>(null);
  const [errored, setErrored] = useState(false);
  const [retryCount, setRetryCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;

    async function fetchSignedUrl() {
      if (!storagePath) {
        setSignedUrl(null);
        setLoading(false);
        setErrored(false);
        return;
      }

      setLoading(true);

      try {
        const { data, error } = await supabase.storage
          .from("logos")
          .createSignedUrl(storagePath, 7200); // 2 hours

        if (error) {
          console.error("Signed URL error:", error);
          throw error;
        }

        if (isMounted && data?.signedUrl) {
          setSignedUrl(data.signedUrl);
          setErrored(false);
          setLoading(false);
        }
      } catch (error) {
        console.error("Failed to create signed URL for", storagePath, ":", error);
        if (isMounted) {
          setSignedUrl(null);
          setErrored(true);
          setLoading(false);
        }
      }
    }

    fetchSignedUrl();

    // Refresh every 90 minutes to stay ahead of expiry
    const refreshInterval = setInterval(fetchSignedUrl, 90 * 60 * 1000);

    return () => {
      isMounted = false;
      clearInterval(refreshInterval);
    };
  }, [storagePath]);

  const handleError = () => {
    // Retry once on error
    if (retryCount < 1) {
      setRetryCount((prev) => prev + 1);
      // Force refresh by clearing and re-fetching
      setSignedUrl(null);
      setTimeout(() => {
        if (storagePath) {
          supabase.storage
            .from("logos")
            .createSignedUrl(storagePath, 3600)
            .then(({ data }) => {
              if (data?.signedUrl) {
                setSignedUrl(data.signedUrl);
              } else {
                setErrored(true);
              }
            })
            .catch(() => setErrored(true));
        }
      }, 100);
    } else {
      setErrored(true);
    }
  };

  const firstLetter = merchant?.[0]?.toUpperCase() || "?";

  return (
    <div
      className={`${sizeClasses[size]} flex-none rounded-xl overflow-hidden bg-white/80 ring-2 ring-white shadow-sm relative`}
    >
      {loading && storagePath && !errored && (
        <div className="absolute inset-0 bg-muted/20 backdrop-blur-sm grid place-items-center">
          <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
        </div>
      )}
      {signedUrl && !errored && !loading ? (
        <img
          src={signedUrl}
          alt={`${merchant} logo`}
          className="w-full h-full object-contain p-1"
          onError={handleError}
          loading="lazy"
        />
      ) : (
        <div className="w-full h-full grid place-items-center font-semibold bg-gradient-to-br from-sky-400 to-blue-600 text-white">
          {firstLetter}
        </div>
      )}
    </div>
  );
}
