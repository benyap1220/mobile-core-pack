import { motion, AnimatePresence } from "framer-motion";
import { X } from "lucide-react";
import { useState } from "react";
import GradientButton from "./GradientButton";
import { Slider } from "./ui/slider";
import { Checkbox } from "./ui/checkbox";
import { Label } from "./ui/label";
import { Input } from "./ui/input";

interface FiltersSheetProps {
  isOpen: boolean;
  onClose: () => void;
  onApply: (filters: FilterState) => void;
  currentFilters: FilterState;
}

export interface FilterState {
  status: string[];
  categories: string[];
  merchant: string;
  daysLeft: number[];
}

const statusOptions = [
  { value: "active", label: "Active" },
  { value: "expiring", label: "Expiring ≤7d" },
  { value: "expired", label: "Expired" },
  { value: "used", label: "Used" },
];

const categoryOptions = [
  { value: "food", label: "Food" },
  { value: "shopping", label: "Shopping" },
  { value: "fitness", label: "Fitness" },
  { value: "travel", label: "Travel" },
  { value: "other", label: "Other" },
];

export default function FiltersSheet({
  isOpen,
  onClose,
  onApply,
  currentFilters,
}: FiltersSheetProps) {
  const [filters, setFilters] = useState<FilterState>(currentFilters);

  const handleApply = () => {
    onApply(filters);
    onClose();
  };

  const handleClear = () => {
    const emptyFilters: FilterState = {
      status: [],
      categories: [],
      merchant: "",
      daysLeft: [0, 30],
    };
    setFilters(emptyFilters);
    onApply(emptyFilters);
    onClose();
  };

  const toggleStatus = (value: string) => {
    setFilters((prev) => ({
      ...prev,
      status: prev.status.includes(value)
        ? prev.status.filter((s) => s !== value)
        : [...prev.status, value],
    }));
  };

  const toggleCategory = (value: string) => {
    setFilters((prev) => ({
      ...prev,
      categories: prev.categories.includes(value)
        ? prev.categories.filter((c) => c !== value)
        : [...prev.categories, value],
    }));
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/40 z-50 backdrop-blur-sm"
          />

          {/* Sheet */}
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 30, stiffness: 300 }}
            className="fixed right-0 top-0 bottom-0 w-full max-w-md z-50 glass border-l border-white/20 shadow-2xl overflow-y-auto"
          >
            <div className="p-6 space-y-6">
              {/* Header */}
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold">Filters</h2>
                <button
                  onClick={onClose}
                  className="p-2 rounded-full hover:bg-muted/20 transition-colors"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              {/* Status */}
              <div className="space-y-3">
                <Label className="text-sm font-medium">Status</Label>
                <div className="space-y-2">
                  {statusOptions.map((option) => (
                    <div key={option.value} className="flex items-center gap-2">
                      <Checkbox
                        id={`status-${option.value}`}
                        checked={filters.status.includes(option.value)}
                        onCheckedChange={() => toggleStatus(option.value)}
                      />
                      <Label
                        htmlFor={`status-${option.value}`}
                        className="text-sm cursor-pointer"
                      >
                        {option.label}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Category */}
              <div className="space-y-3">
                <Label className="text-sm font-medium">Category</Label>
                <div className="space-y-2">
                  {categoryOptions.map((option) => (
                    <div key={option.value} className="flex items-center gap-2">
                      <Checkbox
                        id={`category-${option.value}`}
                        checked={filters.categories.includes(option.value)}
                        onCheckedChange={() => toggleCategory(option.value)}
                      />
                      <Label
                        htmlFor={`category-${option.value}`}
                        className="text-sm cursor-pointer"
                      >
                        {option.label}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Merchant */}
              <div className="space-y-3">
                <Label htmlFor="merchant" className="text-sm font-medium">
                  Merchant
                </Label>
                <Input
                  id="merchant"
                  placeholder="Type merchant name..."
                  value={filters.merchant}
                  onChange={(e) =>
                    setFilters((prev) => ({ ...prev, merchant: e.target.value }))
                  }
                />
              </div>

              {/* Days Left Slider */}
              <div className="space-y-3">
                <Label className="text-sm font-medium">
                  Days Left: {filters.daysLeft[0]}–{filters.daysLeft[1]}
                </Label>
                <Slider
                  min={0}
                  max={30}
                  step={1}
                  value={filters.daysLeft}
                  onValueChange={(value) =>
                    setFilters((prev) => ({ ...prev, daysLeft: value }))
                  }
                  className="w-full"
                />
              </div>

              {/* Actions */}
              <div className="flex gap-3 pt-4">
                <button
                  onClick={handleClear}
                  className="flex-1 glass rounded-2xl px-5 py-3 hover:shadow-md transition-shadow"
                >
                  Clear
                </button>
                <GradientButton onClick={handleApply} className="flex-1">
                  Apply
                </GradientButton>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
