import { Card } from "@/components/ui/card";
import VoucherBorder from "./VoucherBorder";
import { ExternalLink, Bookmark, Check } from "lucide-react";
import GradientButton from "./GradientButton";
import { Button } from "@/components/ui/button";

interface BorderPreviewProps {
  prototypeId: string;
  previewPath: string;
  layoutMode?: string;
  replaceBaseFrame?: boolean;
  contentInset?: number;
}

export default function BorderPreview({ 
  prototypeId,
  previewPath, 
  layoutMode = "full-frame",
  replaceBaseFrame = false,
  contentInset = 0
}: BorderPreviewProps) {
  // Clean Grab voucher mock for preview
  const grabPreview = {
    brand: 'Grab',
    category: 'Grab',
    title: 'RM5 OFF Rides',
    subtitle: 'Save RM5 on your next GrabCar ride',
    chips: ['Valid for rides above RM15', 'One use per week'],
    code: 'GRAB5',
    expiry: 'Expires 13 Oct',
    logo: '/brand-logos/lazada-official.png', // Using existing asset as placeholder
  };

  return (
    <div className="space-y-3">
      <p className="text-sm font-medium text-muted-foreground">
        {replaceBaseFrame ? 'Frame Replacement Preview' : 'Overlay Preview'}
      </p>
      {replaceBaseFrame && (
        <p className="text-xs text-amber-600 font-medium">
          ⚠️ Blue base frame is replaced by border art
        </p>
      )}
      <div className="relative">
        <Card className="relative overflow-hidden card--frame-off">
          {/* Optional background image (allowed) */}
          {/* <img src="/bg/your-image.webp" alt="" className="voucher-bg" /> */}
          
          {/* Decorative border overlay */}
          <VoucherBorder 
            borderStyleId={prototypeId}
            sourceTable="border_prototypes"
            hideBaseFrame
          />
          
          <div className="voucher-content relative z-10" style={{ paddingLeft: '16px', paddingRight: '16px' }}>
            {/* Header Row - Logo + Brand (left) and Expiry (right) */}
            <div className="flex items-start justify-between gap-3 mb-2">
              <div className="flex items-center gap-3 min-w-0">
                <img src={grabPreview.logo} alt="Grab" className="w-10 h-10 shrink-0 rounded-lg object-cover" />
                <div className="min-w-0">
                  <h3 className="font-semibold text-base truncate uppercase tracking-wide">{grabPreview.brand}</h3>
                  <p className="text-xs text-muted-foreground">{grabPreview.category}</p>
                </div>
              </div>
              <span className="px-2 py-1 text-xs font-medium rounded-full bg-rose-500 text-white whitespace-nowrap">
                {grabPreview.expiry}
              </span>
            </div>

            {/* All content below is left-aligned */}
            <div className="space-y-2">
              {/* Headline */}
              <h2 className="text-lg font-bold leading-tight">{grabPreview.title}</h2>
              
              {/* Subcopy */}
              <p className="text-sm text-muted-foreground">{grabPreview.subtitle}</p>

              {/* Condition Chips */}
              <div className="flex flex-wrap gap-1">
                {grabPreview.chips.map((c, i) => (
                  <span key={i} className="px-2 py-1 rounded-full text-xs bg-pink-50 text-pink-700 border border-pink-200">
                    {c}
                  </span>
                ))}
              </div>

              {/* Code Box */}
              <div className="rounded-xl px-4 py-2 flex items-center justify-between bg-muted/60 max-w-[180px]">
                <span className="font-semibold text-base tracking-wide">{grabPreview.code}</span>
                <svg className="w-4 h-4 text-muted-foreground" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
                  <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
                </svg>
              </div>

              {/* CTA Button and Action Icons */}
              <div className="flex gap-2 mt-3">
                <GradientButton className="flex-1 flex items-center justify-center gap-2">
                  Order on {grabPreview.brand}
                  <ExternalLink className="w-4 h-4" />
                </GradientButton>
                <div className="flex flex-col gap-1">
                  <Button
                    variant="outline"
                    size="sm"
                    className="px-3"
                    aria-label="Save voucher"
                  >
                    <Bookmark className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="px-3"
                    aria-label="Mark as used"
                  >
                    <Check className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
