import { useRef } from "react";
import { Upload, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { useLogoResolver } from "@/hooks/useLogoResolver";
import Logo from "@/components/Logo";

interface LogoUploadProps {
  voucherId: string;
  merchant: string;
  domain?: string;
  currentLogoUrl?: string | null;
  onLogoUpdated: (logoUrl: string) => void;
}

export default function LogoUpload({
  voucherId,
  merchant,
  domain,
  currentLogoUrl,
  onLogoUpdated,
}: LogoUploadProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { uploadManualLogo, resolveLogo, isResolving } = useLogoResolver();

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const logoUrl = await uploadManualLogo(voucherId, file);
    if (logoUrl) {
      onLogoUpdated(logoUrl);
    }
  };

  const handleTryAgain = async () => {
    const result = await resolveLogo(voucherId, merchant, domain, undefined, true);
    if (result?.logoPath) {
      onLogoUpdated(result.logoPath);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4">
        <div>
          <Label className="text-sm mb-2 block">Merchant Logo</Label>
          <Logo storagePath={currentLogoUrl} merchant={merchant} size="md" />
        </div>
        <div className="flex-1 space-y-2">
          <div className="flex gap-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => fileInputRef.current?.click()}
            >
              <Upload className="h-4 w-4 mr-2" />
              Upload
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={handleTryAgain}
              disabled={isResolving}
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${isResolving ? 'animate-spin' : ''}`} />
              Try Again
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">
            Logo auto-resolves when you change merchant name
          </p>
        </div>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleFileChange}
      />
    </div>
  );
}
