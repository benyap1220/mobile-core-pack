import { motion } from "framer-motion";
import { ChevronRight } from "lucide-react";

interface Voucher {
  voucher_id: string;
  merchant: string;
  deal_type: string;
  value: number | null;
  currency: string;
  category: string;
  expiry_date: string | null;
  apply_mode?: string;
}

interface ExpiringSoonProps {
  vouchers: Voucher[];
  onVoucherClick: (voucherId: string) => void;
}

const getExpiryDays = (expiryDate: string | null) => {
  if (!expiryDate) return null;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const expiry = new Date(expiryDate);
  expiry.setHours(0, 0, 0, 0);
  return Math.ceil((expiry.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
};

const getDaysLeftPillColor = (days: number | null) => {
  if (days === null) return "bg-muted text-muted-foreground";
  if (days < 0) return "bg-destructive text-white";
  if (days <= 3) return "bg-destructive text-white";
  if (days <= 7) return "bg-warning text-white";
  return "bg-success text-white";
};

const getApplyModeBadge = (mode?: string) => {
  if (!mode || mode === "manual") return null;
  if (mode === "auto")
    return {
      text: "Auto-apply",
      tooltip: "Discount applies automatically at checkout.",
      color: "bg-accent/10 text-accent border-accent/20",
    };
  if (mode === "added_to_card")
    return {
      text: "Added",
      tooltip: "Offer linked to your card/account.",
      color: "bg-success/10 text-success border-success/20",
    };
  return null;
};

const getMerchantInitial = (merchant: string) => {
  return merchant.charAt(0).toUpperCase();
};

const formatDiscount = (dealType: string, value: number | null, currency: string) => {
  if (dealType === "percentage" && value) {
    return `${value}% off`;
  }
  if (dealType === "fixed" && value) {
    return `${currency} ${value} off`;
  }
  return dealType;
};

export default function ExpiringSoon({ vouchers, onVoucherClick }: ExpiringSoonProps) {
  if (vouchers.length === 0) return null;

  return (
    <div className="mb-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold">Expiring Soon</h3>
        <button className="text-sm text-accent flex items-center gap-1 hover:underline">
          View all
          <ChevronRight className="h-4 w-4" />
        </button>
      </div>

      <div className="flex gap-4 overflow-x-auto pb-4 -mx-4 px-4 scrollbar-hide">
        {vouchers.map((voucher, index) => {
          const days = getExpiryDays(voucher.expiry_date);
          const badge = getApplyModeBadge(voucher.apply_mode);

          return (
            <motion.div
              key={voucher.voucher_id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.04 }}
              whileHover={{ y: -2 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => onVoucherClick(voucher.voucher_id)}
              className="glass border-gradient rounded-2xl p-4 min-w-[280px] sm:min-w-[320px] cursor-pointer hover:shadow-lg transition-shadow relative"
            >
              {/* Apply Mode Badge */}
              {badge && (
                <div
                  className={`absolute top-3 right-3 text-xs px-2 py-1 rounded-full border ${badge.color}`}
                  title={badge.tooltip}
                >
                  {badge.text}
                </div>
              )}

              {/* Merchant Avatar */}
              <div className="flex items-start gap-3 mb-3">
                <div className="w-12 h-12 blue-gradient rounded-full flex items-center justify-center text-white font-bold text-lg shadow-md">
                  {getMerchantInitial(voucher.merchant)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold truncate">{voucher.merchant}</p>
                  <p className="text-xs text-muted-foreground capitalize">
                    {voucher.category}
                  </p>
                </div>
              </div>

              {/* Discount */}
              <div className="mb-3">
                <p className="text-2xl font-bold gradient-text">
                  {formatDiscount(voucher.deal_type, voucher.value, voucher.currency)}
                </p>
              </div>

              {/* Days Left Pill */}
              <div className="flex items-center justify-between">
                <span
                  className={`text-xs px-3 py-1 rounded-full font-medium ${getDaysLeftPillColor(
                    days
                  )}`}
                >
                  {days === null
                    ? "No expiry"
                    : days < 0
                    ? "Expired"
                    : `${days}d left`}
                </span>
                <button className="text-sm text-accent font-medium hover:underline">
                  Use now
                </button>
              </div>
            </motion.div>
          );
        })}
      </div>

      <style>{`
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
    </div>
  );
}
