import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

interface SafeArea {
  top: number;
  right: number;
  bottom: number;
  left: number;
}

interface FrameMeta {
  viewW: number;
  viewH: number;
  cornerRadius: number;
  contentInset: number;
  outerInset: number;
  hadFrameRemoved: boolean;
}

interface BorderStyle {
  id: string;
  svg_path: string | null;
  webm_path: string | null;
  lottie_path: string | null;
  image_path: string | null;
  scale_mode: string | null;
  style_tag: string | null;
  layout_mode: string | null;
  safe_area: SafeArea | null;
  suggested_rotation: number | null;
  replace_base_frame: boolean | null;
  frame_meta: FrameMeta | null;
}

interface VoucherBorderProps {
  borderStyleId?: string | null;
  merchant?: string;
  offerTitle?: string;
  className?: string;
  hideBaseFrame?: boolean; // Control whether to hide blue base frame
  contentPadding?: number; // Apply content inset from frame
  sourceTable?: "border_styles" | "border_prototypes"; // Which table to query
  target?: 'deals' | 'home'; // Target shape for border filtering
}

export default function VoucherBorder({
  borderStyleId,
  merchant,
  offerTitle,
  className = "",
  hideBaseFrame,
  contentPadding,
  sourceTable = "border_styles",
  target = 'deals',
}: VoucherBorderProps) {
  const [borderStyle, setBorderStyle] = useState<BorderStyle | null>(null);
  const [loading, setLoading] = useState(true);
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);

  useEffect(() => {
    // Check for reduced motion preference
    const mediaQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
    setPrefersReducedMotion(mediaQuery.matches);

    const handler = (e: MediaQueryListEvent) => setPrefersReducedMotion(e.matches);
    mediaQuery.addEventListener("change", handler);
    return () => mediaQuery.removeEventListener("change", handler);
  }, []);

  useEffect(() => {
    const fetchBorderStyle = async () => {
      try {
        let style: BorderStyle | null = null;

        if (borderStyleId) {
          // Use specific border style from the specified table
          const { data, error } = await supabase
            .from(sourceTable)
            .select("*")
            .eq("id", borderStyleId)
            .eq("target", target)
            .maybeSingle();
          
          if (error) {
            console.error("Error fetching border style:", error);
            return;
          }
          
          if (data) {
            // Parse safe_area and frame_meta if they're JSON strings
            style = {
              ...data,
              safe_area: typeof data.safe_area === 'string'
                ? JSON.parse(data.safe_area)
                : data.safe_area,
              frame_meta: typeof data.frame_meta === 'string'
                ? JSON.parse(data.frame_meta)
                : data.frame_meta,
            };
          }
        } else if (merchant || offerTitle) {
          // Deterministic selection based on merchant/offer
          const { data: styles } = await supabase
            .from("border_styles")
            .select("*")
            .eq("target", target);

          if (styles && styles.length > 0) {
            // Hash merchant + offer title to pick consistent border
            const seed = `${merchant || ""}${offerTitle || ""}`;
            let hash = 0;
            for (let i = 0; i < seed.length; i++) {
              hash = ((hash << 5) - hash) + seed.charCodeAt(i);
              hash = hash & hash;
            }
            const index = Math.abs(hash) % styles.length;
            const selected = styles[index];
            
            // Parse safe_area and frame_meta if they're JSON strings
            style = {
              ...selected,
              safe_area: typeof selected.safe_area === 'string' 
                ? JSON.parse(selected.safe_area)
                : selected.safe_area,
              frame_meta: typeof selected.frame_meta === 'string'
                ? JSON.parse(selected.frame_meta)
                : selected.frame_meta,
            };
          }
        }

        setBorderStyle(style);
      } catch (error) {
        console.error("Error fetching border style:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchBorderStyle();
  }, [borderStyleId, merchant, offerTitle, target, sourceTable]);

  if (loading || !borderStyle) {
    return null;
  }

  const baseUrl = import.meta.env.VITE_SUPABASE_URL;
  const layoutMode = borderStyle.layout_mode || 'full-frame';
  const safeArea = borderStyle.safe_area || { top: 16, right: 16, bottom: 16, left: 16 };
  const replaceBaseFrame = hideBaseFrame ?? borderStyle.replace_base_frame ?? false;
  const contentInset = contentPadding ?? borderStyle.frame_meta?.contentInset ?? 0;

  // Get position styles based on layout mode
  const getLayoutStyles = () => {
    switch (layoutMode) {
      case 'right-rail':
        return {
          right: 0,
          top: `${safeArea.top}px`,
          bottom: `${safeArea.bottom}px`,
          width: '40%',
          height: 'auto',
        };
      case 'left-rail':
        return {
          left: 0,
          top: `${safeArea.top}px`,
          bottom: `${safeArea.bottom}px`,
          width: '40%',
          height: 'auto',
        };
      case 'top-rail':
        return {
          top: 0,
          left: `${safeArea.left}px`,
          right: `${safeArea.right}px`,
          height: '40%',
          width: 'auto',
        };
      case 'bottom-rail':
        return {
          bottom: 0,
          left: `${safeArea.left}px`,
          right: `${safeArea.right}px`,
          height: '40%',
          width: 'auto',
        };
      case 'corners':
        return {
          inset: `${safeArea.top}px ${safeArea.right}px ${safeArea.bottom}px ${safeArea.left}px`,
        };
      case 'full-frame':
      default:
        return {
          inset: 0,
        };
    }
  };

  const layoutStyles = getLayoutStyles();

  // CSS variables for safe area padding (consumed by parent content containers)
  const cssVars: React.CSSProperties = {
    ['--vb-safe-top' as any]: `${safeArea.top || contentInset || 18}px`,
    ['--vb-safe-right' as any]: `${safeArea.right || contentInset || 18}px`,
    ['--vb-safe-bottom' as any]: `${safeArea.bottom || contentInset || 18}px`,
    ['--vb-safe-left' as any]: `${safeArea.left || contentInset || 18}px`,
  };

  // Priority 1: Render PNG border (simplified system)
  if (borderStyle.image_path) {
    const scaleMode = borderStyle.scale_mode || 'cover';
    return (
      <div 
        className="absolute pointer-events-none" 
        style={{
          inset: '-32px', // Extends 32px beyond card edges - decorative border becomes the frame
          ...cssVars
        }} 
        aria-hidden="true"
      >
        <img
          src={`${baseUrl}/storage/v1/object/public/borders/${borderStyle.image_path}?v=${borderStyle.id}`}
          alt=""
          className={`absolute inset-0 w-full h-full pointer-events-none ${className}`}
          style={{
            objectFit: scaleMode as any,
            zIndex: 3,
            // NO padding - border extends to edges and becomes the visual frame
          }}
          aria-hidden="true"
        />
      </div>
    );
  }

  // Priority 2: Render SVG border (legacy system)
  if (borderStyle.svg_path) {
    return (
      <div className="absolute inset-0 pointer-events-none" style={cssVars} aria-hidden="true">
        <img
          src={`${baseUrl}/storage/v1/object/public/borders/${borderStyle.svg_path}?v=${borderStyle.id}`}
          alt=""
          className={`absolute inset-0 w-full h-full pointer-events-none ${className}`}
          style={{ 
            zIndex: 3, // Overlay above everything so decorative art is visually dominant
          }}
          aria-hidden="true"
        />
      </div>
    );
  }

  // Render video border (animated) - fallback
  if (borderStyle.webm_path && !prefersReducedMotion) {
    return (
      <div
        className={`absolute pointer-events-none overflow-hidden rounded-2xl ${className}`}
        style={{
          inset: 0,
          ...cssVars,
        }}
        aria-hidden="true"
      >
        <video
          src={`${baseUrl}/storage/v1/object/public/borders/${borderStyle.webm_path}`}
          autoPlay
          loop
          muted
          playsInline
          className="w-full h-full object-cover opacity-60"
          style={{ zIndex: 1 }}
        />
      </div>
    );
  }

  // No border
  return null;
}
