import { useState } from "react";
import { ChevronDown, Calendar as CalendarIcon } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { cn } from "@/lib/utils";
import { TimeframePreset, getTimeframeLabel, DateRange } from "@/lib/dateRanges";
import { format } from "date-fns";

interface TimeframeChipProps {
  value: TimeframePreset;
  customRange?: DateRange;
  onChange: (preset: TimeframePreset, customRange?: DateRange) => void;
}

export default function TimeframeChip({ value, customRange, onChange }: TimeframeChipProps) {
  const [open, setOpen] = useState(false);
  const [showCustomPicker, setShowCustomPicker] = useState(false);
  const [customFrom, setCustomFrom] = useState<Date | undefined>(customRange?.from);
  const [customTo, setCustomTo] = useState<Date | undefined>(customRange?.to);

  const handlePresetSelect = (preset: TimeframePreset) => {
    if (preset === 'custom') {
      setShowCustomPicker(true);
    } else {
      onChange(preset);
      setOpen(false);
      setShowCustomPicker(false);
    }
  };

  const handleCustomApply = () => {
    if (customFrom && customTo) {
      onChange('custom', { from: customFrom, to: customTo });
      setOpen(false);
      setShowCustomPicker(false);
    }
  };

  const presets: { value: TimeframePreset; label: string }[] = [
    { value: 'all', label: 'All time' },
    { value: 'month', label: 'This month' },
    { value: '30d', label: 'Last 30 days' },
    { value: 'year', label: 'This year' },
    { value: 'custom', label: 'Custom…' },
  ];

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          className="h-6 px-2 text-xs text-muted-foreground hover:text-foreground gap-1"
        >
          {getTimeframeLabel(value, customRange)}
          <ChevronDown className="h-3 w-3" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0" align="end">
        <AnimatePresence mode="wait">
          {!showCustomPicker ? (
            <motion.div
              key="presets"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.18 }}
              className="p-2 space-y-1"
            >
              {presets.map((preset) => (
                <Button
                  key={preset.value}
                  variant={value === preset.value ? "secondary" : "ghost"}
                  size="sm"
                  className="w-full justify-start text-sm"
                  onClick={() => handlePresetSelect(preset.value)}
                >
                  {preset.label}
                </Button>
              ))}
            </motion.div>
          ) : (
            <motion.div
              key="custom"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.18 }}
              className="p-3 space-y-3"
            >
              <div className="space-y-2">
                <label className="text-xs font-medium">From</label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !customFrom && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {customFrom ? format(customFrom, "PPP") : <span>Pick a date</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={customFrom}
                      onSelect={setCustomFrom}
                      initialFocus
                      className="pointer-events-auto"
                    />
                  </PopoverContent>
                </Popover>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-medium">To</label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !customTo && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {customTo ? format(customTo, "PPP") : <span>Pick a date</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={customTo}
                      onSelect={setCustomTo}
                      initialFocus
                      className="pointer-events-auto"
                    />
                  </PopoverContent>
                </Popover>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="flex-1"
                  onClick={() => setShowCustomPicker(false)}
                >
                  Back
                </Button>
                <Button
                  size="sm"
                  className="flex-1"
                  onClick={handleCustomApply}
                  disabled={!customFrom || !customTo}
                >
                  Apply
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </PopoverContent>
    </Popover>
  );
}
