import { motion } from "framer-motion";
import { useState, useEffect } from "react";
import { useCurrencyPrefs } from "@/hooks/useCurrencyPrefs";
import { formatMoney } from "@/lib/currency";
import { TimeframePreset, DateRange, getTimeframeLabel } from "@/lib/dateRanges";
import TimeframeChip from "./TimeframeChip";

interface HeroWalletProps {
  totalSavings: number;
  expiringThisWeek: number;
  autoApplyCount: number;
  timeframe: TimeframePreset;
  customRange?: DateRange;
  hasMixedCurrencies: boolean;
  onTimeframeChange: (preset: TimeframePreset, customRange?: DateRange) => void;
}

export default function HeroWallet({
  totalSavings,
  expiringThisWeek,
  autoApplyCount,
  timeframe,
  customRange,
  hasMixedCurrencies,
  onTimeframeChange,
}: HeroWalletProps) {
  const [animatedSavings, setAnimatedSavings] = useState(0);
  const { prefs } = useCurrencyPrefs();

  useEffect(() => {
    const duration = 600;
    const steps = 30;
    const increment = totalSavings / steps;
    let current = 0;

    const timer = setInterval(() => {
      current += increment;
      if (current >= totalSavings) {
        setAnimatedSavings(totalSavings);
        clearInterval(timer);
      } else {
        setAnimatedSavings(Math.floor(current));
      }
    }, duration / steps);

    return () => clearInterval(timer);
  }, [totalSavings]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass border-gradient rounded-3xl shadow-lg p-4 sm:p-6 sticky top-[64px] z-20 mb-6"
    >
      {/* Blue gradient overlay */}
      <div
        className="absolute inset-0 rounded-3xl pointer-events-none opacity-10"
        style={{
          background:
            "radial-gradient(600px 300px at 70% 0%, rgba(45,168,255,0.3), transparent 60%)",
        }}
      />

      <div className="relative">
        {/* Header */}
        <div className="flex justify-between items-start mb-2">
          <div className="flex-1">
            <h2 className="text-2xl font-bold gradient-text">Total Saved</h2>
          </div>
          <div className="text-right">
            <p className="text-sm text-muted-foreground">Expiring this week</p>
            <p className="text-2xl font-bold text-warning">{expiringThisWeek}</p>
            {autoApplyCount > 0 && (
              <span className="inline-block mt-1 text-xs bg-accent/10 text-accent px-2 py-1 rounded-full">
                {autoApplyCount} auto-apply ready
              </span>
            )}
          </div>
        </div>

        {/* Savings Counter */}
        <div>
          <motion.div
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            className="text-4xl sm:text-5xl font-bold gradient-text"
          >
            {formatMoney(animatedSavings, prefs)}
          </motion.div>
          <div className="flex items-center gap-2 mt-2">
            <TimeframeChip
              value={timeframe}
              customRange={customRange}
              onChange={onTimeframeChange}
            />
          </div>
          {hasMixedCurrencies && (
            <p className="text-xs text-warning mt-2">
              Mixed currencies; showing preferred currency total
            </p>
          )}
        </div>

      </div>
    </motion.div>
  );
}
