import { Card } from "@/components/ui/card";
import VoucherBorder from "@/components/VoucherBorder";
import { ExternalLink, Bookmark, Check } from "lucide-react";
import GradientButton from "@/components/GradientButton";
import { Button } from "@/components/ui/button";
import BrandAvatar from "@/components/BrandAvatar";
import { Badge } from "@/components/ui/badge";

interface HomeVoucherPreviewMockProps {
  borderStyleId?: string;
  sourceTable?: "border_styles" | "border_prototypes";
}

export default function HomeVoucherPreviewMock({ 
  borderStyleId, 
  sourceTable = "border_prototypes" 
}: HomeVoucherPreviewMockProps) {
  // Mock voucher data matching Home/IRL voucher layout
  const mockVoucher = {
    merchant: "Starbucks",
    display_title: "Buy 1 Get 1 Free",
    conditions: "Valid on all beverages, Mon-Fri only",
    tags: [],
  };

  const expiryInfo = { text: "Expires in 3 days", variant: "outline" as const };

  return (
    <Card className="relative overflow-hidden rounded-2xl shadow-md card--frame-off">
      {/* Decorative border overlay */}
      {borderStyleId && (
        <VoucherBorder 
          borderStyleId={borderStyleId}
          sourceTable={sourceTable}
          hideBaseFrame
          target="home"
        />
      )}
      
      <div className="voucher-content relative z-10 p-4">
        {/* Header Row - Logo and Content */}
        <div className="flex items-start gap-3">
          <BrandAvatar
            merchant={mockVoucher.merchant}
            size="sm"
          />
          
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2 mb-1">
              <h3 className="font-semibold text-base truncate uppercase tracking-wide text-gray-900">{mockVoucher.merchant}</h3>
              <span className="text-xs px-2 py-1 rounded-full whitespace-nowrap font-medium bg-muted text-muted-foreground">
                {expiryInfo.text}
              </span>
            </div>

            {/* Bold deal headline */}
            <div className="mb-2">
              <span className="font-bold text-lg gradient-text">{mockVoucher.display_title}</span>
            </div>
            
            {/* Condition chips */}
            {mockVoucher.conditions && (
              <div className="flex gap-1 mb-2 flex-wrap">
                <span className="text-xs px-2 py-1 rounded-full bg-muted/50 text-muted-foreground">
                  {mockVoucher.conditions}
                </span>
              </div>
            )}

            {/* Tags */}
            {mockVoucher.tags.length > 0 && (
              <div className="flex flex-wrap gap-1 mb-2">
                {mockVoucher.tags.map((tag: string, i: number) => (
                  <span 
                    key={i} 
                    className="text-xs px-2 py-1 rounded-full bg-muted/50 text-muted-foreground capitalize"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            )}

            {/* Bottom row: Mark Used button */}
            <div className="flex items-center justify-between gap-2">
              <Button
                variant="outline"
                size="sm"
                className="px-2 h-7 ml-auto"
                aria-label="Mark as used"
              >
                <Check className="h-3 w-3" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}
