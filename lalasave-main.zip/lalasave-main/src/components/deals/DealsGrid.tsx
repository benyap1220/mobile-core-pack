import { useState, useEffect, useRef, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import DealCard from "./DealCard";
import SkeletonCard from "./SkeletonCard";
import DealDetailModal from "@/components/DealDetailModal";

interface PrimaryCoupon {
  id: string;
  code: string | null;
  benefit: string | null;
  min_spend: number | null;
  currency: string | null;
  expires_at: string | null;
  title: string | null;
  restrictions: string | null;
}

interface Deal {
  id: string;
  offer_id: number;
  deeplink_id: string;
  title: string;
  subtitle: string | null;
  badge: string | null;
  tags: string[] | null;
  image_url: string | null;
  expires_at: string | null;
  platform: string | null;
  platform_logo: string | null;
  country: string | null;
  source: string;
  score: number;
  created_at: string;
  border_id: string | null;
  border?: { id: string } | null;
  primary_coupon: PrimaryCoupon | null;
  more_coupons_count: number;
}

interface DealsGridProps {
  selectedPlatform: string;
  selectedCategory: string;
  onRefreshNeeded?: () => void;
}

export default function DealsGrid({ 
  selectedPlatform, 
  selectedCategory,
  onRefreshNeeded 
}: DealsGridProps) {
  const [deals, setDeals] = useState<Deal[]>([]);
  const [loading, setLoading] = useState(true);
  const [hasMore, setHasMore] = useState(true);
  const [nextCursor, setNextCursor] = useState<any>(null);
  const loadMoreRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const [selectedPosition, setSelectedPosition] = useState(0);
  const [dealDetails, setDealDetails] = useState<any>(null);

  const logImpression = useCallback(async (dealId: string) => {
    try {
      await supabase.functions.invoke('aff-impression', {
        body: { deal_id: dealId }
      });
    } catch (error) {
      console.error('Failed to log impression:', error);
    }
  }, []);

  const fetchDeals = useCallback(async (cursor: any = null) => {
    try {
      setLoading(true);
      
      const params = new URLSearchParams({ limit: '24' });
      if (cursor) {
        params.append('cursor_score', cursor.score);
        params.append('cursor_date', cursor.created_at);
        params.append('cursor_id', cursor.id);
      }

      const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/deals-list?${params}`;
      const response = await fetch(url);

      if (!response.ok) throw new Error('Failed to fetch deals');

      const result = await response.json();
      
      if (cursor) {
        setDeals(prev => [...prev, ...(result.items || [])]);
      } else {
        setDeals(result.items || []);
      }

      setNextCursor(result.next_cursor);
      setHasMore(!!result.next_cursor);

      // Log impressions for newly loaded deals
      (result.items || []).forEach((deal: Deal) => logImpression(deal.id));

    } catch (error) {
      console.error('Error fetching deals:', error);
      toast({
        title: "Error loading deals",
        description: "Please try again later",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [toast, logImpression]);

  // Initial load
  useEffect(() => {
    fetchDeals();
  }, [selectedPlatform, selectedCategory]);

  // Infinite scroll observer
  useEffect(() => {
    if (!loadMoreRef.current) return;
    
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && hasMore && !loading) {
            fetchDeals(nextCursor);
          }
        });
      },
      { rootMargin: '800px', threshold: 0.5 }
    );

    observer.observe(loadMoreRef.current);
    return () => observer.disconnect();
  }, [hasMore, loading, nextCursor, fetchDeals]);

  const handleCardClick = async (dealId: string, position: number) => {
    setSelectedPosition(position);
    
    // Fetch deal details (public endpoint, no auth)
    try {
      const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/deal-details?deal_id=${dealId}`;
      const response = await fetch(url);
      if (response.ok) {
        const data = await response.json();
        setDealDetails(data);
      } else {
        console.error('Failed to fetch deal details:', response.status);
        toast({
          title: "Error loading deal",
          description: "Please try again",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Failed to fetch deal details:', error);
      toast({
        title: "Error loading deal",
        description: "Please try again",
        variant: "destructive",
      });
    }
  };

  // Filter deals by platform/category
  const filteredDeals = deals.filter(deal => {
    if (selectedPlatform !== 'all' && deal.platform?.toLowerCase() !== selectedPlatform) {
      return false;
    }
    if (selectedCategory !== 'all' && !deal.tags?.some(tag => tag.toLowerCase() === selectedCategory)) {
      return false;
    }
    return true;
  });

  return (
    <>
      <div className="grid grid-cols-2 gap-3 pb-20">
        {filteredDeals.map((deal, index) => (
          <div
            key={deal.id}
            ref={index === filteredDeals.length - 1 ? loadMoreRef : null}
          >
            <DealCard 
              deal={deal} 
              borderStyleId={deal.border?.id || undefined}
              position={index + 1}
              primaryCoupon={deal.primary_coupon}
              moreCouponsCount={deal.more_coupons_count}
              onRefreshNeeded={onRefreshNeeded}
              onClick={() => handleCardClick(deal.id, index + 1)}
            />
          </div>
        ))}
        
        {loading && Array.from({ length: 6 }).map((_, i) => (
          <SkeletonCard key={`skeleton-${i}`} />
        ))}
      </div>
      
      {!loading && filteredDeals.length === 0 && (
        <div className="text-center py-12 text-muted-foreground">
          <p>No deals available</p>
        </div>
      )}

      <DealDetailModal
        open={!!dealDetails}
        onOpenChange={(open) => {
          if (!open) {
            setDealDetails(null);
          }
        }}
        dealDetails={dealDetails}
        position={selectedPosition}
      />
    </>
  );
}
