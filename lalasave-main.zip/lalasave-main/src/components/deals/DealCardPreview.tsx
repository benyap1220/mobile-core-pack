import { Card } from "@/components/ui/card";
import VoucherBorder from "@/components/VoucherBorder";
import { ExternalLink, Bookmark, Check, Copy } from "lucide-react";
import GradientButton from "@/components/GradientButton";
import { Button } from "@/components/ui/button";
import BrandAvatar from "@/components/BrandAvatar";
import { Badge } from "@/components/ui/badge";

interface DealCardPreviewProps {
  borderStyleId?: string;
  sourceTable?: "border_styles" | "border_prototypes";
}

export default function DealCardPreview({ borderStyleId, sourceTable = "border_prototypes" }: DealCardPreviewProps) {
  // Mock deal data that matches real deals
  const mockDeal = {
    merchant: "Shopee",
    platform: "shopee",
    offer_title: "20% OFF Sitewide",
    offer_summary: "Get 20% off on all items with minimum purchase of RM50",
    coupon_code: "SAVE20",
  };

  const expiryInfo = { text: "Expires 7 days", variant: "outline" as const };
  const terms = ["Min. purchase RM50", "Valid for all items"];

  return (
    <div className="w-full max-w-[180px] mx-auto">
      <Card className="relative overflow-hidden rounded-2xl shadow-md card--frame-off">
        {/* Decorative border overlay */}
        {borderStyleId && (
          <VoucherBorder 
            borderStyleId={borderStyleId}
            sourceTable={sourceTable}
            hideBaseFrame
          />
        )}
        
        <div className="voucher-content relative z-10 py-3 px-2">
          {/* Header Row - Logo and Expiry next to each other */}
          <div className="flex items-start gap-2 mb-1">
            <BrandAvatar
              merchant={mockDeal.merchant}
              size="sm"
            />
            <Badge variant={expiryInfo.variant} className="px-2 py-0.5 text-[11px] font-semibold whitespace-nowrap">
              {expiryInfo.text}
            </Badge>
          </div>

          {/* All content below is left-aligned */}
          <div className="space-y-1.5">
            {/* Headline */}
            <h2 className="text-base font-bold leading-5 line-clamp-2">{mockDeal.offer_title}</h2>
            
            {/* Subcopy */}
            {mockDeal.offer_summary && (
              <p className="text-xs text-muted-foreground line-clamp-2">{mockDeal.offer_summary}</p>
            )}

            {/* Condition Chips */}
            {terms.length > 0 && (
              <div className="flex flex-wrap gap-1">
                {terms.slice(0, 2).map((term: string, i: number) => (
                  <span 
                    key={i} 
                    className="px-2 py-0.5 rounded-full text-[11px] bg-pink-50 text-pink-700 border border-pink-200"
                  >
                    {term.trim()}
                  </span>
                ))}
              </div>
            )}

            {/* Code Box */}
            {mockDeal.coupon_code && (
              <div 
                className="rounded-xl px-3 py-1.5 flex items-center justify-between bg-muted/60 cursor-pointer hover:bg-muted/80 transition-colors"
              >
                <span className="font-semibold text-sm tracking-wide truncate">{mockDeal.coupon_code}</span>
                <Copy className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0 ml-2" />
              </div>
            )}

            {/* CTA Button and Action Icons */}
            <div className="space-y-1 mt-2">
              <GradientButton 
                className="w-full flex items-center justify-center gap-1 h-9 text-xs px-2"
              >
                <span className="truncate">Shop on Shopee</span>
                <ExternalLink className="w-3 h-3 flex-shrink-0" />
              </GradientButton>
              <div className="flex gap-1.5 justify-center">
                <Button
                  variant="outline"
                  size="sm"
                  className="px-2 h-7"
                  aria-label="Save voucher"
                >
                  <Bookmark className="h-3 w-3" />
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="px-2 h-7"
                  aria-label="Mark as used"
                >
                  <Check className="h-3 w-3" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
