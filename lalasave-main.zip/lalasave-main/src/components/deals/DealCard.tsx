import { Card } from "@/components/ui/card";
import VoucherBorder from "@/components/VoucherBorder";
import { ExternalLink, Bookmark, Check, Copy, Tag, Ticket } from "lucide-react";
import GradientButton from "@/components/GradientButton";
import { Button } from "@/components/ui/button";
import BrandAvatar from "@/components/BrandAvatar";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { format, isPast, differenceInDays } from "date-fns";
import { useState } from "react";
import { getPlatformLogo } from "@/lib/platformLogos";

interface PrimaryCoupon {
  id: string;
  code: string | null;
  benefit: string | null;
  min_spend: number | null;
  currency: string | null;
  expires_at: string | null;
  title: string | null;
  restrictions: string | null;
}

interface DealCardProps {
  deal: any;
  borderStyleId?: string;
  position?: number;
  primaryCoupon?: PrimaryCoupon | null;
  moreCouponsCount?: number;
  onRefreshNeeded?: () => void;
  onClick?: () => void;
}

export default function DealCard({ deal, borderStyleId, position = 0, primaryCoupon, moreCouponsCount = 0, onRefreshNeeded, onClick }: DealCardProps) {
  const { toast } = useToast();
  const [isSaved, setIsSaved] = useState(false);
  const [logoError, setLogoError] = useState(false);

  const handleCTAClick = async (e: React.MouseEvent) => {
    e.stopPropagation();
    const deeplinkUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/go-deeplink/${deal.deeplink_id}?pos=card_${position}`;
    window.open(deeplinkUrl, '_blank');
  };

  const getExpiryChip = () => {
    // Use primary coupon expiry if available, otherwise deal expiry
    const expiryDate = primaryCoupon?.expires_at || deal.expires_at;
    
    if (!expiryDate) {
      return { text: "No expiry", variant: "outline" as const };
    }

    const expiry = new Date(expiryDate);
    const daysLeft = differenceInDays(expiry, new Date());
    const isExpired = isPast(expiry);

    if (isExpired) {
      return { text: "Expired", variant: "destructive" as const };
    }

    if (daysLeft <= 7) {
      return { text: `Expires ${format(expiry, "d MMM")}`, variant: "destructive" as const };
    }

    return { text: `Expires ${format(expiry, "d MMM")}`, variant: "outline" as const };
  };

  const handleCopyCoupon = (e: React.MouseEvent, code: string) => {
    e.stopPropagation();
    navigator.clipboard.writeText(code);
    toast({
      title: "Copied!",
      description: `Code ${code} copied to clipboard`,
    });
  };

  const handleOpenDeal = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    const uid = user?.id || "";
    const redirectUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/aff-redirect?offerId=${deal.id}&uid=${uid}`;
    window.open(redirectUrl, "_blank");
  };

  const detectDealType = (title: string, summary: string | null): "percentage" | "amount" | "other" => {
    const text = `${title} ${summary || ''}`.toLowerCase();
    
    if (text.match(/\d+%\s*(off|discount|save)/)) {
      return 'percentage';
    }
    
    if (text.match(/(rm|usd|sgd|myr|\$)\s*\d+\s*(off|voucher|discount)/i)) {
      return 'amount';
    }
    
    return 'other';
  };

  const handleSaveToWallet = async (e: React.MouseEvent) => {
    e.stopPropagation();
    
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        toast({
          title: "Sign in required",
          description: "Please sign in to save deals",
          variant: "destructive",
        });
        return;
      }

      const merchantName = (deal.merchant || deal.platform).substring(0, 100);
      
      const categoryMap: Record<string, "food" | "fitness" | "travel" | "other"> = {
        "food": "food",
        "marketplace": "other",
        "ehailing": "travel",
        "electronics": "other",
      };

      const detectedDealType = detectDealType(deal.offer_title, deal.offer_summary);

      let extractedValue: number | null = null;
      if (detectedDealType === 'percentage') {
        const match = deal.offer_title.match(/(\d+)%/);
        if (match) extractedValue = parseInt(match[1]);
      } else if (detectedDealType === 'amount') {
        const match = deal.title?.match(/(rm|usd|sgd|myr|\$)\s*(\d+)/i);
        if (match) extractedValue = parseInt(match[2]);
      }

      const { error } = await supabase.from("vouchers").insert([{
        user_id: user.id,
        merchant: merchantName,
        deal_type: detectedDealType,
        value: extractedValue,
        category: "other",
        conditions: (deal.subtitle || "").substring(0, 1000),
        expiry_date: deal.expires_at ? new Date(deal.expires_at).toISOString().split('T')[0] : null,
        merchant_logo_path: deal.platform_logo || null,
        logo_source: (deal.platform_logo ? "resolver" : "none") as any,
        source: "manual" as const,
        status: "active" as const,
        display_title: (deal.title || "Deal").substring(0, 200),
        source_offer_id: deal.id,
      }]);

      if (error) throw error;

      setIsSaved(true);
      toast({
        title: "Saved to wallet",
        description: `${deal.offer_title} added to your vouchers`,
      });

      onRefreshNeeded?.();
    } catch (error) {
      console.error("Failed to save:", error);
      toast({
        title: "Failed to save",
        description: "Please try again",
        variant: "destructive",
      });
    }
  };

  const cleanPlatformName = (platform: string) => {
    return platform
      .replace(/\s*-\s*(CPS|CPA)\s*$/i, '') // Remove - CPS or - CPA suffix
      .replace(/\s*\((Deeplinkable|Non-deeplinkable)\)\s*/i, '') // Remove (Deeplinkable)
      .trim();
  };

  const getPlatformCTA = () => {
    const platform = deal.platform || 'Store';
    const cleaned = cleanPlatformName(platform);
    const firstWord = cleaned.split(' ')[0];
    const formatted = firstWord.charAt(0).toUpperCase() + firstWord.slice(1).toLowerCase();
    return `Shop on ${formatted}`;
  };

  const expiryInfo = getExpiryChip();
  const terms = deal.terms ? deal.terms.split(".").slice(0, 2).filter((t: string) => t.trim()) : [];
  
  // Use platform_logo directly from API (backend has already resolved it via logo-proxy)
  const logoUrl = deal.platform_logo;



  return (
    <Card 
      className="relative overflow-hidden rounded-2xl shadow-sm card--frame-off hover:shadow-md transition-shadow cursor-pointer"
      onClick={onClick}
    >
      {/* Decorative border overlay */}
      {borderStyleId && (
        <VoucherBorder 
          borderStyleId={borderStyleId}
          sourceTable="border_styles"
          target="deals"
          hideBaseFrame
        />
      )}
      
      <div className="voucher-content relative z-10 py-3 px-2">
        {/* Header Row - Logo and Expiry side by side */}
        <div className="flex items-start gap-2 mb-1">
          {logoUrl && !logoError ? (
            <img 
              src={logoUrl} 
              alt={deal.platform} 
              className="h-8 w-8 rounded-lg object-contain flex-shrink-0" 
              onError={() => setLogoError(true)}
            />
          ) : (
            <BrandAvatar merchant={deal.platform || deal.title} size="sm" />
          )}
          <Badge variant={expiryInfo.variant} className="px-2 py-0.5 text-[11px] font-semibold whitespace-nowrap">
            {expiryInfo.text}
          </Badge>
        </div>

        {/* All content below is left-aligned */}
        <div className="space-y-1.5">
          {/* Platform Name */}
          {deal.platform && (
            <p className="text-xs font-semibold text-primary">
              {cleanPlatformName(deal.platform)}
            </p>
          )}
          
          {/* Deal Benefit - Main Headline (NO gradient, regular dark text) */}
          <h2 className="text-base font-bold leading-5 line-clamp-2">
            {primaryCoupon?.benefit || deal.title}
          </h2>
          
          {/* Subtitle - Gray text */}
          {(deal.subtitle || primaryCoupon?.restrictions) && (
            <p className="text-xs text-muted-foreground line-clamp-2">
              {deal.subtitle || primaryCoupon?.restrictions || deal.title?.substring(0, 60)}
            </p>
          )}
        
          {/* Condition Chips (Max 2) */}
          {(primaryCoupon?.min_spend || deal.tags?.length) && (
            <div className="flex flex-wrap gap-1">
              {primaryCoupon?.min_spend && primaryCoupon.min_spend > 0 && (
                <span className="px-2 py-0.5 rounded-full text-[11px] bg-pink-50 text-pink-700 border border-pink-200">
                  Min {primaryCoupon.currency || 'RM'}{primaryCoupon.min_spend}
                </span>
              )}
              {deal.tags?.slice(0, 2).map((tag: string, i: number) => (
                <span 
                  key={i} 
                  className="px-2 py-0.5 rounded-full text-[11px] bg-pink-50 text-pink-700 border border-pink-200"
                >
                  {tag}
                </span>
              ))}
              {moreCouponsCount > 0 && (
                <span className="px-2 py-0.5 rounded-full text-[11px] bg-blue-50 text-blue-700 border border-blue-200">
                  +{moreCouponsCount} more
                </span>
              )}
            </div>
          )}

          {/* Coupon Code or Auto-apply chip */}
          {primaryCoupon?.code ? (
            <div 
              className="rounded-xl px-3 py-1.5 flex items-center justify-between bg-muted/60 cursor-pointer hover:bg-muted/80 transition-colors"
              onClick={(e) => handleCopyCoupon(e, primaryCoupon.code!)}
            >
              <span className="font-semibold text-sm tracking-wide truncate">{primaryCoupon.code}</span>
              <Copy className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0 ml-2" />
            </div>
          ) : (
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-muted/50 rounded-md">
              <span className="text-xs font-medium text-muted-foreground">Auto-applies</span>
            </div>
          )}

          {/* CTA Button and Action Icons */}
          <div className="space-y-1 mt-2">
            <GradientButton
              onClick={() => handleCTAClick({} as React.MouseEvent)}
              className="w-full flex items-center justify-center gap-1 h-9 text-xs px-2"
            >
              <span className="truncate">{getPlatformCTA()}</span>
              <ExternalLink className="w-3 h-3 flex-shrink-0" />
            </GradientButton>
            <div className="flex gap-1.5 justify-center">
              <Button
                variant="outline"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  handleSaveToWallet(e);
                }}
                className="px-2 h-7"
                aria-label="Save voucher"
              >
                {isSaved ? <Check className="h-3 w-3" /> : <Bookmark className="h-3 w-3" />}
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="px-2 h-7"
                aria-label="Mark as used"
              >
                <Check className="h-3 w-3" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}
