import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export default function SkeletonCard() {
  return (
    <Card className="relative overflow-hidden rounded-2xl shadow-md">
      <div className="animate-pulse py-3 px-2 space-y-2">
        {/* Header row skeleton */}
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2 flex-1">
            <Skeleton className="w-8 h-8 rounded-lg" />
            <div className="space-y-1 flex-1">
              <Skeleton className="h-3 w-20" />
              <Skeleton className="h-2 w-12" />
            </div>
          </div>
          <Skeleton className="h-5 w-16 rounded-full" />
        </div>

        {/* Title skeleton */}
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-3/4" />

        {/* Subcopy skeleton */}
        <Skeleton className="h-3 w-full" />
        <Skeleton className="h-3 w-2/3" />

        {/* Chips skeleton */}
        <div className="flex gap-1">
          <Skeleton className="h-5 w-20 rounded-full" />
          <Skeleton className="h-5 w-24 rounded-full" />
        </div>

        {/* Code box skeleton */}
        <Skeleton className="h-8 w-full rounded-xl" />

        {/* Button skeleton */}
        <div className="flex gap-1.5">
          <Skeleton className="h-9 flex-1 rounded-2xl" />
          <Skeleton className="h-9 w-9 rounded-md" />
        </div>
      </div>
    </Card>
  );
}
