import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface GradientButtonProps {
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
  disabled?: boolean;
  type?: "button" | "submit" | "reset";
}

export default function GradientButton({ 
  children, 
  className, 
  onClick,
  disabled,
  type = "button",
}: GradientButtonProps) {
  return (
    <motion.button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "blue-gradient text-white rounded-2xl px-5 py-3 shadow-lg transition-transform",
        "hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed",
        className
      )}
      whileHover={disabled ? {} : { y: -2 }}
      whileTap={disabled ? {} : { scale: 0.98 }}
    >
      {children}
    </motion.button>
  );
}
