export default function Avatar({ size = 40 }: { size?: number }) {
  return (
    <img
      src="/images/avatar-bear.png"
      alt="User avatar"
      width={size}
      height={size}
      className="rounded-full ring-2 ring-white shadow-sm"
    />
  );
}
