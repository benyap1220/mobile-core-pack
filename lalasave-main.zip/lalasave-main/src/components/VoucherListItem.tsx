import { motion } from "framer-motion";
import { MapPin, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatDealSummary, getConditionChips } from "@/lib/deals";
import { useCurrencyPrefs } from "@/hooks/useCurrencyPrefs";
import BrandAvatar from "@/components/BrandAvatar";
import VoucherBorder from "@/components/VoucherBorder";
import { Card } from "@/components/ui/card";
import { format } from "date-fns";

interface VoucherListItemProps {
  voucher: {
    voucher_id: string;
    merchant: string;
    merchant_logo_path?: string | null;
    merchant_domain?: string | null;
    location?: string | null;
    deal_type: string;
    value: number | null;
    currency: string;
    category: string;
    expiry_date: string | null;
    status: string;
    conditions?: string | null;
    tags?: string[] | null;
    display_title?: string | null;
    border_style_id?: string | null;
  };
  onClick: () => void;
  onMarkUsed: () => void;
  borderStyleId?: string;
}

const getExpiryDays = (expiryDate: string | null) => {
  if (!expiryDate) return null;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const expiry = new Date(expiryDate);
  expiry.setHours(0, 0, 0, 0);
  return Math.ceil((expiry.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
};

const getStatusPill = (days: number | null, status: string) => {
  if (status === "expired" || (days !== null && days < 0)) {
    return { text: "Expired", color: "bg-destructive text-white" };
  }
  if (days === null) return { text: "No expiry", color: "bg-muted text-muted-foreground" };
  if (days <= 1) return { text: `${days}d left`, color: "bg-destructive text-white" };
  if (days <= 7) return { text: `${days}d left`, color: "bg-warning text-white" };
  return { text: `${days}d left`, color: "bg-success text-white" };
};

const getProgressPercentage = (days: number | null) => {
  if (days === null) return 100;
  if (days < 0) return 0;
  // Assume 30 days is 100%, scale down
  const maxDays = 30;
  return Math.max(0, Math.min(100, (days / maxDays) * 100));
};

const getProgressColor = (days: number | null) => {
  if (days === null) return "bg-success";
  if (days < 0 || days <= 1) return "bg-destructive";
  if (days <= 7) return "bg-warning";
  return "bg-success";
};

const getMerchantInitial = (merchant: string) => {
  return merchant.charAt(0).toUpperCase();
};

export default function VoucherListItem({
  voucher,
  onClick,
  onMarkUsed,
  borderStyleId,
}: VoucherListItemProps) {
  const { prefs } = useCurrencyPrefs();
  const days = getExpiryDays(voucher.expiry_date);
  const statusPill = getStatusPill(days, voucher.status);
  const progressPercentage = getProgressPercentage(days);
  const progressColor = getProgressColor(days);
  
  // Use display_title if available, else compute from deal_type/value
  const dealHeadline = voucher.display_title || formatDealSummary(voucher.deal_type, voucher.value, voucher.currency, prefs);
  const conditionChips = getConditionChips(voucher.conditions);
  
  // Format expiry date like "Expires 13 Oct"
  const formattedExpiry = voucher.expiry_date 
    ? `Expires ${format(new Date(voucher.expiry_date), "d MMM")}`
    : null;
  
  // Determine if expiring soon (7 days or less)
  const isExpiringSoon = days !== null && days <= 7 && days >= 0;

  return (
    <Card className="relative overflow-hidden rounded-2xl shadow-md card--frame-off">
      {/* Decorative border overlay */}
      {borderStyleId && (
        <VoucherBorder 
          borderStyleId={borderStyleId}
          sourceTable="border_styles"
          hideBaseFrame
          target="home"
        />
      )}
      
      <motion.div
        whileHover={{ y: -2 }}
        whileTap={{ scale: 0.98 }}
        transition={{ duration: 0.12 }}
        onClick={onClick}
        className="voucher-content relative z-10 p-4 cursor-pointer"
      >
        <div className="flex items-start gap-3">
          <BrandAvatar merchant={voucher.merchant} domain={voucher.merchant_domain} size="sm" />
        
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2 mb-1">
            <h3 className="font-semibold text-base truncate uppercase tracking-wide text-gray-900">{voucher.merchant}</h3>
            <span className={`text-xs px-2 py-1 rounded-md whitespace-nowrap font-medium ${
              isExpiringSoon ? 'bg-red-500 text-white' : 'bg-red-100 text-black'
            }`}>
              {formattedExpiry || "No expiry"}
            </span>
          </div>

          {/* Location */}
          {voucher.location && (
            <div className="flex items-center gap-1 text-xs text-muted-foreground mb-2">
              <MapPin className="h-3 w-3" />
              <span className="truncate">{voucher.location}</span>
            </div>
          )}

          {/* Bold deal headline - use display_title or computed */}
          <div className="mb-2">
            <span className="font-bold text-lg gradient-text">{dealHeadline}</span>
          </div>

          {/* Condition chips (max 2 from conditions text) */}
          {conditionChips.length > 0 && (
            <div className="flex gap-1 mb-2 flex-wrap">
              {conditionChips.map((chip, idx) => (
                <span
                  key={idx}
                  className="text-xs px-2 py-1 rounded-full bg-muted/50 text-muted-foreground"
                >
                  {chip}
                </span>
              ))}
            </div>
          )}

          {/* Bottom row: category pill + Mark Used icon */}
          <div className="flex items-center justify-between gap-2">
            {voucher.category && voucher.category.toLowerCase() !== 'other' && (
              <span className="text-xs px-2 py-1 rounded-full bg-muted/50 text-muted-foreground capitalize">
                {voucher.category}
              </span>
            )}
            <Button
              onClick={(e) => {
                e.stopPropagation();
                onMarkUsed();
              }}
              variant="outline"
              size="sm"
              className="px-2 h-7 ml-auto"
              aria-label="Mark as used"
            >
              <Check className="h-3 w-3" />
            </Button>
          </div>
        </div>
      </div>

        {/* Thin progress bar at bottom */}
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-muted/30">
          <div
            className={`h-full transition-all duration-300 ${progressColor}`}
            style={{ width: `${progressPercentage}%` }}
          />
        </div>
      </motion.div>
    </Card>
  );
}
