import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";

interface Voucher {
  voucher_id: string;
  merchant: string;
  deal_type?: string;
  value?: number | null;
  currency?: string;
  actual_amount_saved?: number | null;
}

interface MarkUsedDialogProps {
  voucher: Voucher | null;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export function MarkUsedDialog({ voucher, isOpen, onClose, onSuccess }: MarkUsedDialogProps) {
  const [actualAmount, setActualAmount] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Show input prompt for percentage vouchers OR "other" type with no fixed value
  const needsAmountInput = 
    voucher?.deal_type === 'percentage' ||  // Always for percentage
    (voucher?.deal_type === 'other' && !voucher?.value);  // For "other" with no fixed value (free delivery, BOGO, etc.)
  
  const currency = voucher?.currency || 'MYR';

  const handleSubmit = async () => {
    if (!voucher) return;

    // Validate when amount input is needed
    if (needsAmountInput && (!actualAmount || parseFloat(actualAmount) <= 0)) {
      toast({
        title: "Amount Required",
        description: "Please enter the actual amount you saved.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);

    const updateData: any = { status: 'used' };
    
    if (needsAmountInput && actualAmount) {
      updateData.actual_amount_saved = parseFloat(actualAmount);
    }

    const { error } = await supabase
      .from('vouchers')
      .update(updateData)
      .eq('voucher_id', voucher.voucher_id);

    setIsSubmitting(false);

    if (error) {
      console.error("Error marking voucher as used:", error);
      toast({
        title: "Error",
        description: "Failed to mark voucher as used. Please try again.",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Success",
      description: "Voucher marked as used!",
    });

    setActualAmount("");
    onSuccess();
    onClose();
  };

  const handleCancel = () => {
    setActualAmount("");
    onClose();
  };

  if (!voucher) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Mark as Used</DialogTitle>
          <DialogDescription>
            {needsAmountInput 
              ? `How much did you save using this ${voucher.merchant} voucher?`
              : `Confirm marking this ${voucher.merchant} voucher as used.`
            }
          </DialogDescription>
        </DialogHeader>
        
        {needsAmountInput && (
          <div className="space-y-2">
            <Label htmlFor="actual-amount">Amount Saved *</Label>
            <Input 
              id="actual-amount"
              type="number" 
              step="0.01"
              min="0.01"
              placeholder={`e.g., ${currency} 50`}
              value={actualAmount}
              onChange={(e) => setActualAmount(e.target.value)}
              required
            />
            <p className="text-xs text-muted-foreground">
              Enter the actual amount you saved after using this voucher
            </p>
          </div>
        )}
        
        <DialogFooter>
          <Button variant="outline" onClick={handleCancel} disabled={isSubmitting}>
            Cancel
          </Button>
          <Button 
            onClick={handleSubmit} 
            disabled={isSubmitting || (needsAmountInput && !actualAmount)}
          >
            {isSubmitting ? "Marking..." : "Confirm"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
