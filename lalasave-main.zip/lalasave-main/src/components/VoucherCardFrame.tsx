import { ReactNode } from "react";

interface VoucherCardFrameProps {
  children: ReactNode;
  replaceBaseFrame?: boolean;
  contentInset?: number;
  className?: string;
}

/**
 * Wrapper component that applies proper padding when using frame replacement mode.
 * When replaceBaseFrame is true, applies contentInset as padding to prevent content
 * from overlapping with the decorative frame band.
 */
export default function VoucherCardFrame({ 
  children, 
  replaceBaseFrame = false,
  contentInset = 0,
  className = ""
}: VoucherCardFrameProps) {
  if (!replaceBaseFrame || contentInset === 0) {
    return <>{children}</>;
  }

  return (
    <div 
      className={className}
      style={{ 
        padding: `${contentInset}px`
      }}
    >
      {children}
    </div>
  );
}
