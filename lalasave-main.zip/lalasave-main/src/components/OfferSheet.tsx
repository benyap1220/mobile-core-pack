import { motion, AnimatePresence } from "framer-motion";
import { X, Check, ExternalLink } from "lucide-react";
import { useState } from "react";
import GradientButton from "./GradientButton";
import BrandAvatar from "./BrandAvatar";
import { formatConditionsAsBullets, capitalizeTag } from "@/lib/deals";
import { formatDealHeadline } from "@/lib/currency";
import { useCurrencyPrefs } from "@/hooks/useCurrencyPrefs";
import { supabase } from "@/integrations/supabase/client";

interface Voucher {
  voucher_id: string;
  merchant: string;
  merchant_logo_path?: string | null;
  merchant_domain?: string | null;
  deal_type: string;
  value: number | null;
  currency: string;
  category: string;
  expiry_date: string | null;
  conditions: string;
  personal_notes?: string | null;
  tags: string[];
  apply_mode?: string;
  online_url?: string | null;
}

interface OfferSheetProps {
  voucher: Voucher | null;
  isOpen: boolean;
  onClose: () => void;
  onMarkUsed: (voucherId: string) => void;
}

const getExpiryDays = (expiryDate: string | null) => {
  if (!expiryDate) return null;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const expiry = new Date(expiryDate);
  expiry.setHours(0, 0, 0, 0);
  return Math.ceil((expiry.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
};

const getDaysLeftPillColor = (days: number | null) => {
  if (days === null) return "bg-muted text-muted-foreground";
  if (days < 0) return "bg-destructive text-white";
  if (days <= 3) return "bg-destructive text-white";
  if (days <= 7) return "bg-warning text-white";
  return "bg-success text-white";
};

const getApplyModeBadge = (mode?: string) => {
  if (!mode || mode === "manual")
    return {
      text: "Manual",
      tooltip: "Show code or scan QR to redeem.",
      color: "bg-muted/50 text-muted-foreground border-muted",
    };
  if (mode === "auto")
    return {
      text: "Auto-apply",
      tooltip: "Discount applies automatically at checkout.",
      color: "bg-accent/10 text-accent border-accent/20",
    };
  if (mode === "added_to_card")
    return {
      text: "Added",
      tooltip: "Offer linked to your card/account.",
      color: "bg-success/10 text-success border-success/20",
    };
  return {
    text: "Manual",
    tooltip: "Show code or scan QR to redeem.",
    color: "bg-muted/50 text-muted-foreground border-muted",
  };
};


const getStackSuggestions = (category: string, currency: string): string[] => {
  const suggestions: string[] = [];
  
  if (currency === "MYR") {
    if (category === "food") {
      suggestions.push("+5% TnG cashback", "+1% GrabPay cashback");
    } else if (category === "travel") {
      suggestions.push("+1% card rebate");
    } else {
      suggestions.push("+2% e-wallet cashback");
    }
  }
  
  return suggestions;
};

export default function OfferSheet({
  voucher,
  isOpen,
  onClose,
  onMarkUsed,
}: OfferSheetProps) {
  const [selectedStacks, setSelectedStacks] = useState<string[]>([]);
  const { prefs } = useCurrencyPrefs();

  if (!voucher) return null;

  const days = getExpiryDays(voucher.expiry_date);
  const badge = getApplyModeBadge(voucher.apply_mode);
  const stackSuggestions = getStackSuggestions(voucher.category, voucher.currency);
  const conditionBullets = formatConditionsAsBullets(voucher.conditions);
  const onlineUrl = voucher.online_url;

  const getCTALabel = () => {
    const category = voucher.category.toLowerCase();
    if (category.includes('marketplace') || category.includes('ecommerce') || category.includes('shopping')) {
      return `Shop on ${voucher.merchant}`;
    }
    if (category.includes('ehailing') || category.includes('food') || category.includes('delivery')) {
      return `Order on ${voucher.merchant}`;
    }
    return 'Use online';
  };

  const handleOpenLink = async () => {
    if (!onlineUrl) return;

    // Optional analytics logging (non-blocking)
    try {
      await supabase.from('affiliate_clicks').insert({
        voucher_id: voucher.voucher_id,
        offer_id: null,
        user_agent: navigator.userAgent,
        clicked_at: new Date().toISOString(),
      });
    } catch (err) {
      console.debug('Analytics logging skipped:', err);
    }

    window.open(onlineUrl, '_blank', 'noopener,noreferrer');
  };

  const toggleStack = (stack: string) => {
    setSelectedStacks((prev) =>
      prev.includes(stack) ? prev.filter((s) => s !== stack) : [...prev, stack]
    );
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/40 z-50 backdrop-blur-sm"
          />

          {/* Sheet */}
          <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 30, stiffness: 300 }}
            className="fixed bottom-0 left-0 right-0 md:left-1/2 md:-translate-x-1/2 md:bottom-auto md:top-1/2 md:-translate-y-1/2 md:max-w-lg md:rounded-3xl z-50 glass border-gradient shadow-2xl flex flex-col max-h-[85vh]"
          >
            {/* Scrollable content */}
            <div className="overflow-y-auto flex-1 pb-[calc(env(safe-area-inset-bottom)+88px)]">
              <div className="p-6">
              {/* Close Button */}
              <button
                onClick={onClose}
                className="absolute top-4 right-4 p-2 rounded-full hover:bg-muted/20 transition-colors"
              >
                <X className="h-5 w-5" />
              </button>

              {/* Merchant Logo & Name */}
              <div className="flex items-center gap-4 mb-6">
                <BrandAvatar 
                  merchant={voucher.merchant} 
                  domain={voucher.merchant_domain}
                  size="md"
                />
                <div className="flex-1 min-w-0">
                  <h2 className="text-xl font-bold truncate">{voucher.merchant}</h2>
                  {voucher.category && voucher.category.toLowerCase() !== 'other' && (
                    <p className="text-sm text-muted-foreground capitalize">
                      {voucher.category}
                    </p>
                  )}
                </div>
              </div>

              {/* Discount */}
              <div className="mb-4">
                <h2 className="text-4xl font-bold gradient-text">
                  {formatDealHeadline(voucher.deal_type, voucher.value, prefs)}
                </h2>
              </div>

              {/* Days Left & Apply Mode */}
              <div className="flex items-center gap-2 mb-6">
                <span
                  className={`text-sm px-3 py-1 rounded-full font-medium ${getDaysLeftPillColor(
                    days
                  )}`}
                >
                  {days === null
                    ? "No expiry"
                    : days < 0
                    ? "Expired"
                    : `${days}d left`}
                </span>
                {voucher.expiry_date && (
                  <span className="text-sm text-muted-foreground">
                    Expires {new Date(voucher.expiry_date).toLocaleDateString()}
                  </span>
                )}
              </div>


              {/* Code/Barcode Placeholder */}
              <div className="glass rounded-2xl p-6 mb-6 text-center">
                <div className="inline-block px-6 py-3 bg-white rounded-lg border-2 border-dashed border-muted mb-2">
                  <p className="text-2xl font-mono font-bold">PROMO2025</p>
                </div>
                <p className="text-xs text-muted-foreground">
                  Show this code at checkout
                </p>
              </div>

              {/* Conditions */}
              {conditionBullets.length > 0 && (
                <section className="mb-6">
                  <h3 className="text-sm font-semibold mb-2">Conditions</h3>
                  <ul className="space-y-1 list-disc list-inside text-sm text-muted-foreground">
                    {conditionBullets.map((line, i) => (
                      <li key={i}>{line}</li>
                    ))}
                  </ul>
                </section>
              )}
              {!conditionBullets.length && (
                <section className="mb-6">
                  <h3 className="text-sm font-semibold mb-2">Conditions</h3>
                  <p className="text-sm text-muted-foreground">No special conditions.</p>
                </section>
              )}

              {/* Personal Notes */}
              {voucher.personal_notes && (
                <section className="mb-6">
                  <h3 className="text-sm font-semibold mb-2">Personal Notes</h3>
                  <ul className="space-y-1 list-disc list-inside text-sm text-muted-foreground">
                    {voucher.personal_notes.split('\n').filter(line => line.trim()).map((line, i) => (
                      <li key={i}>{line.replace(/^•\s*/, '')}</li>
                    ))}
                  </ul>
                </section>
              )}

              {/* Tags (if needed separately) */}
              {voucher.tags && voucher.tags.filter(tag => tag.toLowerCase() !== 'other' && tag.toLowerCase() !== 'manual').length > 0 && (
                <div className="mb-6">
                  <p className="text-sm font-medium mb-2">Tags</p>
                  <div className="flex flex-wrap gap-2">
                    {voucher.tags
                      .filter(tag => tag.toLowerCase() !== 'other' && tag.toLowerCase() !== 'manual')
                      .map((tag, idx) => (
                        <span
                          key={idx}
                          className="text-xs px-3 py-1 rounded-full bg-primary/10 text-primary border border-primary/20"
                        >
                          {capitalizeTag(tag)}
                        </span>
                      ))}
                  </div>
                </div>
              )}

              {/* Stack Suggestions */}
              {stackSuggestions.length > 0 && (
                <div className="mb-6">
                  <p className="text-sm font-medium mb-2">Stack with</p>
                  <div className="flex flex-wrap gap-2">
                    {stackSuggestions.map((stack, idx) => {
                      const isSelected = selectedStacks.includes(stack);
                      return (
                        <button
                          key={idx}
                          onClick={() => toggleStack(stack)}
                          className={`text-xs px-3 py-1.5 rounded-full border transition-all ${
                            isSelected
                              ? "blue-gradient text-white border-transparent"
                              : "border-accent/20 text-accent hover:bg-accent/5"
                          }`}
                        >
                          {isSelected && <Check className="inline h-3 w-3 mr-1" />}
                          {stack}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
              </div>
            </div>

            {/* Sticky footer with actions */}
            <div className="sticky bottom-0 left-0 right-0 z-10 bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-t p-4 pb-[calc(env(safe-area-inset-bottom)+16px)]">
              <div className="flex gap-3 flex-col sm:flex-row">
                {onlineUrl ? (
                  <GradientButton
                    onClick={handleOpenLink}
                    className="flex-1 flex items-center justify-center gap-2"
                    aria-label={`Open ${voucher.merchant} in a new tab`}
                  >
                    {getCTALabel()}
                    <ExternalLink className="w-4 h-4" />
                  </GradientButton>
                ) : (
                  <GradientButton
                    onClick={() => {
                      onClose();
                    }}
                    className="flex-1"
                  >
                    Use now
                  </GradientButton>
                )}
                <button
                  onClick={() => {
                    onMarkUsed(voucher.voucher_id);
                    onClose();
                  }}
                  className="flex-1 glass rounded-2xl px-5 py-3 hover:shadow-md transition-shadow"
                >
                  Mark used
                </button>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
