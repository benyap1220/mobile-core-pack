import { motion } from "framer-motion";
import { Tag, Calendar, ExternalLink } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import BrandAvatar from "@/components/BrandAvatar";
import GradientButton from "@/components/GradientButton";
import { supabase } from "@/integrations/supabase/client";

interface VoucherCardProps {
  voucher: {
    voucher_id: string;
    merchant: string;
    merchant_domain?: string;
    deal_type: string;
    value: number | null;
    currency: string;
    expiry_date: string | null;
    tags: string[];
    category: string;
    online_url?: string | null;
  };
  index: number;
  onClick: () => void;
}

const VoucherCard = ({ voucher, index, onClick }: VoucherCardProps) => {
  const onlineUrl = voucher.online_url;

  const getCTALabel = () => {
    const category = voucher.category.toLowerCase();
    if (category.includes('marketplace') || category.includes('ecommerce') || category.includes('shopping')) {
      return `Shop on ${voucher.merchant}`;
    }
    if (category.includes('ehailing') || category.includes('food') || category.includes('delivery')) {
      return `Order on ${voucher.merchant}`;
    }
    return 'Use online';
  };

  const handleCTAClick = async () => {
    if (!onlineUrl) return;

    // Optional analytics logging (non-blocking)
    try {
      await supabase.from('affiliate_clicks').insert({
        voucher_id: voucher.voucher_id,
        offer_id: null,
        user_agent: navigator.userAgent,
        clicked_at: new Date().toISOString(),
      });
    } catch (err) {
      // Silently fail if table doesn't exist or insert fails
      console.debug('Analytics logging skipped:', err);
    }

    window.open(onlineUrl, '_blank', 'noopener,noreferrer');
  };

  const getExpiryStatus = (expiryDate: string | null) => {
    if (!expiryDate) return { color: "bg-muted", text: "No expiry", textColor: "text-muted-foreground" };
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const expiry = new Date(expiryDate);
    expiry.setHours(0, 0, 0, 0);
    const diffTime = expiry.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays < 0) return { color: "bg-destructive", text: "Expired", textColor: "text-white" };
    if (diffDays <= 3) return { color: "bg-white border border-red-200", text: `${diffDays}d left`, textColor: "text-red-600" };
    if (diffDays <= 7) return { color: "bg-white border border-amber-200", text: `${diffDays}d left`, textColor: "text-amber-600" };
    return { color: "bg-white border border-blue-200", text: `${diffDays}d left`, textColor: "text-[#0A66FF]" };
  };

  const getDealDisplay = () => {
    if (voucher.deal_type === 'percentage' && voucher.value) {
      return `${voucher.value}% OFF`;
    }
    if (voucher.deal_type === 'amount' && voucher.value) {
      return `${voucher.currency} ${voucher.value} OFF`;
    }
    if (voucher.deal_type === 'bogo') {
      return 'BOGO';
    }
    return 'DEAL';
  };

  const status = getExpiryStatus(voucher.expiry_date);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      onClick={onClick}
      whileHover={{ y: -2 }}
      whileTap={{ scale: 0.98 }}
      className="glass border-gradient p-5 cursor-pointer transition-all hover:shadow-xl"
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          {/* Merchant Logo */}
          <div className="flex items-center gap-3 mb-3">
            <BrandAvatar 
              merchant={voucher.merchant} 
              domain={voucher.merchant_domain}
              size="sm"
            />
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-lg truncate">{voucher.merchant}</h3>
              <p className="text-sm text-muted-foreground capitalize">{voucher.category}</p>
            </div>
          </div>

          {/* Deal Value */}
          <div className="mb-3">
            <p className="text-2xl font-bold gradient-text">{getDealDisplay()}</p>
          </div>

          {/* Tags */}
          {voucher.tags.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-3">
              {voucher.tags.slice(0, 3).map((tag, i) => (
                <Badge key={i} variant="secondary" className="text-xs">
                  <Tag className="w-3 h-3 mr-1" />
                  {tag}
                </Badge>
              ))}
            </div>
          )}

          {/* Expiry Date */}
          {voucher.expiry_date && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Calendar className="w-4 h-4" />
              <span>Expires: {new Date(voucher.expiry_date).toLocaleDateString()}</span>
            </div>
          )}

          {/* Online CTA */}
          {onlineUrl && (
            <div className="mt-4" onClick={(e) => e.stopPropagation()}>
              <GradientButton
                onClick={handleCTAClick}
                className="w-full flex items-center justify-center gap-2"
                aria-label={`Open ${voucher.merchant} in a new tab`}
              >
                {getCTALabel()}
                <ExternalLink className="w-4 h-4" />
              </GradientButton>
            </div>
          )}
        </div>

        {/* Status Badge */}
        <div>
          <Badge className={`${status.color} ${status.textColor} font-semibold`}>
            {status.text}
          </Badge>
        </div>
      </div>
    </motion.div>
  );
};

export default VoucherCard;
