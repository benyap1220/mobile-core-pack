export type CurrencyPrefs = {
  code: string;           // e.g., 'MYR'
  symbol: string;         // e.g., 'RM'
  position: 'prefix' | 'suffix';
  locale: string;         // e.g., 'en-MY'
};

export const DEFAULT_CURRENCY_PREFS: CurrencyPrefs = {
  code: 'MYR',
  symbol: 'RM',
  position: 'prefix',
  locale: 'en-MY',
};

export const CURRENCY_OPTIONS = [
  { code: 'MYR', symbol: 'RM', locale: 'en-MY', name: 'Malaysian Ringgit' },
  { code: 'USD', symbol: '$', locale: 'en-US', name: 'US Dollar' },
  { code: 'PHP', symbol: '₱', locale: 'en-PH', name: 'Philippine Peso' },
  { code: 'SGD', symbol: 'S$', locale: 'en-SG', name: 'Singapore Dollar' },
  { code: 'THB', symbol: '฿', locale: 'th-TH', name: 'Thai Baht' },
  { code: 'IDR', symbol: 'Rp', locale: 'id-ID', name: 'Indonesian Rupiah' },
  { code: 'VND', symbol: '₫', locale: 'vi-VN', name: 'Vietnamese Dong' },
];

export const LOCALE_OPTIONS = [
  { value: 'en-MY', label: 'English (Malaysia)' },
  { value: 'en-PH', label: 'English (Philippines)' },
  { value: 'en-SG', label: 'English (Singapore)' },
  { value: 'en-US', label: 'English (United States)' },
  { value: 'th-TH', label: 'Thai (Thailand)' },
  { value: 'id-ID', label: 'Indonesian (Indonesia)' },
  { value: 'vi-VN', label: 'Vietnamese (Vietnam)' },
];

export function formatMoney(value: number, prefs: CurrencyPrefs): string {
  const n = new Intl.NumberFormat(prefs.locale, {
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
  
  return prefs.position === 'prefix' ? `${prefs.symbol} ${n}` : `${n} ${prefs.symbol}`;
}

export function formatDealHeadline(
  type?: string | null,
  value?: number | null,
  prefs?: CurrencyPrefs
): string {
  const t = (type || '').toLowerCase();
  if (t === 'percentage' && value != null) return `${Math.round(value)}% OFF`;
  if (t === 'amount' && value != null && prefs) return `${formatMoney(value, prefs)} OFF`;
  if (t === 'bogo') return 'BOGO';
  return 'OTHER';
}
