/**
 * Canonical brand slug - strips sub-brands and normalizes to main brand
 * This is the FIRST function to call for any brand identification
 */
export function canonicalBrandSlug(name: string): string {
  const s = (name || '').toLowerCase().replace(/[''`"]/g, '').trim();
  
  // Lazada: catches ALL variants including logistics, express, mall, etc.
  if (s.includes('lazada')) return 'lazada';
  
  // LEX is Lazada Express
  if (s === 'lex' || s.includes('lex ')) return 'lazada';
  
  // McDonald's variants
  if (s.includes('mcdonald')) return 'mcdonalds';
  
  // Grab variants
  if (s.includes('grab')) return 'grab';
  
  // Shopee variants
  if (s.includes('shopee')) return 'shopee';
  
  // Default: basic normalization
  return s.replace(/\s+/g, ' ').trim();
}

/**
 * Slugify for URL/filename usage (kept for backwards compatibility)
 */
export function slugifyMerchant(name: string): string {
  // Use canonical slug first
  const canonical = canonicalBrandSlug(name);
  
  // Convert to URL-safe slug
  return canonical
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')     // replace non-alphanumeric with dash
    .replace(/^-+|-+$/g, '');        // trim leading/trailing dashes
}
