import { z } from "zod";

/**
 * TypeScript union type for logo source
 * Must match the database enum logo_source_enum
 */
export type LogoSource = 'uploaded' | 'resolver' | 'vision_crop' | 'generated' | 'none';

/**
 * Zod schema for validating logo source values
 * Use this to validate incoming data before saving to database
 */
export const LogoSourceSchema = z.enum(['uploaded', 'resolver', 'vision_crop', 'generated', 'none']);

/**
 * Default logo source value
 */
export const DEFAULT_LOGO_SOURCE: LogoSource = 'none';

/**
 * Check if a value is a valid LogoSource
 */
export function isValidLogoSource(value: unknown): value is LogoSource {
  return LogoSourceSchema.safeParse(value).success;
}

/**
 * Safely convert unknown value to LogoSource
 * Returns DEFAULT_LOGO_SOURCE if invalid
 */
export function toLogoSource(value: unknown): LogoSource {
  const result = LogoSourceSchema.safeParse(value);
  return result.success ? result.data : DEFAULT_LOGO_SOURCE;
}
