import { CurrencyPrefs, formatDealHeadline as formatDealHeadlineWithPrefs } from "./currency";

export function formatDealSummary(
  type?: string | null,
  value?: number | null,
  currency = "RM",
  prefs?: CurrencyPrefs
): string {
  // Use currency prefs if provided for amount discounts
  if (prefs) {
    return formatDealHeadlineWithPrefs(type, value, prefs);
  }
  
  // Fallback to simple format
  const t = (type || "").toLowerCase();
  if (t === "percentage" && value != null) return `${Math.round(value)}% OFF`;
  if (t === "amount" && value != null) return `${currency} ${value} OFF`;
  if (t === "bogo") return "BOGO";
  return "OTHER";
}

export function capitalizeTag(tag: string): string {
  return tag
    .split(' ')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(' ');
}

export function formatConditionsAsBullets(raw?: string | null): string[] {
  if (!raw) return [];
  
  // Split into sentences by . ; • or newline
  const parts = raw
    .split(/[.;•\n]/g)
    .map(s => s.trim())
    .filter(Boolean)
    .map(s => s.length > 0 ? s.charAt(0).toUpperCase() + s.slice(1) : s);

  // Grammar cleanups and add exclamation marks
  return parts
    .map(s => {
      let cleaned = s
        .replace(/\s+/g, ' ')
        .replace(/weekday(s)? only/i, 'Weekdays only')
        .replace(/dine in only/i, 'Dine-in only')
        .replace(/minimum spend/i, 'Min spend');
      
      // Add exclamation mark if not already ending with punctuation
      if (!/[!.?]$/.test(cleaned)) {
        cleaned += '!';
      }
      
      return cleaned;
    })
    .slice(0, 3); // show up to 3 bullets
}

export function formatConditionsText(conditions?: string | null): string {
  if (!conditions) return '';
  
  // Capitalize first letter of each sentence
  return conditions
    .split(/([.!?]\s+)/)
    .map((part, i) => {
      if (i % 2 === 0 && part.length > 0) {
        return part.charAt(0).toUpperCase() + part.slice(1);
      }
      return part;
    })
    .join('');
}

export function getConditionChips(conditions?: string | null): string[] {
  const bullets = formatConditionsAsBullets(conditions);
  return bullets.slice(0, 2); // max 2 chips for list cards
}
