/**
 * Hard-coded brand logo overrides
 * These take absolute priority over any network fetches or cache lookups
 */
export const BRAND_OVERRIDES: Record<string, { url: string; mime?: string }> = {
  lazada: { 
    url: '/brand-logos/lazada-official.png', 
    mime: 'image/png' 
  },
  // Add more curated overrides here as needed
  // shopee: { url: '/brand-logos/shopee-official.svg', mime: 'image/svg+xml' },
};

/**
 * Check if a brand has a hard-coded override
 */
export function getBrandOverride(slug: string): { url: string; mime?: string } | null {
  return BRAND_OVERRIDES[slug] || null;
}
