/**
 * Platform Logo Resolution
 * Maps platform names and domains to logo URLs
 */

export interface PlatformLogoMap {
  [key: string]: string;
}

// Map of known platforms to their logo URLs in public storage
export const PLATFORM_LOGOS: PlatformLogoMap = {
  'lazada': '/brand-logos/lazada-official.png',
  'shopee': '/brand-logos/shopee-official.png',
  'airasia': '/brand-logos/airasia.png',
  'watsons': '/brand-logos/watsons.png',
  'taobao': '/brand-logos/taobao.png',
  'zalora': '/brand-logos/zalora.png',
  'sephora': '/brand-logos/sephora.png',
  'traveloka': '/brand-logos/traveloka.png',
  'uniqlo': '/brand-logos/uniqlo.png',
  'shein': '/brand-logos/shein.png',
};

// Map of domains to platform slugs
export const DOMAIN_TO_PLATFORM: { [key: string]: string } = {
  'lazada.com.my': 'lazada',
  'lazada.sg': 'lazada',
  'shopee.com.my': 'shopee',
  'shopee.sg': 'shopee',
  'grab.com': 'grab',
  'foodpanda.my': 'foodpanda',
  'temu.com': 'temu',
  'amazon.com': 'amazon',
  'amazon.sg': 'amazon',
  'taobao.com': 'taobao',
  'zalora.com.my': 'zalora',
  'watsons.com.my': 'watsons',
  'uniqlo.com': 'uniqlo',
  'traveloka.com': 'traveloka',
  'airasia.com': 'airasia',
};

/**
 * Get platform logo URL from platform name or URL
 * @param platformOrUrl Platform name or landing URL
 * @returns Logo URL or null if not found
 */
export function getPlatformLogo(platformOrUrl: string | null | undefined): string | null {
  if (!platformOrUrl) return null;

  const input = platformOrUrl.toLowerCase();

  // Try direct platform name match
  for (const [key, logo] of Object.entries(PLATFORM_LOGOS)) {
    if (input.includes(key)) {
      return logo;
    }
  }

  // Try domain extraction and match
  try {
    const url = new URL(input.startsWith('http') ? input : `https://${input}`);
    const domain = url.hostname.replace('www.', '');
    
    for (const [domainPattern, platform] of Object.entries(DOMAIN_TO_PLATFORM)) {
      if (domain.includes(domainPattern)) {
        return PLATFORM_LOGOS[platform] || null;
      }
    }
  } catch {
    // Not a valid URL, continue
  }

  return null;
}

/**
 * Get platform display name from URL or name
 */
export function getPlatformName(platformOrUrl: string | null | undefined): string {
  if (!platformOrUrl) return 'Store';

  const input = platformOrUrl.toLowerCase();

  // Check known platforms
  for (const key of Object.keys(PLATFORM_LOGOS)) {
    if (input.includes(key)) {
      return key.charAt(0).toUpperCase() + key.slice(1);
    }
  }

  // Try to extract from domain
  try {
    const url = new URL(input.startsWith('http') ? input : `https://${input}`);
    const domain = url.hostname.replace('www.', '');
    
    for (const [domainPattern, platform] of Object.entries(DOMAIN_TO_PLATFORM)) {
      if (domain.includes(domainPattern)) {
        return platform.charAt(0).toUpperCase() + platform.slice(1);
      }
    }
    
    // Return cleaned domain as fallback
    return domain.split('.')[0].charAt(0).toUpperCase() + domain.split('.')[0].slice(1);
  } catch {
    return platformOrUrl;
  }
}
