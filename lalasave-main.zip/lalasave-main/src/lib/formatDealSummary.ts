export function formatDealSummary(
  dealType: string,
  value: number | null,
  currency: string = "RM"
): string {
  if (dealType === "percentage" && value) {
    return `${value}% OFF`;
  }
  if (dealType === "fixed" && value) {
    return `${currency} ${value} OFF`;
  }
  if (dealType === "bogo") {
    return "BOGO";
  }
  // Title-case other deal types
  return dealType
    .split("_")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
}
