export type TimeframePreset = 'all' | 'month' | '30d' | 'year' | 'custom';

export interface DateRange {
  from?: Date;
  to?: Date;
}

export function getDateRangeForPreset(preset: TimeframePreset): DateRange {
  const now = new Date();
  
  switch (preset) {
    case 'all':
      return {};
    
    case 'month': {
      const from = new Date(now.getFullYear(), now.getMonth(), 1);
      return { from, to: now };
    }
    
    case '30d': {
      const from = new Date(now);
      from.setDate(from.getDate() - 30);
      return { from, to: now };
    }
    
    case 'year': {
      const from = new Date(now.getFullYear(), 0, 1);
      return { from, to: now };
    }
    
    case 'custom':
      return {};
    
    default:
      return {};
  }
}

export function getTimeframeLabel(preset: TimeframePreset, customRange?: DateRange): string {
  switch (preset) {
    case 'all':
      return 'All time';
    case 'month':
      return 'This month';
    case '30d':
      return 'Last 30 days';
    case 'year':
      return 'This year';
    case 'custom':
      if (customRange?.from && customRange?.to) {
        const fmt = new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric' });
        return `${fmt.format(customRange.from)} - ${fmt.format(customRange.to)}`;
      }
      return 'Custom';
    default:
      return 'All time';
  }
}
