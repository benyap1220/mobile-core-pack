import { z } from "zod";

// Voucher validation schemas
export const voucherUpdateSchema = z.object({
  merchant: z.string().min(1, "Merchant name required").max(100, "Merchant name too long"),
  merchant_domain: z.string().max(100).optional().nullable(),
  merchant_logo_path: z.string().max(500).optional().nullable(),
  deal_type: z.enum(["percentage", "amount"]).optional().nullable(),
  value: z.number().min(0).max(1000000).optional().nullable(),
  currency: z.string().min(2).max(10),
  category: z.enum(["food", "fitness", "travel", "other"]).optional().nullable(),
  expiry_date: z.string().optional().nullable(),
  valid_from: z.string().optional().nullable(),
  conditions: z.string().max(1000).optional().nullable(),
  personal_notes: z.string().max(1000).optional().nullable(),
  tags: z.array(z.string().max(30)).max(10),
});

export const customTagSchema = z.string()
  .min(1, "Tag cannot be empty")
  .max(30, "Tag too long")
  .regex(/^[a-zA-Z0-9\s&-]+$/, "Tag contains invalid characters");

export const merchantNameSchema = z.string()
  .min(1, "Merchant name required")
  .max(100, "Merchant name too long");

export type VoucherUpdate = z.infer<typeof voucherUpdateSchema>;
