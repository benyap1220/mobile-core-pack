import { supabase } from "@/integrations/supabase/client";

interface ComputeTotalSavedParams {
  userId: string;
  preferredCurrency: string;
}

/**
 * Computes total saved using the database function that sums all used vouchers.
 * This ensures Dashboard "Total Saved" matches the sum in History.
 */
export async function computeTotalSaved({
  userId,
  preferredCurrency,
}: ComputeTotalSavedParams): Promise<{ total: number; hasMixedCurrencies: boolean }> {
  const { data, error } = await supabase.rpc("compute_total_saved", {
    p_user_id: userId,
    p_preferred_currency: preferredCurrency,
  });

  if (error) {
    console.error("Error computing total saved:", error);
    return { total: 0, hasMixedCurrencies: false };
  }

  if (!data || data.length === 0) {
    return { total: 0, hasMixedCurrencies: false };
  }

  return {
    total: data[0].total || 0,
    hasMixedCurrencies: data[0].has_mixed_currencies || false,
  };
}
