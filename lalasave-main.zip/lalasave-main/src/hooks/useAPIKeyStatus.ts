import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

interface APIKeyStatus {
  name: string;
  exists: boolean;
  valid: boolean | null;
  error?: string;
}

export function useAPIKeyStatus() {
  const [status, setStatus] = useState<APIKeyStatus[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkKeys = async () => {
      try {
        const { data, error } = await supabase.functions.invoke("verify-api-keys");
        
        if (error) throw error;
        setStatus(data.results);
      } catch (error) {
        console.error("Error checking API keys:", error);
      } finally {
        setLoading(false);
      }
    };

    checkKeys();
  }, []);

  return { status, loading };
}
