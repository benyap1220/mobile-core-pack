import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { LogoSource, toLogoSource } from "@/lib/logoTypes";

export const useLogoResolver = () => {
  const [isResolving, setIsResolving] = useState(false);
  const { toast } = useToast();

  const resolveLogo = async (voucherId: string, merchant: string, domain?: string, voucherImagePath?: string, force?: boolean) => {
    setIsResolving(true);
    try {
      const { data, error } = await supabase.functions.invoke("logo-autofill", {
        body: { voucherId, merchant, domain, voucherImagePath, force },
      });

      if (error) throw error;

      // Silent success - no toast on errors, just use fallback
      console.log("Logo autofill completed:", data?.source || "none");
      return data;
    } catch (error: any) {
      console.error("Logo autofill failed (silent):", error);
      return null;
    } finally {
      setIsResolving(false);
    }
  };

  const uploadManualLogo = async (voucherId: string, file: File) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const filePath = `${voucherId}-manual.png`;
      
      const { error: uploadError } = await supabase.storage
        .from("logos")
        .upload(filePath, file, {
          contentType: file.type,
          upsert: true,
        });

      if (uploadError) throw uploadError;

      // Store storage path in DB, not signed URL
      const logoSource: LogoSource = 'uploaded';
      
      await supabase
        .from("vouchers")
        .update({
          merchant_logo_path: filePath,
          logo_source: logoSource,
          logo_cache_updated_at: new Date().toISOString(),
        })
        .eq("voucher_id", voucherId);

      toast({
        description: "Logo uploaded successfully",
      });

      return filePath;
    } catch (error: any) {
      console.error("Manual logo upload failed:", error);
      toast({
        variant: "destructive",
        title: "Upload failed",
        description: error.message,
      });
      return null;
    }
  };

  return { resolveLogo, uploadManualLogo, isResolving };
};
