import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { CurrencyPrefs, DEFAULT_CURRENCY_PREFS } from '@/lib/currency';

export function useCurrencyPrefs() {
  const [prefs, setPrefs] = useState<CurrencyPrefs>(DEFAULT_CURRENCY_PREFS);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCurrencyPrefs();
  }, []);

  const fetchCurrencyPrefs = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        setLoading(false);
        return;
      }

      let { data, error } = await supabase
        .from('user_settings')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      // If no settings exist, create default ones
      if (!data && !error) {
        const { data: newSettings } = await supabase
          .from('user_settings')
          .insert({ user_id: user.id })
          .select('*')
          .single();
        data = newSettings;
      }

      if (data) {
        setPrefs({
          code: (data as any).preferred_currency || DEFAULT_CURRENCY_PREFS.code,
          symbol: (data as any).currency_symbol || DEFAULT_CURRENCY_PREFS.symbol,
          position: ((data as any).symbol_position as 'prefix' | 'suffix') || DEFAULT_CURRENCY_PREFS.position,
          locale: (data as any).locale || DEFAULT_CURRENCY_PREFS.locale,
        });
      }
    } catch (error) {
      console.error('Error fetching currency preferences:', error);
    } finally {
      setLoading(false);
    }
  };

  return { prefs, loading, refresh: fetchCurrencyPrefs };
}
