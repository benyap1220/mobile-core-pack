# IA Offers + Deeplink v1 - Production Ready

## Quick Start

### 1. Set ENV Secrets (Lovable Cloud)
```
IA_API_KEY=pk_live_xxx
IA_API_SECRET=sk_live_xxx
IA_AUTH_SCHEME=headers
IA_API_BASE_URL=https://api.involve.asia
```

### 2. Test Connection
Visit `/ia-admin` → Click "Test IA Connection"

### 3. Ingest & Build
1. Click "Ingest IA Offers Now" (1-3 min)
2. Click "Rebuild Feed Now" (30s-2min)

### 4. View Deals
Visit `/ia-deals` - Mobile-first grid with infinite scroll

## Features Implemented

✅ Platform allowlist (Lazada, Shopee, Grab, etc.)  
✅ Smart landing discovery with URL heuristics  
✅ **Strict URL selection policy with validation**:
  - Blocked patterns (/cart, /checkout, /login, etc.)
  - Mobile-friendly checks (viewport meta)
  - Region validation (MY domains)
  - Reachability tests (2s timeout)
  - OG meta quality checks
✅ **Sophisticated scoring (0-1 scale)**:
  - Base: promo=0.55, product=0.50, category=0.40, home=0.30
  - Boosts: platform priority +0.10, CPS +0.05, meta quality +0.05
  - Penalties: no viewport -0.10, slow -0.10, wrong region -0.15
✅ **Diversity rules**: max 1 promo + 1 category + 1 home per advertiser
✅ Rate limiting (20 req/min token bucket)  
✅ 48h rotation batches  
✅ Deeplink caching (30 days)  
✅ Click/impression tracking with SubIDs  
✅ Random non-repeating borders per page  
✅ Detail modal with promo notes  
✅ Admin UI with manual controls  
✅ Selection explainability (stored in DB)

## SubIDs
- `aff_sub`: "dealsgrid"
- `aff_sub2`: "card_{position}"
- `aff_sub3`: "{offer_id}"
- `aff_sub4`: "{landing_kind}"

## Cron Jobs (Manual Setup)
Daily ingest: 4:00 AM  
Feed rebuild: Every 2h at :15

See full README for SQL cron setup.

## URL Selection Quality

Each landing URL goes through:
1. **Blocklist check**: rejects /cart, /checkout, /login, etc.
2. **Reachability**: HEAD/GET with 2s timeout
3. **Mobile check**: validates viewport meta tag
4. **Region check**: ensures MY domain (lazada.com.my, shopee.com.my, etc.)
5. **Meta quality**: checks for OG image/title
6. **Scoring**: 0-1 scale with boosts/penalties
7. **Selection metadata**: stored in `ia_landings.selection_reason`

Example selection_reason:
```json
{
  "kind": "promo",
  "checks": {"reachable": true, "mobile": true, "region": true, "deeplinkable": true},
  "boosts": {"platform": 0.10, "cps": 0.05, "meta": 0.05},
  "penalties": {"viewport": 0, "slow": 0, "region": 0},
  "score": 0.75
}
```

## Analytics
```sql
-- CTR by deal
SELECT d.title, COUNT(DISTINCT ai.id) as imp, COUNT(DISTINCT ac.id) as clicks
FROM deals_feed d
LEFT JOIN aff_impressions ai ON ai.deal_id = d.id
LEFT JOIN ia_deeplinks dl ON dl.id = d.deeplink_id
LEFT JOIN aff_clicks ac ON ac.deeplink_id = dl.id
GROUP BY d.id, d.title
ORDER BY clicks DESC;
```
